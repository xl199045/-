<?php
/**
 * OAuth 统一回调处理（29 渠道）
 * 支持：github / gitee / alipay / qq / wechat / weibo / baidu /
 *       dingtalk / douyin / feishu / oschina / coding /
 *       huawei / google / microsoft / wework / xiaomi / bilibili /
 *       gitlab / twitter / facebook / discord / line / linkedin /
 *       qihoo / douban / netease / taobao / juhe(聚合平台)
 * 流程：callback.php?channel=xxx            -> 跳转第三方授权页
 *       授权回调 callback.php?channel=xxx&code=xxx -> 换取用户信息 -> 登录成功跳转
 * 聚合平台 juhe：对接惊霄/彩虹聚合登录协议（connect.php?act=login/callback）
 */

// 未安装时跳转安装向导
if (!file_exists(__DIR__ . '/config.php')) {
    header('Location: install/');
    exit;
}
require __DIR__ . '/config.php';

$channel = trim($_GET['channel'] ?? '');
if (!isset($channels[$channel])) {
    die('渠道不存在');
}
$info = $channels[$channel];
if ($info['enable'] != 1) {
    die('该登录渠道已在后台关闭');
}

// 绑定模式：个人中心点「绑定」时带 bind=1，这里只记录意图（回调地址由第三方登记固定，
// 不能附加自定义参数），真正的绑定在回调阶段完成。
if (isset($_GET['bind']) && $_GET['bind'] == '1') {
    if (uc_session_user_id() <= 0) {
        redirect('login.php');
    }
    $_SESSION['bind_channel'] = $channel;
}
$appid = $info['appid'];
$appsecret = $info['appsecret'];
$redirect_uri = trim((string)$info['redirect_uri']);
$success_url = !empty($systemConfig['success_redirect']) ? $systemConfig['success_redirect'] : '/';
$cbHost = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];
// 回调地址兜底与规范化：保证「跳转授权页」和「回调换用户信息」两阶段使用完全相同的 redirect_uri
// （后台未填写时用与后台展示一致的本站回调地址；填写了相对路径时补全为完整地址）
if ($redirect_uri !== '' && !preg_match('#^https?://#i', $redirect_uri)) {
    $redirect_uri = $cbHost . '/' . ltrim($redirect_uri, '/');
}
if ($redirect_uri === '') {
    $redirect_uri = $cbHost . '/callback.php?channel=' . $channel;
}

/* ===== 对接方式：走官方还是聚合，完全由后台该渠道的「对接方式」(mode) 决定 =====
   惊霄/彩虹聚合平台实际支持的 type（以惊霄 platforms.php 为准，共 16 个） */
$juheTypeMap = [
    'qq' => 'qq', 'wechat' => 'wx', 'alipay' => 'alipay', 'weibo' => 'sina', 'baidu' => 'baidu',
    'douyin' => 'douyin', 'huawei' => 'huawei', 'google' => 'google', 'microsoft' => 'microsoft',
    'wework' => 'wework', 'dingtalk' => 'dingtalk', 'gitee' => 'gitee', 'github' => 'github',
    'feishu' => 'feishu', 'bilibili' => 'bilibili', 'xiaomi' => 'xiaomi',
];
$useJuhe = ($info['mode'] ?? 0) == 1 && $channel !== 'juhe';

// 渠道对接方式 = 聚合平台：读取惊霄凭证（全局配置优先；全局没填时回退用该渠道卡片里填的惊霄凭证，两种填法都兼容）
if ($useJuhe) {
    $jHost = rtrim($systemConfig['juhe_host'] ?? '', '/');
    $jAppid = trim((string)($systemConfig['juhe_appid'] ?? ''));
    $jAppkey = trim((string)($systemConfig['juhe_appkey'] ?? ''));
    if ($jAppid === '' && $jAppkey === '') {
        $jAppid = trim((string)$info['appid']);
        $jAppkey = trim((string)$info['appsecret']);
    }
    if (!$jHost || !$jAppid || !$jAppkey) {
        die('聚合登录未配置：请在后台「一键聚合登录配置」填写 API 域名、AppID、AppKey（或在该渠道卡片里填写惊霄平台的 AppID/AppKey）');
    }
    $appid = $jAppid;
    $appsecret = $jAppkey;
    // 回调固定为本渠道入口（mode 已决定走聚合，授权回调回来自动按聚合换用户信息）
    $redirect_uri = $cbHost . '/callback.php?channel=' . $channel;
}

/* ===== CSRF state 校验 ===== */
if (empty($_SESSION['oauth_state'])) {
    $_SESSION['oauth_state'] = md5(uniqid((string)rand(), true));
}
$state = $_SESSION['oauth_state'];
if (isset($_GET['state']) && $_GET['state'] !== $state) {
    die('state 校验失败（防 CSRF），请重新发起登录');
}

/* ===== 1. 无 code：跳转授权页 ===== */
$hasCode = isset($_GET['code']) || isset($_GET['auth_code']);
if (!$hasCode) {
    if ($useJuhe) {
        // 对接聚合平台：向聚合平台换取登录跳转地址
        $juheHost = rtrim($systemConfig['juhe_host'] ?? '', '/');
        if (!$juheHost) die('该渠道已设为「对接聚合平台」，但后台「跳转设置」未填写聚合平台 API 域名');
        if (!isset($juheTypeMap[$channel])) die('该渠道暂不支持通过聚合平台登录，请改为直连官方');
        $jt = $juheTypeMap[$channel];
        // 必须把本站 state 一并传给聚合平台：平台回调时会原样回传，
        // 否则回传空 state 会被本站 CSRF 校验拦截，导致授权成功后仍无法登录
        $loginApi = $juheHost . '/connect.php?act=login&appid=' . urlencode($appid) . '&appkey=' . urlencode($appsecret)
            . '&type=' . urlencode($jt) . '&redirect_uri=' . urlencode($redirect_uri) . '&state=' . urlencode($state);
        $lr = http_request($loginApi, 'GET');
        $netFail = ($lr === false || trim((string)$lr) === '');
        if ($netFail) {
            $lr = '（聚合平台无响应：域名不可达 / SSL 失败 / 被服务器防火墙拦截）';
        }
        $ld = json_decode($lr, true);
        $jumpUrl = $ld['url'] ?? '';
        if (($ld['code'] ?? -1) !== 0 || !$jumpUrl) {
            // 按惊霄返回内容给出对应排查指引
            $jmsg = trim((string)($ld['msg'] ?? $lr));
            if ($netFail) {
                $hint = '<b>原因：</b>本站服务器无法连通聚合平台 API 域名。请把下方「完整请求地址」复制到浏览器直接打开验证；若浏览器能打开而服务器不能，请检查服务器出网与防火墙放行。';
            } elseif (stripos($jmsg, 'appid') !== false || mb_strpos($jmsg, '应用') !== false) {
                $hint = '<b>原因：</b>AppID / AppKey 与惊霄平台应用不一致。请登录惊霄平台 → 打开该应用 →「接口配置」，把 APPID、APPKEY <b>原样复制</b>到本系统后台「渠道管理 → 一键聚合登录配置」并保存（注意不要填成其他应用的凭证）。';
            } elseif (mb_strpos($jmsg, '登录方式') !== false || mb_strpos($jmsg, '渠道') !== false || stripos($jmsg, 'type') !== false) {
                $hint = '<b>原因：</b>聚合平台不认识或未开通 <b>' . e($jt) . '</b> 这一登录方式（本站渠道：<b>' . e($channel) . '</b>）。请到惊霄平台管理后台 →「平台配置」开通该渠道并配好平台侧凭证；若聚合平台确实不支持该渠道，请到本系统后台把该渠道「对接方式」改为「直连官方 OAuth」。';
            } else {
                $hint = '<b>常见原因：</b>① 后台「一键聚合登录配置」的 APPID/APPKEY 与惊霄平台应用不一致；② 惊霄平台未启用 <b>' . e($jt) . '</b> 渠道（惊霄平台 →「平台配置」打开开关）；③ 该渠道可改为「直连官方 OAuth」再试。';
            }
            die('<div style="font-family:monospace;max-width:680px;margin:30px auto;line-height:1.9;font-size:14px">'
                . '<b>聚合登录请求失败</b><br>'
                . '本站渠道：' . e($channel) . ' ｜ 发送给惊霄的 type：<b>' . e($jt) . '</b><br>'
                . '惊霄返回：<b style="color:#f87171">' . e($jmsg) . '</b><br><br>'
                . '<b>本次请求使用的 AppID：</b><code style="background:#0f172a;padding:2px 8px;border-radius:6px;color:#7dd3fc">' . e($appid) . '</code>（请对照惊霄平台应用页的 APPID）<br><br>'
                . '<b>完整请求地址（可复制到浏览器直接打开核对）：</b><br>'
                . '<code style="word-break:all;background:#0f172a;padding:8px 10px;border-radius:8px;display:block;color:#7dd3fc">' . e($loginApi) . '</code><br>'
                . $hint
                . '</div>');
        }
        redirect($jumpUrl);
    }
    // 直连官方前置校验：凭证为空时不带着残缺参数跳转第三方（第三方只会给出晦涩报错）
    if ($channel !== 'juhe' && trim((string)$appid) === '') {
        die('该渠道尚未配置 AppID：请到后台「渠道管理」填写该渠道的 AppID / AppSecret 并保存；也可把该渠道「对接方式」改为「对接聚合平台」');
    }
    $authUrl = '';
    switch ($channel) {
        case 'github':
            $authUrl = "https://github.com/login/oauth/authorize?client_id={$appid}&redirect_uri=" . urlencode($redirect_uri) . "&scope=read:user&state={$state}";
            break;
        case 'gitee':
            $authUrl = "https://gitee.com/oauth/authorize?client_id={$appid}&redirect_uri=" . urlencode($redirect_uri) . "&response_type=code&state={$state}";
            break;
        case 'alipay':
            $authUrl = "https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id={$appid}&scope=auth_user&redirect_uri=" . urlencode($redirect_uri) . "&state={$state}";
            break;
        case 'qq':
            $authUrl = "https://graph.qq.com/oauth2.0/authorize?response_type=code&client_id={$appid}&redirect_uri=" . urlencode($redirect_uri) . "&state={$state}";
            break;
        case 'wechat':
            $authUrl = "https://open.weixin.qq.com/connect/qrconnect?appid={$appid}&redirect_uri=" . urlencode($redirect_uri) . "&response_type=code&scope=snsapi_login&state={$state}#wechat_redirect";
            break;
        case 'weibo':
            $authUrl = "https://api.weibo.com/oauth2/authorize?client_id={$appid}&redirect_uri=" . urlencode($redirect_uri) . "&response_type=code&state={$state}";
            break;
        case 'baidu':
            $authUrl = "https://openapi.baidu.com/oauth/2.0/authorize?response_type=code&client_id={$appid}&redirect_uri=" . urlencode($redirect_uri) . "&scope=basic&state={$state}";
            break;
        case 'dingtalk':
            $authUrl = "https://login.dingtalk.com/oauth2/auth?redirect_uri=" . urlencode($redirect_uri) . "&response_type=code&client_id={$appid}&scope=openid&state={$state}&prompt=consent";
            break;
        case 'douyin':
            $authUrl = "https://open.douyin.com/platform/oauth/connect?client_key={$appid}&response_type=code&scope=user_info&redirect_uri=" . urlencode($redirect_uri) . "&state={$state}";
            break;
        case 'feishu':
            $authUrl = "https://accounts.feishu.cn/open-apis/authen/v1/index?redirect_uri=" . urlencode($redirect_uri) . "&app_id={$appid}&state={$state}";
            break;
        case 'oschina':
            $authUrl = "https://www.oschina.net/action/oauth2/authorize?response_type=code&client_id={$appid}&redirect_uri=" . urlencode($redirect_uri) . "&state={$state}";
            break;
        case 'coding':
            $authUrl = "https://coding.net/oauth/authorize?client_id={$appid}&redirect_uri=" . urlencode($redirect_uri) . "&response_type=code&scope=user&state={$state}";
            break;
        case 'huawei':
            $authUrl = "https://oauth-login.cloud.huawei.com/oauth2/v3/authorize?client_id={$appid}&redirect_uri=" . urlencode($redirect_uri) . "&response_type=code&scope=openid&state={$state}";
            break;
        case 'google':
            $authUrl = "https://accounts.google.com/o/oauth2/v2/auth?client_id={$appid}&redirect_uri=" . urlencode($redirect_uri) . "&response_type=code&scope=openid%20email%20profile&state={$state}";
            break;
        case 'microsoft':
            $authUrl = "https://login.microsoftonline.com/common/oauth2/v2.0/authorize?client_id={$appid}&redirect_uri=" . urlencode($redirect_uri) . "&response_type=code&scope=User.Read&state={$state}";
            break;
        case 'wework':
            // 企业微信扫码登录：AppID 填 CorpID，AppSecret 填应用 Secret，AgentId 用 "CorpID|AgentId" 格式写在 AppID 中
            $corpId = $appid; $agentId = '';
            if (strpos($appid, '|') !== false) { [$corpId, $agentId] = explode('|', $appid, 2); }
            if ($agentId === '') die('企业微信登录需同时配置 CorpID 和 AgentID：请到后台「渠道管理 → 企业微信登录」分别填写两个字段并保存（AgentID 为自建应用 ID），保存后重试');
            $authUrl = "https://open.work.weixin.qq.com/wwopen/sso/qrConnect?appid={$corpId}&agentid={$agentId}&redirect_uri=" . urlencode($redirect_uri) . "&state={$state}";
            break;
        case 'xiaomi':
            $authUrl = "https://account.xiaomi.com/oauth2/authorize?client_id={$appid}&redirect_uri=" . urlencode($redirect_uri) . "&response_type=code&scope=profile&state={$state}";
            break;
        case 'bilibili':
            $authUrl = "https://passport.bilibili.com/login/oauth/v2/authorize?client_id={$appid}&response_type=code&redirect_uri=" . urlencode($redirect_uri) . "&state={$state}";
            break;
        case 'gitlab':
            $authUrl = "https://gitlab.com/oauth/authorize?client_id={$appid}&redirect_uri=" . urlencode($redirect_uri) . "&response_type=code&scope=read_user&state={$state}";
            break;
        case 'twitter':
            $authUrl = "https://twitter.com/i/oauth2/authorize?response_type=code&client_id={$appid}&redirect_uri=" . urlencode($redirect_uri) . "&scope=users.read&state={$state}&code_challenge=challenge&code_challenge_method=plain";
            break;
        case 'facebook':
            $authUrl = "https://www.facebook.com/v18.0/dialog/oauth?client_id={$appid}&redirect_uri=" . urlencode($redirect_uri) . "&state={$state}";
            break;
        case 'discord':
            $authUrl = "https://discord.com/oauth2/authorize?client_id={$appid}&redirect_uri=" . urlencode($redirect_uri) . "&response_type=code&scope=identify&state={$state}";
            break;
        case 'line':
            $authUrl = "https://access.line.me/oauth2/v2.1/authorize?response_type=code&client_id={$appid}&redirect_uri=" . urlencode($redirect_uri) . "&state={$state}&scope=profile";
            break;
        case 'linkedin':
            $authUrl = "https://www.linkedin.com/oauth/v2/authorization?response_type=code&client_id={$appid}&redirect_uri=" . urlencode($redirect_uri) . "&scope=openid%20profile%20email&state={$state}";
            break;
        case 'qihoo':
            $authUrl = "https://openapi.360.cn/oauth/authorize?client_id={$appid}&response_type=code&redirect_uri=" . urlencode($redirect_uri) . "&scope=basic&state={$state}";
            break;
        case 'douban':
            $authUrl = "https://www.douban.com/service/auth2/auth?client_id={$appid}&redirect_uri=" . urlencode($redirect_uri) . "&response_type=code&state={$state}";
            break;
        case 'netease':
            $authUrl = "https://reg.163.com/oauth2/authorize?client_id={$appid}&redirect_uri=" . urlencode($redirect_uri) . "&response_type=code&state={$state}";
            break;
        case 'taobao':
            $authUrl = "https://oauth.taobao.com/authorize?response_type=code&client_id={$appid}&redirect_uri=" . urlencode($redirect_uri) . "&state={$state}";
            break;
        case 'juhe':
            // 聚合平台（对接惊霄/彩虹聚合登录协议），走独立流程，见下方 Step1 处理
            $juheHost = rtrim($systemConfig['juhe_host'] ?? '', '/');
            if (!$juheHost) die('聚合平台渠道未配置 API 域名，请到后台「跳转设置」填写');
            $juheType = trim($_GET['type'] ?? '');
            if ($juheType === '') {
                // 未选择登录方式：显示聚合平台渠道选择页
                $siteName = $systemConfig['site_name'] ?? '聚合登录';
                $theme = $systemConfig['theme_color'] ?? '#22d3ee';
                $juheTypes = [
                    'qq' => 'QQ', 'wx' => '微信', 'alipay' => '支付宝', 'sina' => '微博', 'baidu' => '百度',
                    'douyin' => '抖音', 'huawei' => '华为', 'xiaomi' => '小米', 'bilibili' => '哔哩哔哩',
                    'google' => '谷歌', 'facebook' => 'Facebook', 'twitter' => 'Twitter', 'feishu' => '飞书',
                    'dingtalk' => '钉钉', 'gitee' => 'Gitee', 'github' => 'GitHub', 'telegram' => 'Telegram',
                ];
                $colors = [
                    'qq' => '#12B7F5', 'wx' => '#07C160', 'alipay' => '#1677FF', 'sina' => '#E6162D', 'baidu' => '#2932E1',
                    'douyin' => '#111111', 'huawei' => '#C7000B', 'xiaomi' => '#FF6900', 'bilibili' => '#00A1D6',
                    'google' => '#4285F4', 'facebook' => '#1877F2', 'twitter' => '#1DA1F2', 'feishu' => '#3370FF',
                    'dingtalk' => '#0089FF', 'gitee' => '#C71D23', 'github' => '#24292F', 'telegram' => '#2AABEE',
                ];
                $btnHtml = '';
                foreach ($juheTypes as $tk => $tv) {
                    $btnHtml .= '<a class="oauth-btn" style="--oc:' . ($colors[$tk] ?? '#8B5CF6') . '" href="callback.php?channel=juhe&type=' . $tk . '">'
                        . '<i class="oauth-icon" style="background:' . ($colors[$tk] ?? '#8B5CF6') . '">' . $tv[0] . '</i>'
                        . $tv . '登录</a>';
                }
                echo '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">'
                    . '<title>聚合平台登录 - ' . e($siteName) . '</title><link rel="stylesheet" href="assets/css/style.css">'
                    . '<style>:root{--tc:' . e($theme) . '}</style></head><body><div class="login-page"><div class="login-shell">'
                    . '<div class="card glow-card login-box"><h2 style="text-align:center">聚合平台登录</h2>'
                    . '<p class="login-sub">通过聚合平台选择第三方账号快捷登录</p><div class="oauth-list">' . $btnHtml . '</div>'
                    . '<div class="login-foot"><a href="login.php">返回其他登录方式</a></div></div></div></div></body></html>';
                exit;
            }
            // Step1：向聚合平台换取登录跳转地址
            // 记录本次选择的方式：部分聚合平台回调时不回传 type，回调时用 session 兜底
            $_SESSION['juhe_type'] = $juheType;
            $loginApi = $juheHost . '/connect.php?act=login&appid=' . urlencode($appid) . '&appkey=' . urlencode($appsecret)
                . '&type=' . urlencode($juheType) . '&redirect_uri=' . urlencode($redirect_uri) . '&state=' . urlencode($state);
            $lr = http_request($loginApi, 'GET');
            $ld = json_decode($lr, true);
            $jumpUrl = $ld['url'] ?? '';
            if (($ld['code'] ?? -1) !== 0 || !$jumpUrl) die('聚合平台获取登录地址失败：' . e($ld['msg'] ?? $lr));
            redirect($jumpUrl);
            break;
        default:
            die('不支持的渠道');
    }
    redirect($authUrl);
}

/* ===== 2. 有 code：换取用户信息 ===== */
$openid = '';
$nickname = '';
$avatar = '';

if ($useJuhe) {
    // 对接聚合平台：code 换用户信息（social_uid 为用户唯一标识）
    $juheHost = rtrim($systemConfig['juhe_host'] ?? '', '/');
    $jt = $juheTypeMap[$channel] ?? '';
    if ($jt === '') die('该渠道不支持通过聚合平台登录，请到后台把对接方式改为「直连官方 OAuth」');
    $cbApi = $juheHost . '/connect.php?act=callback&appid=' . urlencode($appid) . '&appkey=' . urlencode($appsecret)
        . '&type=' . urlencode($jt) . '&code=' . urlencode($_GET['code'] ?? '');
    $cr = http_request($cbApi, 'GET');
    $cd = json_decode($cr, true);
    if (($cd['code'] ?? -1) !== 0) die('聚合登录回调失败（渠道：' . e($channel) . '，类型：' . e($jt) . '）<br>错误：' . e($cd['msg'] ?? $cr));
    $openid = $cd['social_uid'] ?? '';
    $nickname = $cd['nickname'] ?? '聚合平台用户';
    $avatar = $cd['faceimg'] ?? '';
} else {
    switch ($channel) {

    /* ---------- GitHub ---------- */
    case 'github':
        $tr = http_request('https://github.com/login/oauth/access_token', 'POST', [
            'client_id' => $appid, 'client_secret' => $appsecret, 'code' => $_GET['code'] ?? '', 'redirect_uri' => $redirect_uri,
        ], ['Accept: application/json']);
        $td = json_decode($tr, true);
        $at = $td['access_token'] ?? '';
        if (!$at) die('GitHub 授权失败：' . e($td['error_description'] ?? $tr));
        $ur = http_request('https://api.github.com/user', 'GET', [], ['Authorization: token ' . $at, 'User-Agent: JuheLogin', 'Accept: application/vnd.github+json']);
        $u = json_decode($ur, true);
        $openid = $u['id'] ?? '';
        $nickname = $u['login'] ?? $u['name'] ?? '';
        $avatar = $u['avatar_url'] ?? '';
        break;

    /* ---------- Gitee ---------- */
    case 'gitee':
        $tr = http_request('https://gitee.com/oauth/token', 'POST', [
            'grant_type' => 'authorization_code', 'code' => $_GET['code'] ?? '',
            'client_id' => $appid, 'client_secret' => $appsecret, 'redirect_uri' => $redirect_uri,
        ]);
        $td = json_decode($tr, true);
        $at = $td['access_token'] ?? '';
        if (!$at) die('Gitee 授权失败：' . e($td['error_description'] ?? $tr));
        $ur = http_request('https://gitee.com/api/v5/user', 'GET', ['access_token' => $at]);
        $u = json_decode($ur, true);
        $openid = $u['id'] ?? '';
        $nickname = $u['name'] ?? $u['login'] ?? '';
        $avatar = $u['avatar_url'] ?? '';
        break;

    /* ---------- 支付宝 ---------- */
    case 'alipay':
        $authCode = $_GET['auth_code'] ?? '';
        if (!$authCode) die('支付宝授权失败：未获取到 auth_code');
        if (empty($appsecret)) die('支付宝渠道未配置应用私钥，请在后台填写');
        $params = [
            'app_id' => $appid, 'method' => 'alipay.system.oauth.token', 'charset' => 'utf-8',
            'sign_type' => 'RSA2', 'timestamp' => date('Y-m-d H:i:s'), 'version' => '1.0',
            'grant_type' => 'authorization_code', 'code' => $authCode,
        ];
        $params['sign'] = alipaySign($params, $appsecret);
        $resp = http_request('https://openapi.alipay.com/gateway.do', 'POST', $params);
        $data = json_decode($resp, true);
        $tr = $data['alipay_system_oauth_token_response'] ?? null;
        if (!$tr) die('支付宝换取用户失败：' . e($resp));
        $openid = $tr['user_id'] ?? '';
        $nickname = $tr['user_name'] ?? '支付宝用户';
        if (!$openid) die('支付宝授权失败：' . e($tr['sub_msg'] ?? $tr['msg'] ?? '未知错误'));
        break;

    /* ---------- QQ ---------- */
    case 'qq':
        $tr = http_request('https://graph.qq.com/oauth2.0/token', 'GET', [
            'grant_type' => 'authorization_code', 'code' => $_GET['code'] ?? '',
            'client_id' => $appid, 'client_secret' => $appsecret, 'redirect_uri' => $redirect_uri,
        ]);
        parse_str($tr, $td);
        $at = $td['access_token'] ?? '';
        if (!$at) die('QQ 授权失败：' . e($tr));
        $mr = http_request('https://graph.qq.com/oauth2.0/me', 'GET', ['access_token' => $at]);
        if (preg_match('/"openid"\s*:\s*"([^"]+)"/', $mr, $m)) {
            $openid = $m[1];
        }
        if (!$openid) die('QQ 获取 openid 失败：' . e($mr));
        $ur = http_request('https://graph.qq.com/user/get_user_info', 'GET', [
            'access_token' => $at, 'oauth_consumer_key' => $appid, 'openid' => $openid,
        ]);
        $u = json_decode($ur, true);
        $nickname = $u['nickname'] ?? 'QQ用户';
        $avatar = $u['figureurl_qq_2'] ?? $u['figureurl_qq_1'] ?? '';
        break;

    /* ---------- 微信（开放平台扫码） ---------- */
    case 'wechat':
        $tr = http_request('https://api.weixin.qq.com/sns/oauth2/access_token', 'GET', [
            'appid' => $appid, 'secret' => $appsecret, 'code' => $_GET['code'] ?? '', 'grant_type' => 'authorization_code',
        ]);
        $td = json_decode($tr, true);
        $at = $td['access_token'] ?? '';
        $openid = $td['openid'] ?? '';
        if (!$at || !$openid) die('微信授权失败：' . e($td['errmsg'] ?? $tr));
        $ur = http_request('https://api.weixin.qq.com/sns/userinfo', 'GET', ['access_token' => $at, 'openid' => $openid]);
        $u = json_decode($ur, true);
        $nickname = $u['nickname'] ?? '微信用户';
        $avatar = $u['headimgurl'] ?? '';
        break;

    /* ---------- 微博 ---------- */
    case 'weibo':
        $tr = http_request('https://api.weibo.com/oauth2/access_token', 'POST', [
            'client_id' => $appid, 'client_secret' => $appsecret, 'grant_type' => 'authorization_code',
            'code' => $_GET['code'] ?? '', 'redirect_uri' => $redirect_uri,
        ]);
        $td = json_decode($tr, true);
        $at = $td['access_token'] ?? '';
        $openid = $td['uid'] ?? '';
        if (!$at || !$openid) die('微博授权失败：' . e($td['error_description'] ?? $tr));
        $ur = http_request('https://api.weibo.com/2/users/show.json', 'GET', ['access_token' => $at, 'uid' => $openid]);
        $u = json_decode($ur, true);
        $nickname = $u['screen_name'] ?? '微博用户';
        $avatar = $u['avatar_large'] ?? '';
        break;

    /* ---------- 百度 ---------- */
    case 'baidu':
        $tr = http_request('https://openapi.baidu.com/oauth/2.0/token', 'GET', [
            'grant_type' => 'authorization_code', 'code' => $_GET['code'] ?? '',
            'client_id' => $appid, 'client_secret' => $appsecret, 'redirect_uri' => $redirect_uri,
        ]);
        $td = json_decode($tr, true);
        $at = $td['access_token'] ?? '';
        if (!$at) die('百度授权失败：' . e($td['error_description'] ?? $tr));
        $ur = http_request('https://openapi.baidu.com/rest/2.0/passport/users/getInfo', 'GET', ['access_token' => $at]);
        $u = json_decode($ur, true);
        $openid = $u['userid'] ?? '';
        $nickname = $u['username'] ?? $u['uname'] ?? '百度用户';
        if (!empty($u['portrait'])) {
            $avatar = 'https://himg.bdimg.com/sys/portraitn/item/' . $u['portrait'];
        }
        break;

    /* ---------- 钉钉（扫码） ---------- */
    case 'dingtalk':
        $tr = http_request('https://api.dingtalk.com/v1.0/oauth2/userAccessToken', 'POST', json_encode([
            'clientId' => $appid, 'clientSecret' => $appsecret, 'code' => $_GET['code'] ?? '', 'grantType' => 'authorization_code',
        ]), ['Content-Type: application/json']);
        $td = json_decode($tr, true);
        $at = $td['accessToken'] ?? '';
        if (!$at) die('钉钉授权失败：' . e($td['message'] ?? $tr));
        $ur = http_request('https://api.dingtalk.com/v1.0/oauth2/userinfo', 'GET', [], ['Authorization: Bearer ' . $at]);
        $u = json_decode($ur, true);
        $openid = $u['openId'] ?? '';
        $nickname = $u['nick'] ?? '钉钉用户';
        $avatar = $u['avatarUrl'] ?? '';
        break;

    /* ---------- 抖音 ---------- */
    case 'douyin':
        $tr = http_request('https://open.douyin.com/oauth/access_token/', 'POST', [
            'client_key' => $appid, 'client_secret' => $appsecret, 'code' => $_GET['code'] ?? '', 'grant_type' => 'authorization_code',
        ]);
        $td = json_decode($tr, true);
        $d = $td['data'] ?? [];
        $at = $d['access_token'] ?? '';
        $openid = $d['open_id'] ?? '';
        if (!$at) die('抖音授权失败：' . e($td['message'] ?? $tr));
        $ur = http_request('https://open.douyin.com/oauth/userinfo/', 'GET', ['access_token' => $at, 'open_id' => $openid]);
        $ud = json_decode($ur, true);
        $u = $ud['data'] ?? [];
        $nickname = $u['nickname'] ?? '抖音用户';
        $avatar = $u['avatar'] ?? '';
        break;

    /* ---------- 飞书 ---------- */
    case 'feishu':
        // 飞书 v2 接口：客户端直接以 client_id/client_secret 换 user_access_token
        // （原 v1 oidc/access_token 接口要求额外的 app_access_token 请求头，未携带必然失败）
        $tr = http_request('https://open.feishu.cn/open-apis/authen/v2/oauth/token', 'POST', json_encode([
            'grant_type' => 'authorization_code', 'client_id' => $appid, 'client_secret' => $appsecret,
            'code' => $_GET['code'] ?? '', 'redirect_uri' => $redirect_uri,
        ]), ['Content-Type: application/json']);
        $td = json_decode($tr, true);
        $at = $td['access_token'] ?? ($td['data']['access_token'] ?? '');
        if (!$at) die('飞书授权失败：' . e($td['error_description'] ?? $td['error'] ?? $td['msg'] ?? $tr));
        $ur = http_request('https://open.feishu.cn/open-apis/authen/v1/user_info', 'GET', [], ['Authorization: Bearer ' . $at]);
        $u = json_decode($ur, true);
        $ud = $u['data'] ?? [];
        $openid = $ud['open_id'] ?? '';
        $nickname = $ud['name'] ?? '飞书用户';
        $avatar = $ud['avatar_url'] ?? '';
        break;

    /* ---------- 开源中国 ---------- */
    case 'oschina':
        $tr = http_request('https://www.oschina.net/action/oauth2/token', 'POST', [
            'grant_type' => 'authorization_code', 'code' => $_GET['code'] ?? '',
            'client_id' => $appid, 'client_secret' => $appsecret, 'redirect_uri' => $redirect_uri,
        ]);
        $td = json_decode($tr, true);
        $at = $td['access_token'] ?? '';
        if (!$at) die('OSChina 授权失败：' . e($tr));
        $ur = http_request('https://www.oschina.net/action/openapi/user', 'GET', ['access_token' => $at]);
        $u = json_decode($ur, true);
        $openid = $u['id'] ?? '';
        $nickname = $u['name'] ?? 'OSChina用户';
        $avatar = $u['avatar'] ?? '';
        break;

    /* ---------- Coding ---------- */
    case 'coding':
        $tr = http_request('https://coding.net/api/oauth/access_token', 'POST', [
            'grant_type' => 'authorization_code', 'code' => $_GET['code'] ?? '',
            'client_id' => $appid, 'client_secret' => $appsecret,
        ]);
        $td = json_decode($tr, true);
        $at = $td['access_token'] ?? '';
        if (!$at) die('Coding 授权失败：' . e($tr));
        $ur = http_request('https://coding.net/api/current_user', 'GET', ['access_token' => $at]);
        $u = json_decode($ur, true);
        $ud = $u['data'] ?? $u;
        $openid = $ud['global_key'] ?? $ud['id'] ?? '';
        $nickname = $ud['name'] ?? $ud['global_key'] ?? 'Coding用户';
        $avatar = $ud['avatar'] ?? '';
        break;

    /* ---------- 华为 ---------- */
    case 'huawei':
        $tr = http_request('https://oauth-login.cloud.huawei.com/oauth2/v3/token', 'POST', [
            'grant_type' => 'authorization_code', 'code' => $_GET['code'] ?? '',
            'client_id' => $appid, 'client_secret' => $appsecret, 'redirect_uri' => $redirect_uri,
        ]);
        $td = json_decode($tr, true);
        $at = $td['access_token'] ?? '';
        if (!$at) die('华为授权失败：' . e($td['error_description'] ?? $tr));
        $ur = http_request('https://oauth-login.cloud.huawei.com/oauth2/v3/userinfo', 'GET', [], ['Authorization: Bearer ' . $at]);
        $u = json_decode($ur, true);
        $openid = $u['openid'] ?? $u['sub'] ?? '';
        $nickname = $u['name'] ?? '华为用户';
        $avatar = $u['picture'] ?? '';
        break;

    /* ---------- 谷歌 ---------- */
    case 'google':
        $tr = http_request('https://oauth2.googleapis.com/token', 'POST', [
            'code' => $_GET['code'] ?? '', 'client_id' => $appid, 'client_secret' => $appsecret,
            'redirect_uri' => $redirect_uri, 'grant_type' => 'authorization_code',
        ]);
        $td = json_decode($tr, true);
        $at = $td['access_token'] ?? '';
        if (!$at) die('Google 授权失败：' . e($td['error_description'] ?? $tr));
        $ur = http_request('https://www.googleapis.com/oauth2/v3/userinfo', 'GET', [], ['Authorization: Bearer ' . $at]);
        $u = json_decode($ur, true);
        $openid = $u['sub'] ?? '';
        $nickname = $u['name'] ?? 'Google用户';
        $avatar = $u['picture'] ?? '';
        break;

    /* ---------- 微软 ---------- */
    case 'microsoft':
        $tr = http_request('https://login.microsoftonline.com/common/oauth2/v2.0/token', 'POST', [
            'client_id' => $appid, 'client_secret' => $appsecret,
            'code' => $_GET['code'] ?? '', 'redirect_uri' => $redirect_uri, 'grant_type' => 'authorization_code',
        ]);
        $td = json_decode($tr, true);
        $at = $td['access_token'] ?? '';
        if (!$at) die('微软授权失败：' . e($td['error_description'] ?? $tr));
        $ur = http_request('https://graph.microsoft.com/v1.0/me', 'GET', [], ['Authorization: Bearer ' . $at]);
        $u = json_decode($ur, true);
        $openid = $u['id'] ?? '';
        $nickname = $u['displayName'] ?? '微软用户';
        $avatar = '';
        break;

    /* ---------- 企业微信（扫码登录） ---------- */
    case 'wework':
        $corpId = $appid; $agentId = '';
        if (strpos($appid, '|') !== false) { [$corpId, $agentId] = explode('|', $appid, 2); }
        if ($agentId === '') die('企业微信登录未配置 AgentID：请到后台「渠道管理 → 企业微信登录」填写 CorpID 与 AgentID 后重试');
        $tr = http_request('https://qyapi.weixin.qq.com/cgi-bin/gettoken', 'GET', ['corpid' => $corpId, 'corpsecret' => $appsecret]);
        $td = json_decode($tr, true);
        $at = $td['access_token'] ?? '';
        if (!$at) die('企业微信获取 access_token 失败：' . e($td['errmsg'] ?? $tr));
        $ur = http_request('https://qyapi.weixin.qq.com/cgi-bin/auth/getuserinfo', 'GET', ['access_token' => $at, 'code' => $_GET['code'] ?? '']);
        $u = json_decode($ur, true);
        $userId = $u['userid'] ?? $u['UserId'] ?? '';
        if (!$userId) die('企业微信授权失败：' . e($u['errmsg'] ?? $ur));
        $openid = $userId;
        $dr = http_request('https://qyapi.weixin.qq.com/cgi-bin/user/get', 'GET', ['access_token' => $at, 'userid' => $userId]);
        $du = json_decode($dr, true);
        $nickname = $du['name'] ?? $userId;
        $avatar = $du['avatar'] ?? '';
        break;

    /* ---------- 小米 ---------- */
    case 'xiaomi':
        $tr = http_request('https://account.xiaomi.com/oauth2/token', 'POST', [
            'client_id' => $appid, 'client_secret' => $appsecret, 'grant_type' => 'authorization_code',
            'redirect_uri' => $redirect_uri, 'code' => $_GET['code'] ?? '',
        ]);
        $td = json_decode($tr, true);
        $at = $td['access_token'] ?? '';
        if (!$at) die('小米授权失败：' . e($td['error_description'] ?? $tr));
        $ur = http_request('https://open.account.xiaomi.com/user/profile', 'GET', ['clientId' => $appid, 'token' => $at]);
        $u = json_decode($ur, true);
        $ud = $u['data'] ?? [];
        $openid = $ud['userId'] ?? '';
        $nickname = $ud['miliaoNick'] ?? '小米用户';
        $avatar = $ud['miliaoIcon'] ?? '';
        break;

    /* ---------- 哔哩哔哩 ---------- */
    case 'bilibili':
        $tr = http_request('https://passport.bilibili.com/login/oauth/v2/token', 'POST', [
            'grant_type' => 'authorization_code', 'code' => $_GET['code'] ?? '',
            'client_id' => $appid, 'client_secret' => $appsecret, 'redirect_uri' => $redirect_uri,
        ]);
        $td = json_decode($tr, true);
        $at = $td['access_token'] ?? '';
        if (!$at) die('B站授权失败：' . e($td['error_description'] ?? $tr));
        $openid = $td['openid'] ?? '';
        $ur = http_request('https://api.bilibili.com/x/account/getInfo', 'GET', ['access_token' => $at]);
        $u = json_decode($ur, true);
        $ud = $u['data'] ?? [];
        if (!$openid) $openid = $ud['mid'] ?? '';
        $nickname = $ud['uname'] ?? 'B站用户';
        $avatar = $ud['face'] ?? '';
        break;

    /* ---------- GitLab ---------- */
    case 'gitlab':
        $tr = http_request('https://gitlab.com/oauth/token', 'POST', [
            'grant_type' => 'authorization_code', 'code' => $_GET['code'] ?? '',
            'client_id' => $appid, 'client_secret' => $appsecret, 'redirect_uri' => $redirect_uri,
        ]);
        $td = json_decode($tr, true);
        $at = $td['access_token'] ?? '';
        if (!$at) die('GitLab 授权失败：' . e($td['error_description'] ?? $tr));
        $ur = http_request('https://gitlab.com/api/v4/user', 'GET', ['access_token' => $at]);
        $u = json_decode($ur, true);
        $openid = $u['id'] ?? '';
        $nickname = $u['name'] ?? $u['username'] ?? 'GitLab用户';
        $avatar = $u['avatar_url'] ?? '';
        break;

    /* ---------- X (Twitter) ---------- */
    case 'twitter':
        $tr = http_request('https://api.twitter.com/2/oauth2/token', 'POST', [
            'grant_type' => 'authorization_code', 'code' => $_GET['code'] ?? '',
            'client_id' => $appid, 'client_secret' => $appsecret,
            'redirect_uri' => $redirect_uri, 'code_verifier' => 'challenge',
        ]);
        $td = json_decode($tr, true);
        $at = $td['access_token'] ?? '';
        if (!$at) die('X 授权失败：' . e($td['error_description'] ?? $tr));
        $ur = http_request('https://api.twitter.com/2/users/me', 'GET', [], ['Authorization: Bearer ' . $at]);
        $u = json_decode($ur, true);
        $ud = $u['data'] ?? [];
        $openid = $ud['id'] ?? '';
        $nickname = $ud['name'] ?? $ud['username'] ?? 'X用户';
        $avatar = $ud['profile_image_url'] ?? '';
        break;

    /* ---------- Facebook ---------- */
    case 'facebook':
        $tr = http_request('https://graph.facebook.com/v18.0/oauth/access_token', 'GET', [
            'client_id' => $appid, 'client_secret' => $appsecret,
            'code' => $_GET['code'] ?? '', 'redirect_uri' => $redirect_uri,
        ]);
        $td = json_decode($tr, true);
        $at = $td['access_token'] ?? '';
        if (!$at) die('Facebook 授权失败：' . e($td['error_description'] ?? $tr));
        $ur = http_request('https://graph.facebook.com/v18.0/me?fields=id,name,picture', 'GET', ['access_token' => $at]);
        $u = json_decode($ur, true);
        $openid = $u['id'] ?? '';
        $nickname = $u['name'] ?? 'Facebook用户';
        $avatar = $u['picture']['data']['url'] ?? '';
        break;

    /* ---------- Discord ---------- */
    case 'discord':
        $tr = http_request('https://discord.com/api/oauth2/token', 'POST', [
            'client_id' => $appid, 'client_secret' => $appsecret, 'grant_type' => 'authorization_code',
            'code' => $_GET['code'] ?? '', 'redirect_uri' => $redirect_uri,
        ]);
        $td = json_decode($tr, true);
        $at = $td['access_token'] ?? '';
        if (!$at) die('Discord 授权失败：' . e($td['error_description'] ?? $tr));
        $ur = http_request('https://discord.com/api/users/@me', 'GET', [], ['Authorization: Bearer ' . $at]);
        $u = json_decode($ur, true);
        $openid = $u['id'] ?? '';
        $nickname = $u['username'] ?? 'Discord用户';
        if (!empty($u['avatar'])) {
            $avatar = 'https://cdn.discordapp.com/avatars/' . $u['id'] . '/' . $u['avatar'] . '.png';
        }
        break;

    /* ---------- LINE ---------- */
    case 'line':
        $tr = http_request('https://api.line.me/oauth2/v2.1/token', 'POST', [
            'grant_type' => 'authorization_code', 'code' => $_GET['code'] ?? '',
            'client_id' => $appid, 'client_secret' => $appsecret, 'redirect_uri' => $redirect_uri,
        ]);
        $td = json_decode($tr, true);
        $at = $td['access_token'] ?? '';
        if (!$at) die('LINE 授权失败：' . e($td['error_description'] ?? $tr));
        $ur = http_request('https://api.line.me/v2/profile', 'GET', [], ['Authorization: Bearer ' . $at]);
        $u = json_decode($ur, true);
        $openid = $u['userId'] ?? '';
        $nickname = $u['displayName'] ?? 'LINE用户';
        $avatar = $u['pictureUrl'] ?? '';
        break;

    /* ---------- 领英 LinkedIn ---------- */
    case 'linkedin':
        $tr = http_request('https://www.linkedin.com/oauth/v2/accessToken', 'POST', [
            'grant_type' => 'authorization_code', 'code' => $_GET['code'] ?? '',
            'client_id' => $appid, 'client_secret' => $appsecret, 'redirect_uri' => $redirect_uri,
        ]);
        $td = json_decode($tr, true);
        $at = $td['access_token'] ?? '';
        if (!$at) die('领英授权失败：' . e($td['error_description'] ?? $tr));
        $ur = http_request('https://api.linkedin.com/v2/userinfo', 'GET', [], ['Authorization: Bearer ' . $at]);
        $u = json_decode($ur, true);
        $openid = $u['sub'] ?? '';
        $nickname = $u['name'] ?? '领英用户';
        $avatar = $u['picture'] ?? '';
        break;

    /* ---------- 360 ---------- */
    case 'qihoo':
        $tr = http_request('https://openapi.360.cn/oauth/token', 'POST', [
            'grant_type' => 'authorization_code', 'code' => $_GET['code'] ?? '',
            'client_id' => $appid, 'client_secret' => $appsecret, 'redirect_uri' => $redirect_uri,
        ]);
        $td = json_decode($tr, true);
        $at = $td['access_token'] ?? '';
        if (!$at) die('360 授权失败：' . e($td['error'] ?? $tr));
        $ur = http_request('https://openapi.360.cn/user/info', 'GET', ['access_token' => $at]);
        $u = json_decode($ur, true);
        $openid = $u['id'] ?? '';
        $nickname = $u['name'] ?? '360用户';
        $avatar = $u['avatar'] ?? '';
        break;

    /* ---------- 豆瓣 ---------- */
    case 'douban':
        $tr = http_request('https://www.douban.com/service/auth2/token', 'POST', [
            'grant_type' => 'authorization_code', 'code' => $_GET['code'] ?? '',
            'client_id' => $appid, 'client_secret' => $appsecret, 'redirect_uri' => $redirect_uri,
        ]);
        $td = json_decode($tr, true);
        $at = $td['access_token'] ?? '';
        if (!$at) die('豆瓣授权失败：' . e($td['msg'] ?? $tr));
        $ur = http_request('https://api.douban.com/v2/user/~me', 'GET', ['access_token' => $at]);
        $u = json_decode($ur, true);
        $openid = $u['id'] ?? $u['uid'] ?? '';
        $nickname = $u['name'] ?? '豆瓣用户';
        $avatar = $u['avatar'] ?? '';
        break;

    /* ---------- 网易 ---------- */
    case 'netease':
        $tr = http_request('https://reg.163.com/oauth2/token', 'POST', [
            'grant_type' => 'authorization_code', 'code' => $_GET['code'] ?? '',
            'client_id' => $appid, 'client_secret' => $appsecret, 'redirect_uri' => $redirect_uri,
        ]);
        $td = json_decode($tr, true);
        $at = $td['access_token'] ?? '';
        if (!$at) die('网易授权失败：' . e($td['error_description'] ?? $tr));
        $ur = http_request('https://reg.163.com/oauth2/userinfo', 'GET', ['access_token' => $at]);
        $u = json_decode($ur, true);
        $openid = $u['id'] ?? $u['openid'] ?? '';
        $nickname = $u['name'] ?? '网易用户';
        $avatar = $u['avatar'] ?? '';
        break;

    /* ---------- 淘宝 ---------- */
    case 'taobao':
        $tr = http_request('https://oauth.taobao.com/token', 'POST', [
            'grant_type' => 'authorization_code', 'code' => $_GET['code'] ?? '',
            'client_id' => $appid, 'client_secret' => $appsecret, 'redirect_uri' => $redirect_uri,
        ]);
        $td = json_decode($tr, true);
        $at = $td['access_token'] ?? '';
        if (!$at) die('淘宝授权失败：' . e($td['error_description'] ?? $tr));
        $openid = $td['open_uid'] ?? $td['taobao_user_id'] ?? '';
        $nickname = $td['taobao_user_nick'] ?? '淘宝用户';
        break;

    /* ---------- 聚合平台（对接惊霄/彩虹聚合登录） ---------- */
    case 'juhe':
        $juheHost = rtrim($systemConfig['juhe_host'] ?? '', '/');
        if (!$juheHost) die('聚合平台渠道未配置 API 域名，请到后台「跳转设置」填写');
        // type 优先取回调参数，取不到时用发起登录时记录的 session 值（兼容不携带 type 回调的聚合平台）
        $juheType = trim($_GET['type'] ?? ($_SESSION['juhe_type'] ?? ''));
        unset($_SESSION['juhe_type']);
        if ($juheType === '') die('未能识别登录方式（type 参数丢失），请返回登录页重新选择聚合平台登录');
        $cbApi = $juheHost . '/connect.php?act=callback&appid=' . urlencode($appid) . '&appkey=' . urlencode($appsecret)
            . '&type=' . urlencode($juheType) . '&code=' . urlencode($_GET['code'] ?? '');
        $cr = http_request($cbApi, 'GET');
        $cd = json_decode($cr, true);
        if (($cd['code'] ?? -1) !== 0) die('聚合平台授权失败：' . e($cd['msg'] ?? $cr));
        $openid = $cd['social_uid'] ?? '';
        $nickname = $cd['nickname'] ?? '聚合平台用户';
        $avatar = $cd['faceimg'] ?? '';
        break;

    default:
        die('不支持的渠道');
    }
}

/* ===== 3. 入库 + 登录 + 跳转 ===== */
if ($openid === '' || $openid === null) {
    die('获取用户信息失败（openid 为空），请检查渠道配置或稍后重试');
}

/* ---- 绑定模式：个人中心点「绑定」进来的，把本次授权的渠道挂到当前账号上 ---- */
$bindChannel = $_SESSION['bind_channel'] ?? '';
unset($_SESSION['bind_channel']);
$bindUid = function_exists('uc_session_user_id') ? uc_session_user_id() : 0;
if ($bindChannel !== '' && $bindChannel === $channel && $bindUid > 0) {
    $bindTitle = $channels[$channel]['title'] ?? $channel;
    $owner = uc_binding_owner($conn, $channel, $openid);
    if ($owner > 0 && $owner !== $bindUid) {
        redirect('user.php?err=' . urlencode('该' . $bindTitle . '账号已绑定到其他用户，请改用其他账号或在对应账号中解绑'));
    }
    if (uc_attach($conn, $bindUid, $channel, $openid, $nickname, $avatar)) {
        redirect('user.php?msg=' . urlencode($bindTitle . '绑定成功'));
    }
    redirect('user.php?err=' . urlencode($bindTitle . '绑定失败，请稍后重试'));
}

/* ---- 普通登录：按绑定归属找到账号，没有账号则自动注册并绑定 ---- */
$uid = uc_resolve_login($conn, $channel, $openid, $nickname, $avatar);
uc_login_log($conn, $channel, $openid, $nickname);
uc_set_session($conn, $uid, $channel, $openid, $nickname, $avatar);

redirect($success_url);
