<?php
header("Content-type:text/html;charset=utf-8");
$siteName = '惊霄科技';
$siteEmail = '3917698503@qq.com';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>使用条款 - <?php echo htmlspecialchars($siteName); ?></title>
<style>
    body{max-width:900px;margin:30px auto;padding:0 20px;font-family:-apple-system,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;line-height:1.8;color:#333;background:#f8fafc;}
    .card{background:#fff;padding:40px 50px;border-radius:14px;box-shadow:0 4px 24px rgba(0,0,0,.06);}
    h1{text-align:center;color:#0f172a;margin-top:0;}
    h3{color:#0f172a;margin-top:28px;}
    p{color:#475569;}
    .meta{text-align:center;color:#94a3b8;font-size:13px;margin-bottom:24px;}
</style>
</head>
<body>
<div class="card">
<h1>使用条款</h1>
<p class="meta">更新日期：2026年09月28日</p>
<h3>1. 服务说明</h3>
<p>本系统提供第三方账号聚合登录服务。您访问并使用本站登录功能，即表示您已阅读、理解并同意接受本条款全部内容。</p>
<h3>2. 用户责任</h3>
<p>您承诺不利用本站从事任何违反国家法律法规、危害网络安全的活动，包括但不限于恶意调用接口、暴力破解、数据抓取、传播违法信息。</p>
<h3>3. 账号安全</h3>
<p>您通过第三方 OAuth 授权登录本站，账号安全由对应第三方平台与您共同负责。因您自身原因导致账号泄露的，本站不承担责任。</p>
<h3>4. 服务变更与中断</h3>
<p>本站有权根据运营需要对服务进行维护、升级或调整，对此造成的临时访问中断，本站不承担赔偿责任，但会尽可能提前公告。</p>
<h3>5. 条款更新</h3>
<p>本条款可能不定期更新，更新后将在本页面公示。您继续使用本站服务即视为接受更新后的条款。</p>
<h3>6. 联系我们</h3>
<p>如有疑问，请联系邮箱：<?php echo htmlspecialchars($siteEmail); ?></p>
</div>
</body>
</html>
