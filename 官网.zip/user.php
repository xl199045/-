<?php
/**
 * 个人中心
 * 基本信息（用户名 / 邮箱 / 手机号 / 注册时间） + 修改密码 + 账号绑定（全部渠道 + QQ邮箱）
 * 账号体系见 inc/user.php；所有写操作走 user_action.php（AJAX，带 CSRF 校验）
 */
if (!file_exists(__DIR__ . '/config.php')) {
    header('Location: install/');
    exit;
}
require __DIR__ . '/config.php';

$user = uc_current_user($conn);
if (!$user) {
    // 会话存在但账号已不存在（如被删除）：清理会话再回登录页，避免来回跳转
    unset($_SESSION['user']);
    redirect('login.php');
}
$uid = (int)$user['id'];
$siteName = $systemConfig['site_name'] ?? '聚合登录';
$theme = $systemConfig['theme_color'] ?? '#22d3ee';
$shopUrl = trim((string)($systemConfig['shop_url'] ?? '')); // 后台「跳转设置 → 商城跳转网址」

$bindings = uc_bindings($conn, $uid);
$methodCount = count($bindings) + (!empty($user['password']) ? 1 : 0);
$meta = uc_channel_meta();
$icons = $meta['icons'];
$colors = $meta['colors'];

// 可绑定渠道：排除聚合平台入口（需先选二级登录方式，不参与绑定）
$enabledChannels = [];
$disabledChannels = [];
foreach ($channels as $c) {
    if ($c['name'] === 'juhe') continue;
    if ($c['enable'] == 1) $enabledChannels[] = $c;
    else $disabledChannels[] = $c;
}
// 渠道是否具备发起授权的条件（后台是否配好了凭证）
$juheReady = !empty($systemConfig['juhe_host']) && !empty($systemConfig['juhe_appid']) && !empty($systemConfig['juhe_appkey']);
$juheTypes = ['qq', 'wechat', 'alipay', 'weibo', 'baidu', 'douyin', 'huawei', 'google', 'microsoft',
    'wework', 'dingtalk', 'gitee', 'github', 'feishu', 'bilibili', 'xiaomi'];
$channelReady = function ($c) use ($juheReady, $juheTypes) {
    if (($c['mode'] ?? 0) == 1) {
        return $juheReady && in_array($c['name'], $juheTypes, true);
    }
    return trim((string)$c['appid']) !== '';
};

$emailBound = !empty($user['email']);
$phoneBound = !empty($user['phone']);
$msg = trim((string)($_GET['msg'] ?? ''));
$err = trim((string)($_GET['err'] ?? ''));
$csrf = uc_csrf_token();
$avatar = $user['avatar'] !== '' ? $user['avatar'] : '';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>个人中心 - <?php echo e($siteName); ?></title>
<link rel="stylesheet" href="assets/css/style.css?v=<?php echo @filemtime(__DIR__ . '/assets/css/style.css') ?: 1; ?>">
<style>:root{--tc:<?php echo e($theme); ?>}</style>
</head>
<body class="admin-body">

<nav class="nav">
    <div class="nav-logo"><?php echo e($siteName); ?></div>
    <div class="nav-menu">
        <a href="/">首页</a>
        <?php if ($shopUrl !== ''): ?><a href="<?php echo e($shopUrl); ?>" target="_blank" rel="noopener">商城</a><?php endif; ?>
        <a href="join.php">企业入驻</a>
        <a href="logout.php" class="link-danger">退出登录</a>
    </div>
</nav>

<div class="admin-layout">
    <aside class="admin-side">
        <a href="#profile" class="as-item active">基本信息</a>
        <a href="#password" class="as-item">修改密码</a>
        <a href="#bind" class="as-item">账号绑定 <span class="dim"><?php echo count($bindings); ?></span></a>
        <?php if ($shopUrl !== ''): ?>
        <a href="<?php echo e($shopUrl); ?>" target="_blank" rel="noopener" class="as-item">商城 ↗</a>
        <?php endif; ?>
        <a href="/" class="as-item">返回官网</a>
        <a href="logout.php" class="as-item">退出登录</a>

        <div class="uc-side-card">
            <span class="uc-avatar">
                <span class="uc-avatar-txt"><?php echo e(mb_substr($user['nickname'] !== '' ? $user['nickname'] : $user['username'], 0, 1)); ?></span>
                <?php if ($avatar !== ''): ?>
                <img src="<?php echo e($avatar); ?>" width="38" height="38" alt="头像" referrerpolicy="no-referrer" onerror="this.remove()">
                <?php endif; ?>
            </span>
            <div class="uc-side-info">
                <b><?php echo e($user['username']); ?></b>
                <small><?php echo $emailBound ? e($user['email']) : '未绑定邮箱'; ?></small>
            </div>
        </div>
    </aside>

    <div class="admin-main">
        <?php if ($msg !== ''): ?><p class="msg-ok"><?php echo e($msg); ?></p><?php endif; ?>
        <?php if ($err !== ''): ?><p class="msg-error"><?php echo e($err); ?></p><?php endif; ?>
        <p class="msg-ok" id="ucToast" style="display:none"></p>

        <!-- ===== 账号头部（头像与用户名同一行，头像 52px） ===== -->
        <div class="card glow-card uc-hero">
            <div class="uc-identity">
                <span class="uc-avatar">
                    <span class="uc-avatar-txt"><?php echo e(mb_substr($user['nickname'] !== '' ? $user['nickname'] : $user['username'], 0, 1)); ?></span>
                    <?php if ($avatar !== ''): ?>
                    <img src="<?php echo e($avatar); ?>" width="52" height="52" alt="头像" referrerpolicy="no-referrer" onerror="this.remove()">
                    <?php endif; ?>
                </span>
                <div class="uc-name">
                    <h1><span><?php echo e($user['nickname'] !== '' ? $user['nickname'] : $user['username']); ?></span><i class="uc-dot" title="已登录"></i></h1>
                    <p class="uc-sub">@<?php echo e($user['username']); ?> · UID <?php echo (int)$uid; ?></p>
                </div>
            </div>
            <div class="uc-stats">
                <div class="uc-stat"><b><?php echo count($bindings); ?></b><span>已绑定渠道</span></div>
                <div class="uc-stat"><b><?php echo (int)$methodCount; ?></b><span>可用登录方式</span></div>
                <div class="uc-stat"><b><?php echo e(date('Y-m-d', strtotime((string)$user['created_at']))); ?></b><span>注册时间</span></div>
            </div>
        </div>

        <div class="uc-grid2">
            <!-- ===== 基本信息 ===== -->
            <div class="card glow-card" id="profile">
                <h2>基本信息</h2>

                <div class="uc-row">
                    <label>用户名</label>
                    <div class="uc-inline-row">
                        <input type="text" id="ucUsername" value="<?php echo e($user['username']); ?>" maxlength="30" placeholder="登录用户名">
                        <button class="btn btn-primary btn-sm" id="saveProfileBtn">保存</button>
                    </div>
                </div>
                <div class="uc-row">
                    <label>昵称</label>
                    <div class="uc-inline-row">
                        <input type="text" id="ucNickname" value="<?php echo e($user['nickname']); ?>" maxlength="50" placeholder="显示昵称">
                    </div>
                </div>

                <div class="uc-row">
                    <label>邮箱</label>
                    <div class="uc-inline-row">
                        <input type="text" value="<?php echo $emailBound ? e($user['email']) : '未绑定'; ?>" disabled>
                        <button class="btn btn-primary btn-sm js-toggle" data-panel="emailPanel"><?php echo $emailBound ? '换绑' : '绑定'; ?></button>
                        <?php if ($emailBound): ?>
                        <button class="btn btn-ghost btn-sm js-unbind-email">解绑</button>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="uc-inline" id="emailPanel" style="display:none">
                    <div class="form-item">
                        <label>新 QQ 邮箱</label>
                        <input type="email" id="newEmail" placeholder="你的QQ号@qq.com" autocomplete="email">
                    </div>
                    <div class="form-item">
                        <label>验证码</label>
                        <div class="code-row">
                            <input type="text" id="emailCode" placeholder="6 位验证码" maxlength="6" inputmode="numeric">
                            <button type="button" class="btn btn-ghost btn-sm code-btn" id="sendEmailCodeBtn">获取验证码</button>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="button" class="btn btn-primary btn-sm" id="bindEmailBtn">确认绑定</button>
                        <button type="button" class="btn btn-ghost btn-sm js-toggle" data-panel="emailPanel">取消</button>
                    </div>
                    <p class="form-tip" id="emailTip">验证码将发送到新邮箱，用于确认邮箱归属。</p>
                </div>

                <div class="uc-row">
                    <label>手机号</label>
                    <div class="uc-inline-row">
                        <input type="text" value="<?php echo $phoneBound ? e($user['phone']) : '未绑定'; ?>" disabled>
                        <button class="btn btn-primary btn-sm js-toggle" data-panel="phonePanel"><?php echo $phoneBound ? '换绑' : '绑定'; ?></button>
                        <?php if ($phoneBound): ?>
                        <button class="btn btn-ghost btn-sm js-unbind-phone">解绑</button>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="uc-inline" id="phonePanel" style="display:none">
                    <div class="form-item">
                        <label>手机号</label>
                        <input type="text" id="newPhone" placeholder="11 位手机号" maxlength="11" inputmode="numeric">
                    </div>
                    <div class="form-item">
                        <label>验证码</label>
                        <div class="code-row">
                            <input type="text" id="phoneCode" placeholder="6 位验证码" maxlength="6" inputmode="numeric">
                            <button type="button" class="btn btn-ghost btn-sm code-btn" id="sendPhoneCodeBtn">获取验证码</button>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="button" class="btn btn-primary btn-sm" id="bindPhoneBtn">确认绑定</button>
                        <button type="button" class="btn btn-ghost btn-sm js-toggle" data-panel="phonePanel">取消</button>
                    </div>
                    <p class="form-tip" id="phoneTip">站点未接入短信通道，验证码发送到绑定邮箱<?php echo $emailBound ? '（' . e($user['email']) . '）' : '，请先绑定邮箱'; ?>。</p>
                </div>

                <div class="uc-row">
                    <label>注册时间</label>
                    <div class="uc-inline-row"><input type="text" value="<?php echo e($user['created_at']); ?>" disabled></div>
                </div>
                <div class="uc-row">
                    <label>上次登录</label>
                    <div class="uc-inline-row">
                        <input type="text" value="<?php echo e($user['last_login'] ?: '—'); ?> <?php echo $user['last_ip'] !== '' ? '（' . e($user['last_ip']) . '）' : ''; ?>" disabled>
                    </div>
                </div>
            </div>

            <!-- ===== 修改密码 ===== -->
            <div class="card glow-card" id="password">
                <h2>修改密码</h2>
                <?php if (empty($user['password'])): ?>
                <p class="form-tip" style="margin-bottom:14px">当前账号尚未设置密码，设置后可使用「用户名 + 密码」登录。</p>
                <?php endif; ?>
                <div class="form-item" id="oldPwdItem" style="<?php echo empty($user['password']) ? 'display:none' : ''; ?>">
                    <label>原密码</label>
                    <input type="password" id="oldPwd" autocomplete="current-password" placeholder="当前密码">
                </div>
                <div class="form-item">
                    <label>新密码</label>
                    <input type="password" id="newPwd" autocomplete="new-password" placeholder="至少 6 位">
                </div>
                <div class="form-item">
                    <label>确认新密码</label>
                    <input type="password" id="confirmPwd" autocomplete="new-password" placeholder="再次输入新密码">
                </div>
                <button type="button" class="btn btn-primary btn-block" id="changePwdBtn"><?php echo empty($user['password']) ? '设置密码' : '修改密码'; ?></button>
                <p class="form-tip" id="pwdTip">密码用于在登录页「账号密码登录」中登录。</p>
            </div>
        </div>

        <!-- ===== 账号绑定 ===== -->
        <div class="card glow-card" id="bind">
            <div class="uc-bind-head">
                <h2>账号绑定</h2>
                <span class="dim">绑定第三方账号后，可使用该账号快速登录；解绑前请确保仍有其他登录方式。</span>
            </div>

            <div class="bind-grid">
                <!-- QQ 邮箱 -->
                <div class="bind-card <?php echo $emailBound ? 'is-bound' : ''; ?>">
                    <span class="bind-icon" style="background:<?php echo e($colors['email']); ?>"><?php echo e($icons['email']); ?></span>
                    <div class="bind-info">
                        <b>QQ 邮箱</b>
                        <small><?php echo $emailBound ? '已绑定 · ' . e($user['email']) : '未绑定'; ?></small>
                    </div>
                    <div class="bind-act">
                        <button class="btn btn-sm btn-primary js-toggle" data-panel="emailPanel"><?php echo $emailBound ? '换绑' : '绑定'; ?></button>
                        <?php if ($emailBound): ?>
                        <button class="btn btn-sm btn-danger js-unbind-email">解绑</button>
                        <?php endif; ?>
                    </div>
                </div>

                <?php foreach ($enabledChannels as $c):
                    $name = $c['name'];
                    $bound = isset($bindings[$name]);
                    $ready = $channelReady($c);
                ?>
                <div class="bind-card <?php echo $bound ? 'is-bound' : ''; ?>">
                    <span class="bind-icon" style="background:<?php echo e($colors[$name] ?? '#22d3ee'); ?>"><?php echo e($icons[$name] ?? '登'); ?></span>
                    <div class="bind-info">
                        <b><?php echo e($c['title']); ?></b>
                        <small>
                            <?php if ($bound): ?>
                                已绑定 · <?php echo e($bindings[$name]['nickname'] !== '' ? $bindings[$name]['nickname'] : $bindings[$name]['openid']); ?>
                            <?php else: ?>
                                未绑定
                            <?php endif; ?>
                        </small>
                    </div>
                    <div class="bind-act">
                        <?php if ($bound): ?>
                        <button class="btn btn-sm btn-danger js-unbind" data-channel="<?php echo e($name); ?>" data-title="<?php echo e($c['title']); ?>">解绑</button>
                        <?php elseif ($ready): ?>
                        <a class="btn btn-sm btn-ghost" href="callback.php?channel=<?php echo e($name); ?>&amp;bind=1">绑定</a>
                        <?php else: ?>
                        <span class="dim bind-note">后台未配置凭证</span>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>

                <?php foreach ($disabledChannels as $c): ?>
                <div class="bind-card is-off">
                    <span class="bind-icon" style="background:#334155"><?php echo e($icons[$c['name']] ?? '登'); ?></span>
                    <div class="bind-info">
                        <b><?php echo e($c['title']); ?></b>
                        <small>后台未开启</small>
                    </div>
                    <div class="bind-act"><span class="dim bind-note">—</span></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<script>
window.UC = { csrf: '<?php echo e($csrf); ?>', url: 'user_action.php' };
</script>
<script src="assets/js/user.js?v=<?php echo @filemtime(__DIR__ . '/assets/js/user.js') ?: 1; ?>"></script>
</body>
</html>
