<?php
/**
 * 音乐模式接口：随机返回 assets/music/ 文件夹中的 MP3 列表
 * 使用：把 MP3 文件放入 assets/music/ 目录即可，前台播放器自动随机播放
 */
if (!file_exists(__DIR__ . '/config.php')) {
    header('Location: install/');
    exit;
}
require __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');
$dir = __DIR__ . '/assets/music';
$files = is_dir($dir) ? glob($dir . '/*.mp3') : [];
$list = [];
foreach ($files as $f) {
    $list[] = 'assets/music/' . basename($f);
}
shuffle($list); // 随机顺序
echo json_encode(['total' => count($list), 'files' => $list], JSON_UNESCAPED_SLASHES);
