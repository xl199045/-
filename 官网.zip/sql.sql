-- ============================================================
-- PHP 聚合登录系统 数据库初始化脚本
-- 说明：本脚本不含 CREATE DATABASE / USE（由 /install/ 向导负责建库选库）
-- 支持 12 种聚合登录渠道：GitHub / Gitee / 支付宝 / QQ / 微信 / 微博 /
--                        百度 / 钉钉 / 抖音 / 飞书 / 开源中国 / Coding
-- ============================================================

-- 系统配置表（登录背景、成功跳转、主题色、站点名等）
CREATE TABLE IF NOT EXISTS `system_config` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `key_name` VARCHAR(100) NOT NULL UNIQUE,
  `value` TEXT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- OAuth 登录渠道配置表
CREATE TABLE IF NOT EXISTS `oauth_channels` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL UNIQUE COMMENT '渠道标识',
  `title` VARCHAR(100) NOT NULL COMMENT '显示名称',
  `enable` TINYINT(1) DEFAULT 0 COMMENT '0关闭 1开启',
  `appid` VARCHAR(255) DEFAULT '' COMMENT '应用AppID/ClientId',
  `appsecret` VARCHAR(255) DEFAULT '' COMMENT '密钥/私钥',
  `redirect_uri` VARCHAR(255) DEFAULT '' COMMENT '回调地址',
  `mode` TINYINT(1) DEFAULT 0 COMMENT '0直连官方OAuth 1对接聚合平台',
  `sort` INT DEFAULT 0 COMMENT '排序'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 管理员表（role：super=超级管理员 sub=分管理员；perms 为分管理员可访问模块 JSON）
CREATE TABLE IF NOT EXISTS `admin_user` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL COMMENT 'password_hash（兼容历史 MD5，登录后自动升级）',
  `role` VARCHAR(20) NOT NULL DEFAULT 'sub' COMMENT 'super=超级管理员 sub=分管理员',
  `perms` TEXT NULL COMMENT '分管理员可访问模块JSON',
  `status` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '1启用 0停用',
  `remark` VARCHAR(200) NOT NULL DEFAULT '' COMMENT '备注',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '加入时间',
  `last_login` DATETIME DEFAULT NULL,
  `last_ip` VARCHAR(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 第三方登录用户表
CREATE TABLE IF NOT EXISTS `oauth_users` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `channel` VARCHAR(50) NOT NULL,
  `openid` VARCHAR(255) NOT NULL,
  `nickname` VARCHAR(100) DEFAULT '',
  `avatar` VARCHAR(255) DEFAULT '',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uk_channel_openid` (`channel`,`openid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 登录日志表（后台用户情况 / 概览统计）
CREATE TABLE IF NOT EXISTS `login_logs` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `channel` VARCHAR(50) NOT NULL,
  `openid` VARCHAR(255) DEFAULT '',
  `nickname` VARCHAR(100) DEFAULT '',
  `ip` VARCHAR(64) DEFAULT '',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 初始化全部聚合登录渠道（默认全部开启，前台登录页直接显示；mode=0 直连官方，配好惊霄凭证后可一键切聚合）
INSERT INTO `oauth_channels` (`name`,`title`,`enable`,`appid`,`appsecret`,`redirect_uri`,`sort`) VALUES
('github',  'GitHub登录',   1, '', '', '', 1),
('gitee',   'Gitee登录',    1, '', '', '', 2),
('alipay',  '支付宝登录',   1, '', '', '', 3),
('qq',      'QQ登录',       1, '', '', '', 4),
('wechat',  '微信扫码登录', 1, '', '', '', 5),
('weibo',   '微博登录',     1, '', '', '', 6),
('baidu',   '百度登录',     1, '', '', '', 7),
('dingtalk','钉钉登录',     1, '', '', '', 8),
('douyin',  '抖音登录',     1, '', '', '', 9),
('feishu',  '飞书登录',     1, '', '', '', 10),
('oschina', '开源中国登录', 1, '', '', '', 11),
('coding',  'Coding登录',  1, '', '', '', 12),
('huawei',   '华为登录',     1, '', '', '', 13),
('google',   '谷歌登录',     1, '', '', '', 14),
('microsoft','微软登录',     1, '', '', '', 15),
('wework',   '企业微信登录', 1, '', '', '', 16),
('xiaomi',   '小米登录',     1, '', '', '', 17),
('bilibili', '哔哩哔哩登录', 1, '', '', '', 18),
('gitlab',   'GitLab登录',   1, '', '', '', 19),
('twitter',  'X(Twitter)登录',1, '', '', '', 20),
('facebook', 'Facebook登录', 1, '', '', '', 21),
('discord',  'Discord登录',  1, '', '', '', 22),
('line',     'LINE登录',     1, '', '', '', 23),
('linkedin', '领英登录',     1, '', '', '', 24),
('qihoo',    '360登录',      1, '', '', '', 25),
('douban',   '豆瓣登录',     1, '', '', '', 26),
('netease',  '网易登录',     1, '', '', '', 27),
('taobao',   '淘宝登录',     1, '', '', '', 28),
('juhe',     '聚合平台登录', 1, '', '', '', 29);

-- 初始化系统配置
INSERT INTO `system_config` (`key_name`,`value`) VALUES
('login_bg',         ''),
('success_redirect', '/'),
('theme_color',      '#22d3ee'),
('site_name',        '聚合登录'),
('juhe_host',        ''),
('juhe_appid',       ''),
('juhe_appkey',      '');

-- 默认超级管理员账号 admin / 123456（安装向导中可自定义；首次登录后密码自动升级为 password_hash）
INSERT INTO `admin_user` (`username`,`password`,`role`) VALUES ('admin', MD5('123456'), 'super');

-- ============================================================
-- 产品表（前台产品展示，后台可增删改）
-- ============================================================
CREATE TABLE IF NOT EXISTS `products` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `name` VARCHAR(200) NOT NULL COMMENT '产品名称',
  `description` TEXT COMMENT '产品描述',
  `price` VARCHAR(50) DEFAULT '' COMMENT '价格文案（如 ￥99 / 免费 / 定制）',
  `image` VARCHAR(255) DEFAULT '' COMMENT '图片路径或URL',
  `status` TINYINT(1) DEFAULT 1 COMMENT '1展示 0隐藏',
  `sort` INT DEFAULT 0 COMMENT '排序',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 合作企业表（前台展示 status=1；后台可添加/删除/审核）
-- status: 0 待审核(入驻申请) / 1 展示 / 2 隐藏(拒绝)
-- ============================================================
CREATE TABLE IF NOT EXISTS `companies` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `name` VARCHAR(200) NOT NULL COMMENT '公司/企业名称',
  `email` VARCHAR(200) DEFAULT '' COMMENT '联系邮箱',
  `website` VARCHAR(255) DEFAULT '' COMMENT '企业网址',
  `logo` VARCHAR(255) DEFAULT '' COMMENT 'Logo图片',
  `status` TINYINT(1) DEFAULT 0 COMMENT '0待审核 1展示 2隐藏',
  `sort` INT DEFAULT 0 COMMENT '排序',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 示例产品（仅新安装时插入，后台可修改/删除）
INSERT INTO `products` (`name`,`description`,`price`,`image`,`status`,`sort`) VALUES
('聚合登录企业版', '私有化部署，全渠道聚合登录，专属客服支持。', '￥1999/年', '', 1, 1),
('聚合登录开源版', 'MIT 开源，PHP + MySQL，宝塔一键部署。', '免费', '', 1, 2);
