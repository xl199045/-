<?php
/**
 * 个人中心接口（AJAX，返回 JSON）
 *
 * 动作一览：
 *   login            账号密码登录（用户名为账号 / 邮箱也可）
 *   save_profile     保存用户名、昵称
 *   send_email_code  发送邮箱验证码（绑定 / 换绑 QQ 邮箱）
 *   bind_email       校验验证码并绑定 / 换绑邮箱
 *   unbind_email     解绑邮箱
 *   send_phone_code  发送手机号验证码（当前无短信通道，验证码发送到绑定邮箱）
 *   bind_phone       校验验证码并绑定手机号
 *   unbind_phone     解绑手机号
 *   change_password  修改 / 设置密码
 *   unbind           解绑第三方渠道
 */
if (!file_exists(__DIR__ . '/config.php')) {
    header('Location: install/');
    exit;
}
require __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');

function param($key, $default = '')
{
    if (isset($_POST[$key])) return is_string($_POST[$key]) ? trim($_POST[$key]) : $_POST[$key];
    if (isset($_GET[$key])) return is_string($_GET[$key]) ? trim($_GET[$key]) : $_GET[$key];
    return $default;
}

function out($ok, $msg, $extra = [])
{
    echo json_encode(array_merge(['ok' => (bool)$ok, 'msg' => $msg], $extra), JSON_UNESCAPED_UNICODE);
    exit;
}

$action = param('action');
$smtpCfg = [
    'smtp_host' => $systemConfig['smtp_host'] ?? '',
    'smtp_port' => $systemConfig['smtp_port'] ?? '',
    'smtp_user' => $systemConfig['smtp_user'] ?? '',
    'smtp_pass' => $systemConfig['smtp_pass'] ?? '',
    'smtp_from' => $systemConfig['smtp_from'] ?? '',
    'site_name' => $systemConfig['site_name'] ?? '聚合登录',
];

/* ==================== 账号密码登录（免登录） ==================== */
if ($action === 'login') {
    $account = param('account');
    $password = (string)param('password');
    if ($account === '' || $password === '') out(false, '请输入账号和密码');

    $fails = (int)($_SESSION['login_fails'] ?? 0);
    if ($fails >= 5 && time() - (int)($_SESSION['login_fail_time'] ?? 0) < 300) {
        out(false, '密码错误次数过多，请 5 分钟后再试');
    }

    $esc = mysqli_real_escape_string($conn, $account);
    $res = mysqli_query($conn, "SELECT * FROM `users` WHERE `username` = '{$esc}' LIMIT 1");
    $row = ($res && ($r = mysqli_fetch_assoc($res))) ? $r : uc_user_by_email($conn, $account);

    if (!$row || empty($row['password']) || !password_verify($password, $row['password'])) {
        $_SESSION['login_fails'] = $fails + 1;
        $_SESSION['login_fail_time'] = time();
        out(false, '账号或密码错误');
    }

    unset($_SESSION['login_fails'], $_SESSION['login_fail_time']);
    uc_login_log($conn, 'password', $row['username'], $row['nickname'] !== '' ? $row['nickname'] : $row['username']);
    uc_set_session($conn, $row['id'], 'password', $row['username'], $row['nickname'], $row['avatar']);
    $success_url = !empty($systemConfig['success_redirect']) ? $systemConfig['success_redirect'] : 'user.php';
    out(true, '登录成功', ['redirect' => $success_url]);
}

/* ==================== 以下动作均需登录 ==================== */
$user = uc_current_user($conn);
if (!$user) out(false, '登录状态已失效，请重新登录', ['redirect' => 'login.php']);
$uid = (int)$user['id'];

if (!uc_check_csrf((string)param('csrf'))) {
    out(false, '会话校验失败，请刷新页面后重试');
}

switch ($action) {

    /* ---------- 保存用户名 / 昵称 ---------- */
    case 'save_profile':
        $username = param('username');
        $nickname = param('nickname');
        if ($username === '' && $nickname === '') out(false, '请填写用户名或昵称');
        if ($username !== '') {
            if (!preg_match('/^[\w\x{4e00}-\x{9fa5}.\-]{2,30}$/u', $username)) {
                out(false, '用户名需 2-30 位，仅支持中英文、数字、下划线、点、短横线');
            }
            $uEsc = mysqli_real_escape_string($conn, $username);
            $res = mysqli_query($conn, "SELECT id FROM `users` WHERE `username` = '{$uEsc}' AND id <> {$uid} LIMIT 1");
            if ($res && mysqli_num_rows($res) > 0) out(false, '该用户名已被占用');
            mysqli_query($conn, "UPDATE `users` SET `username` = '{$uEsc}' WHERE id = {$uid}");
            if (($_SESSION['user']['channel'] ?? '') === 'password') $_SESSION['user']['openid'] = $username;
        }
        if ($nickname !== '') {
            $nEsc = mysqli_real_escape_string($conn, mb_substr($nickname, 0, 50));
            mysqli_query($conn, "UPDATE `users` SET `nickname` = '{$nEsc}' WHERE id = {$uid}");
            $_SESSION['user']['nickname'] = mb_substr($nickname, 0, 50);
        }
        out(true, '资料已保存');

    /* ---------- 绑定 / 换绑邮箱（QQ邮箱） ---------- */
    case 'send_email_code':
        $email = strtolower(param('email'));
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) out(false, '邮箱格式不正确');
        if (substr($email, -7) !== '@qq.com') out(false, '目前仅支持 QQ 邮箱（@qq.com）');
        if ($email === strtolower((string)$user['email'])) out(false, '该邮箱已是当前绑定邮箱');
        $other = uc_user_by_email($conn, $email);
        if ($other && (int)$other['id'] !== $uid) out(false, '该邮箱已被其他账号绑定');
        $scene = empty($user['email']) ? 'bind_email' : 'change_email';
        $sent = uc_send_code($conn, $email, $scene, $smtpCfg);
        if ($sent !== true) out(false, $sent);
        out(true, '验证码已发送到 ' . $email . '，10 分钟内有效');

    case 'bind_email':
        $email = strtolower(param('email'));
        $code = param('code');
        if ($email === '' || $code === '') out(false, '请输入邮箱和验证码');
        if (substr($email, -7) !== '@qq.com') out(false, '目前仅支持 QQ 邮箱（@qq.com）');
        $other = uc_user_by_email($conn, $email);
        if ($other && (int)$other['id'] !== $uid) out(false, '该邮箱已被其他账号绑定');
        $scene = empty($user['email']) ? 'bind_email' : 'change_email';
        if (!uc_check_code($conn, $email, $code, $scene)) out(false, '验证码错误或已过期');
        $oldEmail = (string)$user['email'];
        $eEsc = mysqli_real_escape_string($conn, $email);
        if (!mysqli_query($conn, "UPDATE `users` SET `email` = '{$eEsc}' WHERE id = {$uid}")) {
            out(false, '绑定失败：' . mysqli_error($conn));
        }
        // 邮箱登录渠道绑定同步更新（同一时刻只保留一个邮箱）
        if ($oldEmail !== '' && strtolower($oldEmail) !== $email) uc_detach($conn, $uid, 'email');
        uc_attach($conn, $uid, 'email', $email, explode('@', $email)[0], '');
        out(true, $oldEmail === '' ? '邮箱绑定成功' : '邮箱换绑成功，下次可用新邮箱接收验证码登录');

    case 'unbind_email':
        if (empty($user['email'])) out(false, '当前未绑定邮箱');
        if (uc_login_methods($conn, $uid) <= 1) out(false, '至少需要保留一种登录方式，请先设置密码或绑定其他渠道');
        mysqli_query($conn, "UPDATE `users` SET `email` = NULL WHERE id = {$uid}");
        uc_detach($conn, $uid, 'email');
        out(true, '邮箱已解绑');

    /* ---------- 绑定 / 解绑手机号 ---------- */
    case 'send_phone_code':
        $phone = param('phone');
        if (!preg_match('/^1[3-9]\d{9}$/', $phone)) out(false, '请输入正确的 11 位手机号');
        $other = uc_user_by_phone($conn, $phone);
        if ($other && (int)$other['id'] !== $uid) out(false, '该手机号已被其他账号绑定');
        if (empty($user['email'])) out(false, '请先绑定邮箱，验证码将发送到该邮箱');
        $sent = uc_send_code($conn, $user['email'], 'bind_phone', $smtpCfg);
        if ($sent !== true) out(false, $sent);
        out(true, '验证码已发送到绑定邮箱 ' . $user['email'] . '，10 分钟内有效');

    case 'bind_phone':
        $phone = param('phone');
        $code = param('code');
        if (!preg_match('/^1[3-9]\d{9}$/', $phone)) out(false, '请输入正确的 11 位手机号');
        if ($code === '') out(false, '请输入验证码');
        $other = uc_user_by_phone($conn, $phone);
        if ($other && (int)$other['id'] !== $uid) out(false, '该手机号已被其他账号绑定');
        if (empty($user['email'])) out(false, '请先绑定邮箱，验证码将发送到该邮箱');
        if (!uc_check_code($conn, $user['email'], $code, 'bind_phone')) out(false, '验证码错误或已过期');
        $pEsc = mysqli_real_escape_string($conn, $phone);
        mysqli_query($conn, "UPDATE `users` SET `phone` = '{$pEsc}' WHERE id = {$uid}");
        out(true, '手机号绑定成功');

    case 'unbind_phone':
        if (empty($user['phone'])) out(false, '当前未绑定手机号');
        mysqli_query($conn, "UPDATE `users` SET `phone` = NULL WHERE id = {$uid}");
        out(true, '手机号已解绑');

    /* ---------- 修改 / 设置密码 ---------- */
    case 'change_password':
        $old = (string)param('old_password');
        $new = (string)param('new_password');
        $confirm = (string)param('confirm_password');
        if (mb_strlen($new) < 6) out(false, '新密码至少 6 位');
        if ($new !== $confirm) out(false, '两次输入的新密码不一致');
        if (!empty($user['password'])) {
            if ($old === '') out(false, '请输入原密码');
            if (!password_verify($old, $user['password'])) out(false, '原密码错误');
        }
        $hash = password_hash($new, PASSWORD_DEFAULT);
        $hEsc = mysqli_real_escape_string($conn, $hash);
        if (!mysqli_query($conn, "UPDATE `users` SET `password` = '{$hEsc}' WHERE id = {$uid}")) {
            out(false, '修改失败：' . mysqli_error($conn));
        }
        out(true, empty($user['password']) ? '密码设置成功，可用用户名 + 密码登录' : '密码修改成功');

    /* ---------- 解绑第三方渠道 ---------- */
    case 'unbind':
        $channel = param('channel');
        if ($channel === '') out(false, '缺少渠道参数');
        if ($channel === 'email') out(false, '邮箱请在「基本信息」中解绑');
        if (empty($channels[$channel])) out(false, '渠道不存在');
        $bindings = uc_bindings($conn, $uid);
        if (empty($bindings[$channel])) out(false, '该渠道尚未绑定');
        if (uc_login_methods($conn, $uid) <= 1) out(false, '至少需要保留一种登录方式，请先设置密码或绑定其他渠道');
        uc_detach($conn, $uid, $channel);
        out(true, ($channels[$channel]['title'] ?? $channel) . ' 已解绑');

    default:
        out(false, '无效请求');
}
