<?php
/**
 * 企业入驻申请提交（写入 companies，status=0 待审核）
 */
require __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: join.php');
    exit;
}

$name = mysqli_real_escape_string($conn, trim($_POST['name'] ?? ''));
$email = mysqli_real_escape_string($conn, trim($_POST['email'] ?? ''));
$website = mysqli_real_escape_string($conn, trim($_POST['website'] ?? ''));

if ($name === '' || $email === '') {
    echo "<script>alert('企业名称和邮箱不能为空');history.back();</script>";
    exit;
}

// 同一企业重复申请：仅更新申请信息
$exists = mysqli_query($conn, "SELECT id FROM companies WHERE name='$name' LIMIT 1");
if ($exists && mysqli_num_rows($exists) > 0) {
    mysqli_query($conn, "UPDATE companies SET email='$email', website='$website', status=0 WHERE name='$name'");
} else {
    mysqli_query($conn, "INSERT INTO companies (name, email, website, status) VALUES ('$name', '$email', '$website', 0)");
}

echo "<script>alert('申请提交成功，请等待管理员审核');location.href='./';</script>";
