<?php
/**
 * 合作企业保存：新增 / 更新 / 删除 / 状态切换（通过/拒绝/隐藏）
 */
require __DIR__ . '/../config.php';
admin_guard($conn, 'companies'); // 需「合作企业」权限

$act = $_GET['act'] ?? ($_POST['act'] ?? '');

/* ===== 删除 ===== */
if ($act === 'delete') {
    $id = (int)($_GET['id'] ?? 0);
    if ($id) mysqli_query($conn, "DELETE FROM companies WHERE id=$id");
    redirect('companies.php');
}

/* ===== 状态切换 ===== */
if ($act === 'status') {
    $id = (int)($_GET['id'] ?? 0);
    $status = (int)($_GET['status'] ?? 0);
    if ($id) mysqli_query($conn, "UPDATE companies SET status=$status WHERE id=$id");
    redirect('companies.php');
}

/* ===== 保存（新增/更新） ===== */
if ($act === 'save') {
    $id = (int)($_POST['id'] ?? 0);
    $name = mysqli_real_escape_string($conn, trim($_POST['name'] ?? ''));
    if ($name === '') {
        redirect('companies.php?msg=' . urlencode('企业名称不能为空'));
    }
    $email = mysqli_real_escape_string($conn, trim($_POST['email'] ?? ''));
    $website = mysqli_real_escape_string($conn, trim($_POST['website'] ?? ''));
    $logo = mysqli_real_escape_string($conn, trim($_POST['logo'] ?? ''));
    $sort = (int)($_POST['sort'] ?? 0);
    $status = (int)($_POST['status'] ?? 0);

    if ($id) {
        mysqli_query($conn, "UPDATE companies SET name='$name', email='$email', website='$website', logo='$logo', status=$status, sort=$sort WHERE id=$id");
    } else {
        mysqli_query($conn, "INSERT INTO companies (name, email, website, logo, status, sort) VALUES ('$name', '$email', '$website', '$logo', $status, $sort)");
    }
    redirect('companies.php');
}

redirect('companies.php');
