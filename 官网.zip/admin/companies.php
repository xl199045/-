<?php
/**
 * 合作企业管理：列表 + 新增 / 编辑（与产品同样的管理模式）
 */
require __DIR__ . '/../config.php';
admin_guard($conn, 'companies'); // 需「合作企业」权限

$editId = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;
$edit = null;
if ($editId) {
    $res = mysqli_query($conn, "SELECT * FROM companies WHERE id=$editId LIMIT 1");
    $edit = mysqli_fetch_assoc($res);
}

$list = mysqli_query($conn, "SELECT * FROM companies ORDER BY sort ASC, id DESC");
$count = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM companies"))[0];
$showCount = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM companies WHERE status=1"))[0];
$pendingCount = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM companies WHERE status=0"))[0];
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>合作企业管理 - 惊霄科技官网系统</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="admin-body">

<nav class="nav">
    <div class="nav-logo">惊霄科技官网 · 后台</div>
    <div class="nav-menu">
        <a href="index.php">后台首页</a>
        <a href="../">前台首页</a>
        <a href="logout.php" class="link-danger">退出登录</a>
    </div>
</nav>

<div class="admin-layout">
    <aside class="admin-side">
        <a href="index.php" class="as-item">概览</a>
        <a href="products.php" class="as-item">产品管理</a>
        <a href="companies.php" class="as-item active">合作企业</a>
        <a href="index.php?tab=platforms" class="as-item">渠道管理</a>
        <a href="index.php?tab=appearance" class="as-item">登录页设置</a>
        <a href="index.php?tab=smtp" class="as-item">邮箱设置</a>
        <a href="index.php?tab=redirect" class="as-item">跳转设置</a>
        <a href="index.php?tab=admin" class="as-item">管理员</a>
    </aside>

    <div class="admin-main">
        <div class="admin-head">
            <h1>合作企业</h1>
            <span class="badge">共 <?php echo (int)$count; ?> 家 · 前台展示 <?php echo (int)$showCount; ?> 家<?php echo $pendingCount > 0 ? ' · 待审核 ' . $pendingCount . ' 家' : ''; ?></span>
        </div>

        <!-- 新增 / 编辑表单 -->
        <div class="ad-panel">
            <h3><?php echo $edit ? '编辑企业：' . e($edit['name']) : '新增合作企业'; ?></h3>
            <form method="post" action="companies_save.php" enctype="multipart/form-data">
                <input type="hidden" name="act" value="save">
                <input type="hidden" name="id" value="<?php echo $edit ? (int)$edit['id'] : 0; ?>">
                <div class="setup-grid">
                    <div>
                        <div class="form-item"><label>企业名称 *</label><input type="text" name="name" required value="<?php echo $edit ? e($edit['name']) : ''; ?>" placeholder="公司 / 企业名称"></div>
                        <div class="form-item"><label>联系邮箱</label><input type="text" name="email" value="<?php echo $edit ? e($edit['email']) : ''; ?>" placeholder="contact@example.com"></div>
                        <div class="form-item"><label>企业网址（点击跳转）</label><input type="text" name="website" value="<?php echo $edit ? e($edit['website']) : ''; ?>" placeholder="https://example.com"></div>
                    </div>
                    <div>
                        <div class="form-item"><label>排序（越小越靠前）</label><input type="text" name="sort" value="<?php echo $edit ? (int)$edit['sort'] : 0; ?>"></div>
                        <div class="form-item"><label>状态</label>
                            <select name="status">
                                <option value="0" <?php echo ($edit && $edit['status'] == 0) ? 'selected' : ''; ?>>待审核</option>
                                <option value="1" <?php echo ($edit && $edit['status'] == 1) ? 'selected' : ''; ?>>展示（审核通过）</option>
                                <option value="2" <?php echo ($edit && $edit['status'] == 2) ? 'selected' : ''; ?>>隐藏（拒绝）</option>
                            </select>
                        </div>
                        <div class="form-item"><label>Logo 图片地址（可选）</label><input type="text" name="logo" value="<?php echo $edit ? e($edit['logo']) : ''; ?>" placeholder="https://... 或 assets/uploads/xxx.png"></div>
                    </div>
                </div>
                <div class="form-actions">
                    <a class="btn btn-ghost" href="companies.php">取消</a>
                    <button class="btn btn-primary" type="submit"><?php echo $edit ? '保存修改' : '添加企业'; ?></button>
                </div>
            </form>
        </div>

        <!-- 企业列表 -->
        <div class="ad-panel">
            <h3>企业列表</h3>
            <table class="log-table">
                <thead><tr><th>ID</th><th>名称</th><th>邮箱</th><th>网址</th><th>状态</th><th>排序</th><th>操作</th></tr></thead>
                <tbody>
                <?php while ($c = mysqli_fetch_assoc($list)): ?>
                <tr>
                    <td><?php echo (int)$c['id']; ?></td>
                    <td><?php echo e($c['name']); ?></td>
                    <td><?php echo e($c['email']); ?></td>
                    <td><?php echo e($c['website']); ?></td>
                    <td>
                        <?php
                        if ($c['status'] == 0) echo '<span class="pending-tag">待审核</span>';
                        elseif ($c['status'] == 1) echo '<span class="ok-tag">展示中</span>';
                        else echo '<span class="no-tag">已隐藏</span>';
                        ?>
                    </td>
                    <td><?php echo (int)$c['sort']; ?></td>
                    <td class="ops">
                        <a class="btn btn-sm" href="companies.php?edit=<?php echo (int)$c['id']; ?>">编辑</a>
                        <?php if ($c['status'] == 0): ?>
                        <a class="btn btn-sm btn-success" href="companies_save.php?act=status&id=<?php echo (int)$c['id']; ?>&status=1">通过</a>
                        <a class="btn btn-sm btn-danger" href="companies_save.php?act=status&id=<?php echo (int)$c['id']; ?>&status=2">拒绝</a>
                        <?php else: ?>
                        <a class="btn btn-sm btn-ghost" href="companies_save.php?act=status&id=<?php echo (int)$c['id']; ?>&status=<?php echo $c['status'] == 1 ? 0 : 1; ?>"><?php echo $c['status'] == 1 ? '撤回' : '展示'; ?></a>
                        <?php endif; ?>
                        <a class="btn btn-sm btn-danger" href="companies_save.php?act=delete&id=<?php echo (int)$c['id']; ?>" onclick="return confirm('确定删除该企业？')">删除</a>
                    </td>
                </tr>
                <?php endwhile; ?>
                <?php if ($count == 0): ?>
                <tr><td colspan="7" class="dim">暂无合作企业，可在上方添加，或等待前台入驻申请。</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="../assets/js/main.js"></script>
</body>
</html>
