<?php
/**
 * 后台配置保存：渠道 / 系统 / 邮箱 / 密码
 */
require __DIR__ . '/../config.php';
require_once __DIR__ . '/../inc/license.php';
$admin = admin_guard($conn); // 未登录跳登录页；停用账号自动退出

$type = $_GET['type'] ?? '';

/** 当前保存动作所需的模块权限，不足直接拒绝（避免分管理员直接调接口越权） */
function need_module($admin, $module)
{
    if (!admin_can($admin, $module)) {
        $map = admin_module_map();
        admin_deny('当前账号没有「' . ($map[$module] ?? $module) . '」模块的操作权限');
    }
}

/* ===== 一键开启：批量切换对接方式（聚合 / 直连） ===== */
if ($type === 'batch') {
    need_module($admin, 'platforms');
    $mode = ($_POST['mode'] ?? 'direct') === 'juhe' ? 1 : 0;
    // 惊霄聚合平台实际支持的 16 个渠道（以惊霄 platforms.php 为准）
    $juheList = ['qq','wechat','alipay','weibo','baidu','douyin','huawei','google','microsoft','wework','dingtalk','gitee','github','feishu','bilibili','xiaomi'];
    foreach ($juheList as $n) {
        mysqli_query($conn, "UPDATE oauth_channels SET mode=$mode WHERE name='$n'");
    }
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'code' => 0,
        'msg'  => $mode == 1 ? '一键开启完成：全部渠道已切换为「对接聚合平台」' : '一键切换完成：全部渠道已恢复「直连官方 OAuth」',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

/* ===== 渠道管理 ===== */
if ($type === 'channel') {
    need_module($admin, 'platforms');
    $names = $_POST['name'] ?? [];
    $titles = $_POST['title'] ?? [];
    $sorts = $_POST['sort'] ?? [];
    $appids = $_POST['appid'] ?? [];
    $appsecrets = $_POST['appsecret'] ?? [];
    $redirects = $_POST['redirect_uri'] ?? [];
    $enables = $_POST['enable'] ?? [];
    $modes = $_POST['mode'] ?? [];

    foreach ($names as $i => $name) {
        $name = mysqli_real_escape_string($conn, $name);
        $title = mysqli_real_escape_string($conn, trim($titles[$i] ?? ''));
        $sort = (int)($sorts[$i] ?? 0);
        $mode = (int)($modes[$i] ?? 0);
        // 企业微信：CorpID 与 AgentID 分字段，保存时拼为 "CorpID|AgentId"
        if ($name === 'wework') {
            $corp = mysqli_real_escape_string($conn, trim($_POST['wework_corpid'] ?? ''));
            $agent = mysqli_real_escape_string($conn, trim($_POST['wework_agentid'] ?? ''));
            $appid = ($corp !== '' && $agent !== '') ? $corp . '|' . $agent : $corp;
        } else {
            // appid 表单字段以渠道名作键（wework 用 CorpID/AgentID 单独字段）：
            // 不能按数字下标取值，否则 wework 之后的渠道会串位拿到相邻渠道的 AppID
            $appid = mysqli_real_escape_string($conn, trim($appids[$name] ?? ''));
        }
        $appsecret = mysqli_real_escape_string($conn, trim($appsecrets[$i] ?? ''));
        $redirect = mysqli_real_escape_string($conn, trim($redirects[$i] ?? ''));
        $enable = isset($enables[$name]) ? 1 : 0;
        mysqli_query($conn, "UPDATE oauth_channels SET title='$title', enable=$enable, appid='$appid', appsecret='$appsecret', redirect_uri='$redirect', mode=$mode, sort=$sort WHERE name='$name'");
    }
    redirect('index.php?tab=platforms&msg=' . urlencode('渠道设置已保存'));
}

/* ===== 系统 / 跳转设置 ===== */
if ($type === 'system') {
    // 按提交内容判断所属模块：聚合配置=渠道管理，商城/跳转=跳转设置，其余=登录页设置
    if (isset($_POST['juhe_host'])) {
        need_module($admin, 'platforms');
    } elseif (isset($_POST['shop_url']) || isset($_POST['success_redirect'])) {
        need_module($admin, 'redirect');
    } else {
        need_module($admin, 'appearance');
    }
    $map = ['success_redirect', 'site_name', 'theme_color', 'shop_url', 'juhe_host', 'juhe_appid', 'juhe_appkey'];
    foreach ($map as $key) {
        if (isset($_POST[$key])) {
            $val = mysqli_real_escape_string($conn, trim($_POST[$key]));
            mysqli_query($conn, "UPDATE system_config SET value='$val' WHERE key_name='$key'");
        }
    }
    $back = isset($_POST['shop_url']) || isset($_POST['success_redirect']) ? 'redirect' : (isset($_POST['juhe_host']) ? 'platforms' : 'appearance');
    redirect('index.php?tab=' . $back . '&msg=' . urlencode('设置已保存'));
}

/* ===== 邮箱 SMTP ===== */
if ($type === 'smtp') {
    need_module($admin, 'smtp');
    $map = ['smtp_host', 'smtp_port', 'smtp_user', 'smtp_pass', 'smtp_from'];
    foreach ($map as $key) {
        if (isset($_POST[$key])) {
            $val = mysqli_real_escape_string($conn, trim($_POST[$key]));
            mysqli_query($conn, "UPDATE system_config SET value='$val' WHERE key_name='$key'");
        }
    }
    redirect('index.php?tab=smtp&msg=' . urlencode('邮箱设置已保存'));
}

/* ===== 修改自己的密码（所有管理员可用） ===== */
if ($type === 'password') {
    $oldPwd = (string)($_POST['old_pwd'] ?? '');
    $newPwd = (string)($_POST['new_pwd'] ?? '');
    $newPwd2 = (string)($_POST['new_pwd2'] ?? '');
    if (mb_strlen($newPwd) < 6) {
        redirect('index.php?tab=admin&msg=' . urlencode('新密码至少 6 位'));
    }
    if ($newPwd !== $newPwd2) {
        redirect('index.php?tab=admin&msg=' . urlencode('两次新密码不一致'));
    }
    if (!admin_password_verify($admin, $oldPwd)) {
        redirect('index.php?tab=admin&msg=' . urlencode('当前密码错误'));
    }
    $hash = mysqli_real_escape_string($conn, password_hash($newPwd, PASSWORD_DEFAULT));
    mysqli_query($conn, "UPDATE `admin_user` SET `password` = '{$hash}' WHERE id = " . (int)$admin['id']);
    redirect('index.php?tab=admin&msg=' . urlencode('密码修改成功'));
}

/* ===== 分管理员：新增 / 编辑（仅超级管理员） ===== */
if ($type === 'admin_save') {
    if (!admin_is_super($admin)) admin_deny('仅超级管理员可以管理其他管理员');

    $back     = 'index.php?tab=admin';
    $id       = (int)($_POST['id'] ?? 0);
    $username = trim((string)($_POST['username'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $role     = ($_POST['role'] ?? 'sub') === 'super' ? 'super' : 'sub';
    $remark   = trim((string)($_POST['remark'] ?? ''));
    $status   = isset($_POST['status']) ? 1 : 0;
    $perms    = array_values(array_intersect((array)($_POST['perms'] ?? []), array_keys(admin_module_map())));
    $target   = $id > 0 ? admin_row($conn, $id) : null;

    if ($id > 0 && !$target) redirect($back . '&msg=' . urlencode('账号不存在'));
    if ($id > 0 && $id === (int)$admin['id']) {
        if ($status === 0) redirect($back . '&msg=' . urlencode('不能停用当前登录的账号'));
        if ($role !== 'super') redirect($back . '&msg=' . urlencode('不能把自己降级为分管理员'));
    }
    // 至少要保留一个启用状态的超级管理员
    if ($target && $target['role'] === 'super' && ($role !== 'super' || $status === 0) && admin_super_count($conn, $id) === 0) {
        redirect($back . '&msg=' . urlencode('至少要保留一个启用状态的超级管理员'));
    }
    if ($username === '' || !preg_match('/^[\w\x{4e00}-\x{9fa5}.\-]{2,30}$/u', $username)) {
        redirect($back . '&msg=' . urlencode('用户名需 2-30 位中英文、数字、下划线、点、短横线'));
    }
    $uEsc = mysqli_real_escape_string($conn, $username);
    $res = mysqli_query($conn, "SELECT id FROM `admin_user` WHERE `username` = '{$uEsc}' AND id <> {$id} LIMIT 1");
    if ($res && mysqli_num_rows($res) > 0) redirect($back . '&msg=' . urlencode('该用户名已存在'));
    if ($id === 0 && mb_strlen($password) < 6) redirect($back . '&msg=' . urlencode('新管理员密码至少 6 位'));

    $rEsc = mysqli_real_escape_string($conn, $remark);
    $pJson = mysqli_real_escape_string($conn, json_encode($perms, JSON_UNESCAPED_UNICODE));
    if ($id === 0) {
        $hEsc = mysqli_real_escape_string($conn, password_hash($password, PASSWORD_DEFAULT));
        mysqli_query($conn, "INSERT INTO `admin_user` (`username`,`password`,`role`,`perms`,`status`,`remark`)
            VALUES ('{$uEsc}','{$hEsc}','{$role}','{$pJson}',{$status},'{$rEsc}')");
        redirect($back . '&msg=' . urlencode('管理员「' . $username . '」已新增'));
    }
    $sql = "UPDATE `admin_user` SET `username` = '{$uEsc}', `role` = '{$role}', `perms` = '{$pJson}', `status` = {$status}, `remark` = '{$rEsc}'";
    if ($password !== '') {
        $sql .= ", `password` = '" . mysqli_real_escape_string($conn, password_hash($password, PASSWORD_DEFAULT)) . "'";
    }
    $sql .= " WHERE id = {$id}";
    mysqli_query($conn, $sql);
    if ($id === (int)$admin['id']) { // 改到自己：同步刷新会话
        $fresh = admin_row($conn, $id);
        if ($fresh) admin_set_session($fresh);
    }
    redirect($back . '&msg=' . urlencode('管理员已保存'));
}

/* ===== 分管理员：删除（仅超级管理员） ===== */
if ($type === 'admin_delete') {
    if (!admin_is_super($admin)) admin_deny('仅超级管理员可以管理其他管理员');
    $back = 'index.php?tab=admin';
    $id = (int)($_POST['id'] ?? 0);
    if ($id <= 0) redirect($back . '&msg=' . urlencode('参数错误'));
    if ($id === (int)$admin['id']) redirect($back . '&msg=' . urlencode('不能删除当前登录的账号'));
    $target = admin_row($conn, $id);
    if (!$target) redirect($back . '&msg=' . urlencode('账号不存在'));
    if ($target['role'] === 'super' && admin_super_count($conn, $id) === 0) {
        redirect($back . '&msg=' . urlencode('至少要保留一个启用状态的超级管理员'));
    }
    mysqli_query($conn, "DELETE FROM `admin_user` WHERE id = {$id}");
    redirect($back . '&msg=' . urlencode('管理员「' . $target['username'] . '」已删除'));
}

/* ===== 授权状态：保存并验证授权码（仅超级管理员） ===== */
if ($type === 'license_authcode') {
    if (!admin_is_super($admin)) admin_deny('仅超级管理员可以修改授权码');
    $code = trim((string)($_POST['license_authcode'] ?? ''));
    if (!license_save_authcode($code)) {
        redirect('index.php?tab=dashboard&msg=' . urlencode('授权码保存失败：请检查 inc 目录是否可写'));
    }
    license_cache_clear();
    if ($code === '') {
        redirect('index.php?tab=dashboard&msg=' . urlencode('授权码已清空，当前为未授权状态'));
    }
    $st = license_status(true);
    redirect('index.php?tab=dashboard&msg=' . urlencode(
        $st['ok']
            ? '授权码已保存，校验通过：已授权'
            : '授权码已保存，但校验未通过（未授权）：' . $st['msg']
    ));
}

/* ===== 授权状态：重新校验（仅超级管理员） ===== */
if ($type === 'license_refresh') {
    if (!admin_is_super($admin)) admin_deny('仅超级管理员可以刷新授权状态');
    license_cache_clear();
    $st = license_status(true);
    redirect('index.php?tab=dashboard&msg=' . urlencode(
        ($st['ok'] ? '授权有效（已授权）：' : '校验结果（未授权）：') . $st['msg']
    ));
}

redirect('index.php');
