<?php
/**
 * 后台管理员登录
 */
if (!file_exists(__DIR__ . '/../config.php')) {
    header('Location: ../install/');
    exit;
}
require __DIR__ . '/../config.php';

if (admin_current($conn)) {
    redirect('index.php');
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = mysqli_real_escape_string($conn, trim($_POST['username'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $row = null;
    if ($username !== '' && $password !== '') {
        $res = mysqli_query($conn, "SELECT * FROM `admin_user` WHERE username='$username' LIMIT 1");
        $row = ($res && ($r = mysqli_fetch_assoc($res))) ? $r : null;
    }
    if ($row && (int)$row['status'] !== 1) {
        $error = '该管理员账号已被停用，请联系超级管理员';
    } elseif ($row && admin_password_verify($row, $password)) {
        admin_password_upgrade($conn, $row, $password); // 历史 MD5 密码登录成功后自动升级为 password_hash
        admin_set_session($row);
        admin_touch_login($conn, $row['id']);
        redirect('index.php');
    } else {
        $error = '用户名或密码错误';
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>后台登录 - 惊霄科技官网系统</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="login-page">

<div class="login-shell">
    <div class="login-box glow-card">
        <h2>管理后台</h2>
        <p class="login-sub">惊霄科技官网系统 · 请输入管理员账号</p>
        <?php if ($error): ?>
        <p class="msg-error"><?php echo e($error); ?></p>
        <?php endif; ?>
        <form method="post">
            <div class="form-item">
                <label>用户名</label>
                <input type="text" name="username" required placeholder="admin" autocomplete="username">
            </div>
            <div class="form-item">
                <label>密码</label>
                <input type="password" name="password" required placeholder="请输入密码" autocomplete="current-password">
            </div>
            <button type="submit" class="btn btn-primary btn-block">登 录</button>
        </form>
        <div class="login-foot">
            <a href="/">← 返回官网</a>
        </div>
    </div>
</div>

</body>
</html>
