<?php
/**
 * 产品管理：列表 + 新增 / 编辑
 */
require __DIR__ . '/../config.php';
admin_guard($conn, 'products'); // 需「产品管理」权限

$editId = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;
$edit = null;
if ($editId) {
    $res = mysqli_query($conn, "SELECT * FROM products WHERE id=$editId LIMIT 1");
    $edit = mysqli_fetch_assoc($res);
}

$list = mysqli_query($conn, "SELECT * FROM products ORDER BY sort ASC, id DESC");
$count = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM products"))[0];
$showCount = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM products WHERE status=1"))[0];
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>产品管理 - 惊霄科技官网系统</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="admin-body">

<nav class="nav">
    <div class="nav-logo">惊霄科技官网 · 后台</div>
    <div class="nav-menu">
        <a href="index.php">后台首页</a>
        <a href="../">前台首页</a>
        <a href="logout.php" class="link-danger">退出登录</a>
    </div>
</nav>

<div class="admin-layout">
    <aside class="admin-side">
        <a href="index.php" class="as-item">概览</a>
        <a href="products.php" class="as-item active">产品管理</a>
        <a href="companies.php" class="as-item">合作企业</a>
        <a href="index.php?tab=platforms" class="as-item">渠道管理</a>
        <a href="index.php?tab=appearance" class="as-item">登录页设置</a>
        <a href="index.php?tab=smtp" class="as-item">邮箱设置</a>
        <a href="index.php?tab=redirect" class="as-item">跳转设置</a>
        <a href="index.php?tab=admin" class="as-item">管理员</a>
    </aside>

    <div class="admin-main">
        <div class="admin-head">
            <h1>产品管理</h1>
            <span class="badge">共 <?php echo (int)$count; ?> 个 · 前台展示 <?php echo (int)$showCount; ?> 个</span>
        </div>

        <!-- 新增 / 编辑表单 -->
        <div class="ad-panel">
            <h3><?php echo $edit ? '编辑产品：' . e($edit['name']) : '新增产品'; ?></h3>
            <form method="post" action="products_save.php" enctype="multipart/form-data">
                <input type="hidden" name="act" value="save">
                <input type="hidden" name="id" value="<?php echo $edit ? (int)$edit['id'] : 0; ?>">
                <div class="setup-grid">
                    <div>
                        <div class="form-item"><label>产品名称 *</label><input type="text" name="name" required value="<?php echo $edit ? e($edit['name']) : ''; ?>" placeholder="产品名称"></div>
                        <div class="form-item"><label>价格文案</label><input type="text" name="price" value="<?php echo $edit ? e($edit['price']) : ''; ?>" placeholder="如：￥99 / 免费 / 定制"></div>
                        <div class="form-item"><label>排序（越小越靠前）</label><input type="text" name="sort" value="<?php echo $edit ? (int)$edit['sort'] : 0; ?>"></div>
                        <div class="form-item"><label>显示状态</label>
                            <label class="switch"><input type="checkbox" name="status" value="1" <?php echo (!$edit || $edit['status'] == 1) ? 'checked' : ''; ?>><span class="slider"></span><span class="switch-text">展示</span></label>
                        </div>
                    </div>
                    <div>
                        <div class="form-item"><label>产品描述</label><textarea name="description" rows="4" placeholder="产品卖点 / 说明"><?php echo $edit ? e($edit['description']) : ''; ?></textarea></div>
                        <div class="form-item"><label>图片地址（可选，填 URL）</label><input type="text" name="image_url" value="<?php echo $edit ? e($edit['image']) : ''; ?>" placeholder="https://... 或 assets/uploads/products/xxx.png"></div>
                        <div class="form-item"><label>或上传图片（jpg/png/webp，2MB 内）</label><input type="file" name="image_file" accept="image/jpeg,image/png,image/webp"></div>
                        <?php if ($edit && !empty($edit['image'])): ?>
                        <div class="form-tip">当前图片：<img src="../<?php echo e($edit['image']); ?>" style="max-height:64px;border-radius:8px;display:block;margin-top:6px"></div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-actions">
                    <a class="btn btn-ghost" href="products.php">取消</a>
                    <button class="btn btn-primary" type="submit"><?php echo $edit ? '保存修改' : '添加产品'; ?></button>
                </div>
            </form>
        </div>

        <!-- 产品列表 -->
        <div class="ad-panel">
            <h3>产品列表</h3>
            <table class="log-table">
                <thead><tr><th>ID</th><th>图片</th><th>名称</th><th>价格</th><th>状态</th><th>排序</th><th>操作</th></tr></thead>
                <tbody>
                <?php while ($p = mysqli_fetch_assoc($list)): ?>
                <tr>
                    <td><?php echo (int)$p['id']; ?></td>
                    <td>
                        <?php if (!empty($p['image'])): ?>
                        <img src="../<?php echo e($p['image']); ?>" style="width:52px;height:38px;object-fit:cover;border-radius:6px">
                        <?php else: ?>
                        <span class="dim">—</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($p['name']); ?></td>
                    <td><?php echo e($p['price']); ?></td>
                    <td><?php echo $p['status'] == 1 ? '<span class="ok-tag">展示中</span>' : '<span class="no-tag">已隐藏</span>'; ?></td>
                    <td><?php echo (int)$p['sort']; ?></td>
                    <td class="ops">
                        <a class="btn btn-sm" href="products.php?edit=<?php echo (int)$p['id']; ?>">编辑</a>
                        <a class="btn btn-sm btn-ghost" href="products_save.php?act=toggle&id=<?php echo (int)$p['id']; ?>&status=<?php echo $p['status'] == 1 ? 0 : 1; ?>"><?php echo $p['status'] == 1 ? '隐藏' : '展示'; ?></a>
                        <a class="btn btn-sm btn-danger" href="products_save.php?act=delete&id=<?php echo (int)$p['id']; ?>" onclick="return confirm('确定删除该产品？')">删除</a>
                    </td>
                </tr>
                <?php endwhile; ?>
                <?php if ($count == 0): ?>
                <tr><td colspan="7" class="dim">暂无产品，请在左侧表单添加。</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="../assets/js/main.js"></script>
</body>
</html>
