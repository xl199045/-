<?php
/**
 * 管理后台主页：概览 / 渠道管理 / 登录页设置 / 邮箱设置 / 跳转设置 / 管理员
 * 产品管理 → products.php   合作企业 → companies.php
 */
require __DIR__ . '/../config.php';
$admin = admin_guard($conn);                 // 未登录跳登录页；停用/已删除账号自动退出
$isSuper = admin_is_super($admin);

$tab = $_GET['tab'] ?? 'dashboard';
$msg = $_GET['msg'] ?? '';
$moduleMap = admin_module_map();
if ($tab !== 'admin' && !isset($moduleMap[$tab])) $tab = 'dashboard';
$tabAllowed = admin_can($admin, $tab);        // 无权限的模块只显示提示，不输出内容
$editAdmin = ($isSuper && isset($_GET['edit'])) ? admin_row($conn, (int)$_GET['edit']) : null;

// 授权状态（对接惊霄授权系统；结果带缓存，可在概览页手动重新校验）
require_once __DIR__ . '/../inc/license.php';
$license = license_status();

// 概览统计
$totalUsers = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM oauth_users"))[0] ?? 0;
$todayLogins = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM login_logs WHERE DATE(created_at) = CURDATE()"))[0] ?? 0;
$enabledCount = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM oauth_channels WHERE enable=1"))[0] ?? 0;
$productCount = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM products"))[0] ?? 0;
$companyCount = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM companies"))[0] ?? 0;
$pendingCompany = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM companies WHERE status=0"))[0] ?? 0;
$musicCount = 0;
$musicDir = __DIR__ . '/../assets/music';
if (is_dir($musicDir)) { $musicCount = count(glob($musicDir . '/*.mp3')); }

// 渠道图标 / 颜色映射（与前台 index.php、login.php 保持一致）
$iconMap = [
    'github' => 'GH', 'gitee' => 'G', 'alipay' => '支', 'qq' => 'Q',
    'wechat' => '微', 'weibo' => '博', 'baidu' => '百', 'dingtalk' => '钉',
    'douyin' => '抖', 'feishu' => '飞', 'oschina' => 'OS', 'coding' => 'COD',
    'huawei' => 'HW', 'google' => 'G', 'microsoft' => 'MS', 'wework' => '企',
    'xiaomi' => '米', 'bilibili' => 'B',
    'gitlab' => 'GL', 'twitter' => 'X', 'facebook' => 'f', 'discord' => 'DC',
    'line' => 'L', 'linkedin' => 'in', 'qihoo' => '360', 'douban' => '豆',
    'netease' => '易', 'taobao' => '淘', 'juhe' => '聚',
];
$colorMap = [
    'github' => '#24292F', 'gitee' => '#C71D23', 'alipay' => '#1677FF', 'qq' => '#12B7F5',
    'wechat' => '#07C160', 'weibo' => '#E6162D', 'baidu' => '#2932E1', 'dingtalk' => '#0089FF',
    'douyin' => '#111111', 'feishu' => '#3370FF', 'oschina' => '#4E9A44', 'coding' => '#15C072',
    'huawei' => '#C7000B', 'google' => '#4285F4', 'microsoft' => '#00A4EF', 'wework' => '#0082EF',
    'xiaomi' => '#FF6900', 'bilibili' => '#00A1D6',
    'gitlab' => '#FC6D26', 'twitter' => '#1DA1F2', 'facebook' => '#1877F2', 'discord' => '#5865F2',
    'line' => '#06C755', 'linkedin' => '#0A66C2', 'qihoo' => '#DE1616', 'douban' => '#00B51D',
    'netease' => '#E60012', 'taobao' => '#FF5000', 'juhe' => '#8B5CF6',
];

$logs = mysqli_query($conn, "SELECT * FROM login_logs ORDER BY id DESC LIMIT 8");
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>管理后台 - 惊霄科技官网</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="admin-body">

<nav class="nav">
    <div class="nav-logo">惊霄科技官网后台</div>
    <div class="nav-menu">
        <a href="../">前台首页</a>
        <a href="../login.php">登录页</a>
        <a href="../join.php">企业入驻</a>
        <a href="logout.php" class="link-danger">退出登录</a>
    </div>
</nav>

<div class="admin-layout">
    <aside class="admin-side">
        <?php if (admin_can($admin, 'dashboard')): ?>
        <a href="index.php" class="as-item <?php echo $tab === 'dashboard' ? 'active' : ''; ?>">概览</a>
        <?php endif; ?>
        <?php if (admin_can($admin, 'products')): ?>
        <a href="products.php" class="as-item">产品管理</a>
        <?php endif; ?>
        <?php if (admin_can($admin, 'companies')): ?>
        <a href="companies.php" class="as-item">合作企业<?php echo $pendingCompany > 0 ? ' <em>' . $pendingCompany . '</em>' : ''; ?></a>
        <?php endif; ?>
        <?php if (admin_can($admin, 'platforms')): ?>
        <a href="index.php?tab=platforms" class="as-item <?php echo $tab === 'platforms' ? 'active' : ''; ?>">渠道管理</a>
        <?php endif; ?>
        <?php if (admin_can($admin, 'appearance')): ?>
        <a href="index.php?tab=appearance" class="as-item <?php echo $tab === 'appearance' ? 'active' : ''; ?>">登录页设置</a>
        <?php endif; ?>
        <?php if (admin_can($admin, 'smtp')): ?>
        <a href="index.php?tab=smtp" class="as-item <?php echo $tab === 'smtp' ? 'active' : ''; ?>">邮箱设置</a>
        <?php endif; ?>
        <?php if (admin_can($admin, 'redirect')): ?>
        <a href="index.php?tab=redirect" class="as-item <?php echo $tab === 'redirect' ? 'active' : ''; ?>">跳转设置</a>
        <?php endif; ?>
        <a href="index.php?tab=admin" class="as-item <?php echo $tab === 'admin' ? 'active' : ''; ?>">管理员</a>

        <div class="uc-side-card">
            <span class="uc-avatar"><span class="uc-avatar-txt"><?php echo e(mb_substr($admin['username'], 0, 1)); ?></span></span>
            <div class="uc-side-info">
                <b><?php echo e($admin['username']); ?></b>
                <small><?php echo $isSuper ? '超级管理员' : '分管理员 · ' . e(admin_perm_text($admin)); ?></small>
            </div>
        </div>
    </aside>

    <div class="admin-main">
        <?php if ($msg): ?>
        <p class="msg-ok"><?php echo e($msg); ?></p>
        <?php endif; ?>

        <?php if (!$tabAllowed): ?>
        <!-- ===== 无权限提示 ===== -->
        <div class="ad-panel">
            <h3>无访问权限</h3>
            <p class="dim">当前账号（<?php echo e($admin['username']); ?>）没有「<?php echo e($moduleMap[$tab] ?? $tab); ?>」模块的权限，请联系超级管理员在「管理员 → 分管理员」中授权。</p>
        </div>

        <?php else: ?>

        <?php if ($tab === 'dashboard'): ?>
        <!-- ===== 概览 ===== -->
        <div class="admin-head"><h1>概览</h1><span class="badge">演示数据实时来自数据库</span></div>
        <div class="ad-grid">
            <div class="ad-stat"><div class="as-num"><?php echo (int)$totalUsers; ?></div><div class="as-label">注册用户</div></div>
            <div class="ad-stat"><div class="as-num"><?php echo (int)$todayLogins; ?></div><div class="as-label">今日登录</div></div>
            <div class="ad-stat"><div class="as-num"><?php echo (int)$enabledCount; ?>/12</div><div class="as-label">启用渠道</div></div>
            <div class="ad-stat"><div class="as-num"><?php echo (int)$productCount; ?></div><div class="as-label">产品数</div></div>
            <div class="ad-stat"><div class="as-num"><?php echo (int)$companyCount; ?></div><div class="as-label">合作企业</div></div>
            <div class="ad-stat"><div class="as-num"><?php echo (int)$pendingCompany; ?></div><div class="as-label">待审核入驻</div></div>
            <div class="ad-stat"><div class="as-num"><?php echo (int)$musicCount; ?></div><div class="as-label">音乐文件</div></div>
            <div class="ad-stat"><div class="as-num"><?php echo PHP_VERSION; ?></div><div class="as-label">PHP 版本</div></div>
        </div>
        <div class="ad-panel">
            <h3>授权状态 <?php echo license_badge($license); ?></h3>
            <table class="log-table">
                <tbody>
                <tr><td class="dim" style="width:120px">应用名称</td><td><?php echo e($license['name'] !== '' ? $license['name'] : '—'); ?></td></tr>
                <tr><td class="dim">授权域名</td><td><?php echo e($license['host'] !== '' ? $license['host'] : '—'); ?></td></tr>
                <tr><td class="dim">校验时间</td><td><?php echo e(date('Y-m-d H:i:s', (int)$license['checked_at'])); ?><?php echo !empty($license['cached']) ? '（缓存）' : '（实时）'; ?></td></tr>
                <tr><td class="dim">云端返回</td><td><?php echo e($license['msg']); ?></td></tr>
                <tr><td class="dim">授权系统</td><td><?php echo e(license_config()['host'] !== '' ? license_config()['host'] : '未配置'); ?></td></tr>
                <tr><td class="dim">授权码来源</td><td><?php echo e(license_authcode_source()); ?></td></tr>
                </tbody>
            </table>
            <?php if ($isSuper): ?>
            <form method="post" action="save_config.php?type=license_authcode" style="margin-top:14px">
                <div class="form-item form-item-wide">
                    <label>授权码（授权系统「授权列表」中本站域名对应的授权代码）</label>
                    <input type="text" name="license_authcode" value="<?php echo e(license_stored_authcode()); ?>" placeholder="粘贴授权码后点击「保存并验证」">
                </div>
                <div style="margin-top:12px">
                    <button class="btn btn-primary" type="submit">✅ 保存并验证授权码</button>
                </div>
                <?php if (!license_authcode_writable()): ?>
                <p class="form-tip" style="margin-top:8px">⚠️ inc 目录不可写，授权码可能保存失败，请检查站点目录权限。</p>
                <?php endif; ?>
            </form>
            <form method="post" action="save_config.php?type=license_refresh" style="margin-top:10px">
                <button class="btn btn-ghost" type="submit">🔄 重新校验授权</button>
            </form>
            <?php else: ?>
            <p class="dim" style="margin-top:14px;font-size:13px">授权码的填写与校验仅超级管理员可用。</p>
            <?php endif; ?>
        </div>
        <div class="ad-panel">
            <h3>最近登录日志</h3>
            <table class="log-table">
                <thead><tr><th>时间</th><th>昵称</th><th>渠道</th><th>IP</th></tr></thead>
                <tbody>
                <?php while ($log = mysqli_fetch_assoc($logs)): ?>
                <tr>
                    <td><?php echo e($log['created_at']); ?></td>
                    <td><?php echo e($log['nickname']); ?></td>
                    <td><?php echo e($log['channel']); ?></td>
                    <td><?php echo e($log['ip']); ?></td>
                </tr>
                <?php endwhile; ?>
                <?php if (mysqli_num_rows($logs) === 0): ?><tr><td colspan="4" class="dim">暂无登录记录</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php elseif ($tab === 'platforms'): ?>
        <!-- ===== 渠道管理（对齐惊霄惊霄科技官网平台配置体验） ===== -->
        <div class="admin-head"><h1>渠道管理</h1><span class="badge">开关即时生效 · 登录页自动渲染已启用渠道</span></div>

        <!-- ===== 一键惊霄科技官网配置（填一次全部渠道生效） ===== -->
        <div class="ad-panel" style="margin-bottom:16px;border:1px solid rgba(139,92,246,.45)">
            <h3 style="margin:0 0 4px">⚡ 一键惊霄科技官网配置</h3>
            <p style="margin:0 0 14px;font-size:13px;color:var(--dim);line-height:1.6">在惊霄/彩虹聚合平台申请一次，填写下面三项并保存，前台登录页的「惊霄科技官网」Tab 全部 28 个渠道即刻可用，无需每个渠道单独填凭证。</p>
            <form method="post" action="save_config.php?type=system">
                <div class="channel-form">
                    <div class="form-item form-item-wide"><label>聚合平台 API 域名（惊霄平台地址）</label><input type="text" name="juhe_host" value="<?php echo e($systemConfig['juhe_host'] ?? ''); ?>" placeholder="https://jhdl.你的域名.top"></div>
                    <div class="form-item"><label>聚合平台 AppID</label><input type="text" name="juhe_appid" value="<?php echo e($systemConfig['juhe_appid'] ?? ''); ?>" placeholder="惊霄平台分配的 AppID"></div>
                    <div class="form-item"><label>聚合平台 AppKey</label><input type="text" name="juhe_appkey" value="<?php echo e($systemConfig['juhe_appkey'] ?? ''); ?>" placeholder="惊霄平台分配的 AppKey"></div>
                </div>
                <div style="display:flex;justify-content:space-between;align-items:center;margin-top:14px;flex-wrap:wrap;gap:10px">
                    <button class="btn btn-primary" type="submit">💾 保存聚合配置</button>
                    <div style="display:flex;gap:10px">
                        <button class="btn btn-primary" type="button" id="btnBatchJuhe">⚡ 一键开启惊霄科技官网</button>
                        <button class="btn btn-ghost" type="button" id="btnBatchDirect">🔄 一键切换直连官方</button>
                    </div>
                </div>
            </form>
        </div>

        <?php
        // 各平台申请指引 / 开放平台入口（参照惊霄惊霄科技官网平台配置）
        $platformTips = [
            'qq'       => ['doc' => 'https://connect.qq.com/', 'id' => 'APP ID', 'sec' => 'APP Key', 'tip' => '前往QQ互联 → 应用管理 获取APP ID和APP Key'],
            'wechat'   => ['doc' => 'https://open.weixin.qq.com/', 'id' => 'AppID', 'sec' => 'AppSecret', 'tip' => '前往微信开放平台 → 管理中心 → 网站应用 获取凭证'],
            'alipay'   => ['doc' => 'https://open.alipay.com/', 'id' => 'APPID', 'sec' => '应用私钥', 'tip' => '前往支付宝开放平台 → 开发者中心 → 我的应用，注意配置RSA2密钥'],
            'weibo'    => ['doc' => 'https://open.weibo.com/', 'id' => 'App Key', 'sec' => 'App Secret', 'tip' => '前往微博开放平台 → 我的应用 获取App Key'],
            'baidu'    => ['doc' => 'https://developer.baidu.com/', 'id' => 'API Key', 'sec' => 'Secret Key', 'tip' => '前往百度开发者中心 → 控制台 → 创建应用'],
            'douyin'   => ['doc' => 'https://open.douyin.com/', 'id' => 'Client Key', 'sec' => 'Client Secret', 'tip' => '前往抖音开放平台 → 开发者后台 → 创建应用'],
            'huawei'   => ['doc' => 'https://developer.huawei.com/', 'id' => 'Client ID', 'sec' => 'Client Secret', 'tip' => '前往华为开发者联盟 → AppGallery Connect → 我的项目 → 开通华为帐号服务'],
            'google'   => ['doc' => 'https://console.cloud.google.com/apis/credentials', 'id' => 'Client ID', 'sec' => 'Client Secret', 'tip' => '前往 Google Cloud Console → APIs & Services → Credentials 创建OAuth 2.0客户端'],
            'microsoft'=> ['doc' => 'https://portal.azure.com/', 'id' => 'Client ID', 'sec' => 'Client Secret', 'tip' => '前往 Azure Portal → Azure Active Directory → 应用注册 创建应用'],
            'wework'   => ['doc' => 'https://work.weixin.qq.com/', 'id' => 'CorpID', 'sec' => 'Secret', 'tip' => '前往企业微信管理后台 → 应用管理 → 自建应用 获取凭证，AgentID单独填写'],
            'dingtalk' => ['doc' => 'https://open.dingtalk.com/', 'id' => 'AppKey', 'sec' => 'AppSecret', 'tip' => '前往钉钉开放平台 → 应用开发 → 企业内部应用 创建H5微应用'],
            'gitee'    => ['doc' => 'https://gitee.com/oauth/applications', 'id' => 'Client ID', 'sec' => 'Client Secret', 'tip' => '前往 Gitee → 设置 → 第三方应用 创建应用'],
            'github'   => ['doc' => 'https://github.com/settings/developers', 'id' => 'Client ID', 'sec' => 'Client Secret', 'tip' => '前往 GitHub Settings → Developer settings → OAuth Apps 创建应用'],
            'feishu'   => ['doc' => 'https://open.feishu.cn/', 'id' => 'App ID', 'sec' => 'App Secret', 'tip' => '前往飞书开放平台 → 开发者后台 → 创建企业自建应用'],
            'bilibili' => ['doc' => 'https://open.bilibili.com/', 'id' => 'Client ID', 'sec' => 'Client Secret', 'tip' => '前往哔哩哔哩开放平台 → 开发者中心 → 创建应用'],
            'xiaomi'   => ['doc' => 'https://dev.mi.com/', 'id' => 'App ID', 'sec' => 'App Secret', 'tip' => '前往小米开放平台 → 管理中心 → 帐号服务 → 创建网站应用'],
            'oschina'  => ['doc' => 'https://www.oschina.net/action/oauth2/authorize', 'id' => 'Client ID', 'sec' => 'Client Secret', 'tip' => '前往开源中国开放平台创建应用'],
            'coding'   => ['doc' => 'https://coding.net/', 'id' => 'Client ID', 'sec' => 'Client Secret', 'tip' => '前往 Coding 开放平台创建应用'],
            'gitlab'   => ['doc' => 'https://gitlab.com/-/profile/applications', 'id' => 'Client ID', 'sec' => 'Client Secret', 'tip' => '前往 GitLab → 设置 → 应用 创建（自建 GitLab 改域名即可）'],
            'twitter'  => ['doc' => 'https://developer.twitter.com/', 'id' => 'Client ID', 'sec' => 'Client Secret', 'tip' => '前往 Twitter Developer → 项目 → OAuth 2.0 Client'],
            'facebook' => ['doc' => 'https://developers.facebook.com/', 'id' => 'Client ID', 'sec' => 'Client Secret', 'tip' => '前往 Facebook Developers 创建应用并启用 Facebook 登录'],
            'discord'  => ['doc' => 'https://discord.com/developers/applications', 'id' => 'Client ID', 'sec' => 'Client Secret', 'tip' => '前往 Discord Developers 创建应用并配置 OAuth2 重定向'],
            'line'     => ['doc' => 'https://developers.line.biz/', 'id' => 'Channel ID', 'sec' => 'Channel Secret', 'tip' => '前往 LINE Developers 创建 LINE Login 渠道并配置回调'],
            'linkedin' => ['doc' => 'https://www.linkedin.com/developers/', 'id' => 'Client ID', 'sec' => 'Client Secret', 'tip' => '前往 LinkedIn Developers 创建应用并配置 Auth 回调'],
            'qihoo'    => ['doc' => 'https://open.360.cn/', 'id' => 'Client ID', 'sec' => 'Client Secret', 'tip' => '前往 360 开放平台申请应用'],
            'douban'   => ['doc' => 'https://developers.douban.com/', 'id' => 'API Key', 'sec' => 'Secret', 'tip' => '前往豆瓣开发者中心申请 API Key'],
            'netease'  => ['doc' => 'https://open.163.com/', 'id' => 'Client ID', 'sec' => 'Client Secret', 'tip' => '前往网易开放平台申请 OAuth2 应用'],
            'taobao'   => ['doc' => 'https://open.taobao.com/', 'id' => 'App Key', 'sec' => 'App Secret', 'tip' => '前往淘宝开放平台创建应用（需开发者资质）'],
            'juhe'     => ['doc' => '', 'id' => 'AppID', 'sec' => 'AppKey', 'tip' => '对接惊霄/彩虹惊霄科技官网：在惊霄平台申请 AppID/AppKey，并在后台「跳转设置」填写聚合平台 API 域名'],
        ];
        $cbBase = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];
        // 惊霄聚合平台实际支持的 16 个渠道（以惊霄 platforms.php 为准），其余渠道后台聚合选项自动置灰
        $juheSupport = ['qq','wechat','alipay','weibo','baidu','douyin','huawei','google','microsoft','wework','dingtalk','gitee','github','feishu','bilibili','xiaomi'];
        ?>
        <div class="ad-panel">
            <form method="post" action="save_config.php?type=channel">
            <?php foreach ($channels as $item):
                if ($item['name'] === 'juhe') continue; // 聚合平台已合并到顶部「一键惊霄科技官网配置」，不再单独展示渠道卡片
                $tip = $platformTips[$item['name']] ?? [];
                $wecorp = ''; $weagent = '';
                if ($item['name'] === 'wework' && strpos($item['appid'], '|') !== false) { [$wecorp, $weagent] = explode('|', $item['appid'], 2); }
            ?>
                <div class="channel-box">
                    <div class="channel-head">
                        <div style="display:flex;align-items:center;gap:12px">
                            <i class="oauth-icon" style="background:<?php echo e($colorMap[$item['name']] ?? '#8B5CF6'); ?>;font-style:normal"><?php echo e($iconMap[$item['name']] ?? '登'); ?></i>
                            <div>
                                <span class="channel-name"><?php echo e($item['title']); ?></span>
                                <?php if (!empty($tip['doc'])): ?>
                                <a href="<?php echo e($tip['doc']); ?>" target="_blank" rel="noopener" style="font-size:12px;color:var(--tc);margin-left:8px">开放平台 ↗</a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <label class="switch">
                            <input type="checkbox" name="enable[<?php echo e($item['name']); ?>]" value="1" <?php echo $item['enable'] == 1 ? 'checked' : ''; ?>>
                            <span class="slider"></span>
                            <span class="switch-text"><?php echo $item['enable'] == 1 ? '已开启' : '已关闭'; ?></span>
                        </label>
                    </div>
                    <?php if (!empty($tip['tip'])): ?>
                    <div style="font-size:12px;color:var(--dim);background:rgba(251,191,36,.07);border:1px solid rgba(251,191,36,.2);border-radius:8px;padding:8px 12px;margin-bottom:12px">💡 <?php echo e($tip['tip']); ?></div>
                    <?php endif; ?>
                    <div style="font-size:12px;color:var(--dim);margin-bottom:12px">
                        回调地址：
                        <code style="background:#0f172a;padding:2px 8px;border-radius:6px;cursor:pointer;color:#cbd5e1" onclick="copyText(this)"><?php echo e($cbBase); ?>/callback.php?channel=<?php echo e($item['name']); ?></code>
                        <span style="font-size:11px">（点击复制）</span>
                    </div>
                    <input type="hidden" name="name[]" value="<?php echo e($item['name']); ?>">
                    <div class="channel-form">
                        <div class="form-item"><label>显示名称</label><input type="text" name="title[]" value="<?php echo e($item['title']); ?>"></div>
                        <div class="form-item"><label>排序</label><input type="text" name="sort[]" value="<?php echo (int)$item['sort']; ?>"></div>
                        <?php if ($item['name'] === 'wework'): ?>
                        <div class="form-item"><label>CorpID（企业ID）</label><input type="text" name="wework_corpid" value="<?php echo e($wecorp); ?>" placeholder="ww1234567890"></div>
                        <div class="form-item"><label>AgentID（自建应用ID）</label><input type="text" name="wework_agentid" value="<?php echo e($weagent); ?>" placeholder="1000002"></div>
                        <?php else: ?>
                        <div class="form-item"><label><?php echo e($tip['id'] ?? 'AppID'); ?></label><input type="text" name="appid[<?php echo e($item['name']); ?>]" value="<?php echo e($item['appid']); ?>" placeholder="应用ID"></div>
                        <?php endif; ?>
                        <div class="form-item"><label><?php echo e($tip['sec'] ?? 'AppSecret / 私钥'); ?></label><input type="text" name="appsecret[]" value="<?php echo e($item['appsecret']); ?>" placeholder="密钥（支付宝填应用私钥）"></div>
                        <?php if ($item['name'] === 'juhe'): ?>
                        <input type="hidden" name="mode[]" value="0">
                        <?php elseif (!in_array($item['name'], $juheSupport)): ?>
                        <input type="hidden" name="mode[]" value="0">
                        <div class="form-item form-item-wide"><label>对接方式</label>
                            <input type="text" value="仅支持直连官方 OAuth" readonly style="background:rgba(248,113,113,.12);color:#f87171;border-color:rgba(248,113,113,.4)">
                        </div>
                        <div class="form-tip" style="color:#f87171">⚠️ 该渠道不支持惊霄/彩虹聚合中转，只能直连官方登录</div>
                        <?php else: ?>
                        <div class="form-item form-item-wide"><label>对接方式</label>
                            <select name="mode[]">
                                <option value="0" <?php echo ($item['mode'] ?? 0) == 0 ? 'selected' : ''; ?>>直连官方 OAuth（在该平台申请凭证）</option>
                                <option value="1" <?php echo ($item['mode'] ?? 0) == 1 ? 'selected' : ''; ?>>对接聚合平台（经惊霄/彩虹惊霄科技官网中转）</option>
                            </select>
                            <?php if (($item['mode'] ?? 0) == 1): ?>
                            <div class="form-tip">已选对接聚合平台：AppID / AppSecret 填聚合平台分配的凭证，并确保「跳转设置」中已填聚合平台 API 域名。</div>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                        <div class="form-item form-item-wide"><label>回调地址</label><input type="text" name="redirect_uri[]" value="<?php echo e($item['redirect_uri']); ?>" placeholder="<?php echo e($cbBase); ?>/callback.php?channel=<?php echo e($item['name']); ?>"></div>
                    </div>
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-top:10px">
                        <button type="button" class="btn btn-sm btn-ghost" onclick="testCallback('<?php echo e($item['name']); ?>', this)">测试回调</button>
                        <button class="btn btn-sm" type="submit">保存渠道</button>
                    </div>
                </div>
            <?php endforeach; ?>
            <div class="form-actions"><button class="btn btn-primary" type="submit">保存全部渠道设置</button></div>
            </form>
        </div>
        <script>
        function copyText(el) {
            var t = el.textContent.trim();
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(t).then(function(){ toastMsg('回调地址已复制'); });
            }
        }
        function toastMsg(m) {
            var d = document.createElement('div');
            d.textContent = m;
            d.style.cssText = 'position:fixed;top:16px;left:50%;transform:translateX(-50%);background:#10b981;color:#fff;padding:10px 18px;border-radius:10px;font-size:13px;z-index:999;box-shadow:0 6px 20px rgba(0,0,0,.4)';
            document.body.appendChild(d);
            setTimeout(function(){ d.remove(); }, 1800);
        }
        function testCallback(name, btn) {
            var card = btn.closest('.channel-box');
            var on = card.querySelector('input[type=checkbox]').checked;
            if (!on) { toastMsg('请先启用该渠道'); return; }
            var appid = '';
            if (name === 'wework') {
                var c = card.querySelector('input[name=wework_corpid]');
                if (c && c.value.trim()) appid = c.value.trim();
            } else {
                var inp = card.querySelector('input[name^="appid["]');
                if (inp && inp.value.trim()) appid = inp.value.trim();
            }
            if (!appid) { toastMsg('请先填写并保存 AppID'); return; }
            var w = window.open('../callback.php?channel=' + name, 'oauth_test_' + name, 'width=600,height=700,scrollbars=yes,resizable=yes');
            if (w) toastMsg('已打开测试窗口，请在新窗口完成授权'); else toastMsg('浏览器阻止了弹窗，请允许');
        }
        /* ===== 一键开启：批量切换对接方式 ===== */
        function batchMode(mode, label) {
            var tip = mode === 'juhe'
                ? '确认一键开启惊霄科技官网？全部支持聚合的 16 个渠道将切换为「对接聚合平台」。'
                : '确认一键切换直连官方？全部渠道将恢复「直连官方 OAuth」。';
            if (!confirm(tip)) return;
            var btn = mode === 'juhe' ? document.getElementById('btnBatchJuhe') : document.getElementById('btnBatchDirect');
            var old = btn.innerHTML; btn.disabled = true; btn.innerHTML = '处理中…';
            fetch('save_config.php?type=batch', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'mode=' + encodeURIComponent(mode)
            }).then(function(r){ return r.json(); }).then(function(res){
                toastMsg(res.msg || '操作完成');
                setTimeout(function(){ location.reload(); }, 1200);
            }).catch(function(){
                toastMsg('请求失败，请重试');
                btn.disabled = false; btn.innerHTML = old;
            });
        }
        document.getElementById('btnBatchJuhe').addEventListener('click', function(){ batchMode('juhe', '聚合'); });
        document.getElementById('btnBatchDirect').addEventListener('click', function(){ batchMode('direct', '直连'); });
        </script>

        <?php elseif ($tab === 'appearance'): ?>
        <!-- ===== 登录页设置 ===== -->
        <div class="admin-head"><h1>登录页设置</h1><span class="badge">保存后登录页实时生效</span></div>
        <div class="setup-grid">
            <div class="ad-panel">
                <h3>登录背景</h3>
                <?php if (!empty($systemConfig['login_bg'])): ?>
                <div class="bg-preview" style="background-image:url('../<?php echo e($systemConfig['login_bg']); ?>')"></div>
                <?php else: ?>
                <div class="bg-preview bg-empty">未设置背景（登录页使用默认深色背景）</div>
                <?php endif; ?>
                <form method="post" action="upload_bg.php" enctype="multipart/form-data" class="mt">
                    <div class="form-item"><label>上传新背景（jpg/png/webp，2MB 内）</label><input type="file" name="bg_file" accept="image/jpeg,image/png,image/webp" required></div>
                    <button class="btn btn-primary" type="submit">上传并应用</button>
                </form>
            </div>
            <div class="ad-panel">
                <h3>站点信息</h3>
                <form method="post" action="save_config.php?type=system">
                    <div class="form-item"><label>站点名称</label><input type="text" name="site_name" value="<?php echo e($systemConfig['site_name'] ?? '惊霄科技官网'); ?>"></div>
                    <div class="form-item"><label>主题色</label><input type="color" name="theme_color" value="<?php echo e($systemConfig['theme_color'] ?? '#22d3ee'); ?>" style="width:80px;height:42px;padding:4px;background:#1e293b;border:1px solid #334155;border-radius:8px;cursor:pointer"></div>
                    <div class="form-actions"><button class="btn btn-primary" type="submit">保存站点信息</button></div>
                </form>
            </div>
        </div>

        <?php elseif ($tab === 'smtp'): ?>
        <!-- ===== 邮箱设置 ===== -->
        <div class="admin-head"><h1>邮箱设置</h1><span class="badge">QQ 邮箱验证码登录依赖此配置</span></div>
        <div class="ad-panel">
            <form method="post" action="save_config.php?type=smtp">
                <div class="form-item"><label>SMTP 服务器</label><input type="text" name="smtp_host" value="<?php echo e($systemConfig['smtp_host'] ?? 'smtp.qq.com'); ?>" placeholder="smtp.qq.com"></div>
                <div class="form-item"><label>SMTP 端口（SSL 465）</label><input type="text" name="smtp_port" value="<?php echo e($systemConfig['smtp_port'] ?? '465'); ?>" placeholder="465"></div>
                <div class="form-item"><label>发件邮箱</label><input type="text" name="smtp_user" value="<?php echo e($systemConfig['smtp_user'] ?? ''); ?>" placeholder="你的QQ号@qq.com"></div>
                <div class="form-item"><label>SMTP 授权码（QQ邮箱设置→账户→开启SMTP获取）</label><input type="text" name="smtp_pass" value="<?php echo e($systemConfig['smtp_pass'] ?? ''); ?>" placeholder="16位授权码，非登录密码"></div>
                <div class="form-actions"><button class="btn btn-primary" type="submit">保存邮箱设置</button></div>
            </form>
        </div>

        <?php elseif ($tab === 'redirect'): ?>
        <!-- ===== 跳转设置 ===== -->
        <div class="admin-head"><h1>跳转设置</h1><span class="badge">登录成功与商城入口网址后台配置</span></div>
        <div class="ad-panel">
            <form method="post" action="save_config.php?type=system">
                <div class="form-item"><label>登录成功跳转网址</label><input type="text" name="success_redirect" value="<?php echo e($systemConfig['success_redirect'] ?? '/'); ?>" placeholder="例如：/user.php"></div>
                <div class="form-item"><label>商城跳转网址（前台「商城」入口）</label><input type="text" name="shop_url" value="<?php echo e($systemConfig['shop_url'] ?? ''); ?>" placeholder="https://你的商城.com"></div>
                <div class="form-item"><label>聚合平台 API 域名（对接惊霄/彩虹惊霄科技官网，如 https://jhdl.你的域名.top）</label><input type="text" name="juhe_host" value="<?php echo e($systemConfig['juhe_host'] ?? ''); ?>" placeholder="https://jhdl.域名.top"></div>
                <div class="form-actions"><button class="btn btn-primary" type="submit">保存跳转设置</button></div>
            </form>
        </div>

        <?php elseif ($tab === 'admin'): ?>
        <!-- ===== 管理员：我的账号 / 分管理员（超级管理员可见） ===== -->
        <div class="admin-head">
            <h1>管理员</h1>
            <span class="badge"><?php echo $isSuper ? '超级管理员（全部权限）' : '分管理员'; ?> · <?php echo e($admin['username']); ?></span>
        </div>

        <div class="setup-grid">
            <!-- 我的账号 -->
            <div class="ad-panel">
                <h3>我的账号</h3>
                <div class="form-item"><label>用户名</label><input type="text" value="<?php echo e($admin['username']); ?>" disabled></div>
                <div class="form-item"><label>角色</label><input type="text" value="<?php echo $isSuper ? '超级管理员（全部权限）' : '分管理员'; ?>" disabled></div>
                <div class="form-item"><label>可访问模块</label><input type="text" value="<?php echo e(admin_perm_text($admin)); ?>" disabled></div>
                <div class="form-item"><label>上次登录</label><input type="text" value="<?php echo e(($admin['last_login'] ?: '—') . ($admin['last_ip'] !== '' ? '（' . $admin['last_ip'] . '）' : '')); ?>" disabled></div>

                <h3 style="margin-top:20px">修改我的密码</h3>
                <form method="post" action="save_config.php?type=password">
                    <div class="form-item"><label>当前密码</label><input type="password" name="old_pwd" required autocomplete="current-password"></div>
                    <div class="form-item"><label>新密码（至少 6 位）</label><input type="password" name="new_pwd" required minlength="6" autocomplete="new-password"></div>
                    <div class="form-item"><label>确认新密码</label><input type="password" name="new_pwd2" required minlength="6" autocomplete="new-password"></div>
                    <div class="form-actions"><button class="btn btn-primary" type="submit">修改密码</button></div>
                </form>
            </div>

            <!-- 新增 / 编辑分管理员（仅超级管理员） -->
            <?php if ($isSuper): ?>
            <div class="ad-panel">
                <h3><?php echo $editAdmin ? '编辑管理员：' . e($editAdmin['username']) : '新增分管理员'; ?></h3>
                <p class="dim" style="font-size:13px;margin-bottom:14px">勾选该账号可访问的后台模块；超级管理员默认拥有全部模块。</p>
                <form method="post" action="save_config.php?type=admin_save">
                    <input type="hidden" name="id" value="<?php echo $editAdmin ? (int)$editAdmin['id'] : 0; ?>">
                    <div class="form-item"><label>用户名</label><input type="text" name="username" required maxlength="30" value="<?php echo $editAdmin ? e($editAdmin['username']) : ''; ?>" placeholder="2-30 位中英文/数字"></div>
                    <div class="form-item">
                        <label>密码<?php echo $editAdmin ? '（留空表示不修改）' : '（至少 6 位）'; ?></label>
                        <input type="text" name="password" autocomplete="off" placeholder="<?php echo $editAdmin ? '留空不修改' : '至少 6 位'; ?>">
                    </div>
                    <div class="form-item"><label>角色</label>
                        <select name="role">
                            <option value="sub" <?php echo ($editAdmin && $editAdmin['role'] === 'super') ? '' : 'selected'; ?>>分管理员（按下方勾选授权）</option>
                            <option value="super" <?php echo ($editAdmin && $editAdmin['role'] === 'super') ? 'selected' : ''; ?>>超级管理员（全部权限）</option>
                        </select>
                    </div>
                    <div class="form-item"><label>可访问模块</label>
                        <div class="chip-grid">
                            <?php $checkedPerms = $editAdmin ? admin_perms_of($editAdmin) : []; ?>
                            <?php foreach ($moduleMap as $permKey => $permLabel): ?>
                            <label class="chip" style="cursor:pointer">
                                <input type="checkbox" name="perms[]" value="<?php echo e($permKey); ?>" <?php echo in_array($permKey, $checkedPerms, true) ? 'checked' : ''; ?> style="width:auto;margin-right:2px">
                                <?php echo e($permLabel); ?>
                            </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <div class="form-item"><label>备注（选填）</label><input type="text" name="remark" maxlength="200" value="<?php echo $editAdmin ? e($editAdmin['remark']) : ''; ?>" placeholder="例如：运营小编 / 客服"></div>
                    <div class="form-item">
                        <label class="switch">
                            <input type="checkbox" name="status" value="1" <?php echo (!$editAdmin || (int)$editAdmin['status'] === 1) ? 'checked' : ''; ?>>
                            <span class="slider"></span><span class="switch-text">启用该管理员账号</span>
                        </label>
                    </div>
                    <div class="form-actions">
                        <button class="btn btn-primary" type="submit"><?php echo $editAdmin ? '保存修改' : '新增管理员'; ?></button>
                        <?php if ($editAdmin): ?><a class="btn btn-ghost" href="index.php?tab=admin">取消编辑</a><?php endif; ?>
                    </div>
                </form>
            </div>
            <?php endif; ?>
        </div>

        <?php if ($isSuper): ?>
        <div class="ad-panel">
            <h3>管理员列表</h3>
            <table class="log-table">
                <thead><tr><th>用户名</th><th>角色</th><th>可访问模块</th><th>状态</th><th>最后登录</th><th>操作</th></tr></thead>
                <tbody>
                <?php foreach (admin_list($conn) as $a):
                    $selfRow = ((int)$a['id'] === (int)$admin['id']);
                    $lastSuper = ($a['role'] === 'super') && admin_super_count($conn, (int)$a['id']) === 0;
                    $canDelete = !$selfRow && !$lastSuper;
                ?>
                <tr>
                    <td>
                        <?php echo e($a['username']); ?>
                        <?php if ($selfRow): ?><span class="badge" style="margin-left:6px">当前登录</span><?php endif; ?>
                        <?php if ($a['remark'] !== ''): ?><span class="dim" style="font-size:12px">（<?php echo e($a['remark']); ?>）</span><?php endif; ?>
                    </td>
                    <td><?php echo $a['role'] === 'super' ? '<span class="ok-tag">超级管理员</span>' : '分管理员'; ?></td>
                    <td class="dim" style="font-size:12px"><?php echo e(admin_perm_text($a)); ?></td>
                    <td><?php echo (int)$a['status'] === 1 ? '<span class="ok-tag">启用</span>' : '<span class="no-tag">停用</span>'; ?></td>
                    <td class="dim" style="font-size:12px"><?php echo e($a['last_login'] ?: '—'); ?></td>
                    <td class="ops">
                        <a class="btn btn-sm btn-ghost" href="index.php?tab=admin&amp;edit=<?php echo (int)$a['id']; ?>">编辑</a>
                        <?php if ($canDelete): ?>
                        <form method="post" action="save_config.php?type=admin_delete" style="display:inline" onsubmit="return confirm('确定删除管理员「<?php echo e($a['username']); ?>」？');">
                            <input type="hidden" name="id" value="<?php echo (int)$a['id']; ?>">
                            <button class="btn btn-sm btn-danger" type="submit">删除</button>
                        </form>
                        <?php else: ?>
                        <span class="dim" style="font-size:12px">—</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <p class="form-tip" style="margin-top:12px">说明：管理员可以直接在「跳转设置」里配置商城入口；分管理员只能看到被勾选的模块，未勾选的模块即便直接输入地址也会被拦截。</p>
        </div>
        <?php endif; ?>

        <?php endif; ?>
        <?php endif; /* !$tabAllowed */ ?>
    </div>
</div>

<script src="../assets/js/main.js"></script>
</body>
</html>
