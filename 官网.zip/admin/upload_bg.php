<?php
/**
 * 上传登录页背景图片
 */
require __DIR__ . '/../config.php';
admin_guard($conn, 'appearance'); // 需「登录页设置」权限

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_FILES['bg_file'])) {
    redirect('index.php?tab=appearance&msg=' . urlencode('未收到文件'));
}

$file = $_FILES['bg_file'];
$error = '';
if ($file['error'] !== UPLOAD_ERR_OK) {
    $error = '上传失败，错误码：' . $file['error'];
}
if (!$error && $file['size'] > 2 * 1024 * 1024) {
    $error = '图片不能超过 2MB';
}

$allowTypes = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
$mime = $file['type'];
if (!$error && !isset($allowTypes[$mime])) {
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    if (!isset($allowTypes[$mime])) {
        $error = '仅支持 jpg / png / webp 格式';
    }
}

if ($error) {
    redirect('index.php?tab=appearance&msg=' . urlencode($error));
}

$ext = $allowTypes[$mime];
$filename = 'bg_' . date('Ymd') . '_' . substr(md5(uniqid('', true)), 0, 10) . '.' . $ext;
$uploadDir = __DIR__ . '/../assets/uploads/';
if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

if (move_uploaded_file($file['tmp_name'], $uploadDir . $filename)) {
    chmod($uploadDir . $filename, 0644);
    $rel = mysqli_real_escape_string($conn, 'assets/uploads/' . $filename);
    mysqli_query($conn, "UPDATE system_config SET value='$rel' WHERE key_name='login_bg'");
    redirect('index.php?tab=appearance&msg=' . urlencode('背景图片已上传并应用'));
} else {
    redirect('index.php?tab=appearance&msg=' . urlencode('保存失败，请检查 assets/uploads 目录权限'));
}
