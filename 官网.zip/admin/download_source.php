<?php
/**
 * 下载源码：将整个项目打包为 zip 下载（需 zip 扩展）
 */
require __DIR__ . '/../config.php';
admin_guard($conn, '__super'); // 源码打包下载仅超级管理员可用

if (!class_exists('ZipArchive')) {
    die('服务器未启用 zip 扩展，无法打包下载');
}

$root = realpath(__DIR__ . '/../');
$tmp = tempnam(sys_get_temp_dir(), 'src_');
$zip = new ZipArchive();
$zip->open($tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE);

$exclude = [
    'install.lock',         // 不打包安装锁
    $root . '/admin/',      // 后台源码一并打包（包含）
];
// 递归添加（排除 install.lock）
$iterator = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS)
);
foreach ($iterator as $file) {
    $path = $file->getPathname();
    if (basename($path) === 'install.lock') continue;
    if (is_file($path)) {
        $local = ltrim(str_replace($root, '', $path), DIRECTORY_SEPARATOR);
        $zip->addFile($path, $local);
    }
}
$zip->close();

header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="juhelogin-source-' . date('Ymd') . '.zip"');
header('Content-Length: ' . filesize($tmp));
readfile($tmp);
unlink($tmp);
exit;
