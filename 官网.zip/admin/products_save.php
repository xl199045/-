<?php
/**
 * 产品保存：新增 / 更新 / 删除 / 上下架 / 图片上传
 */
require __DIR__ . '/../config.php';
admin_guard($conn, 'products'); // 需「产品管理」权限

$act = $_GET['act'] ?? ($_POST['act'] ?? '');

/* ===== 删除 ===== */
if ($act === 'delete') {
    $id = (int)($_GET['id'] ?? 0);
    if ($id) {
        $res = mysqli_query($conn, "SELECT image FROM products WHERE id=$id");
        if ($img = mysqli_fetch_assoc($res)) {
            if (!empty($img['image']) && strpos($img['image'], 'assets/uploads/') === 0) {
                $f = __DIR__ . '/../' . $img['image'];
                if (is_file($f)) @unlink($f);
            }
        }
        mysqli_query($conn, "DELETE FROM products WHERE id=$id");
    }
    redirect('products.php');
}

/* ===== 上下架 ===== */
if ($act === 'toggle') {
    $id = (int)($_GET['id'] ?? 0);
    $status = (int)($_GET['status'] ?? 0);
    if ($id) {
        mysqli_query($conn, "UPDATE products SET status=" . ($status ? 1 : 0) . " WHERE id=$id");
    }
    redirect('products.php');
}

/* ===== 保存（新增/更新） ===== */
if ($act === 'save') {
    $id = (int)($_POST['id'] ?? 0);
    $name = mysqli_real_escape_string($conn, trim($_POST['name'] ?? ''));
    if ($name === '') {
        redirect('products.php?msg=' . urlencode('产品名称不能为空'));
    }
    $description = mysqli_real_escape_string($conn, trim($_POST['description'] ?? ''));
    $price = mysqli_real_escape_string($conn, trim($_POST['price'] ?? ''));
    $sort = (int)($_POST['sort'] ?? 0);
    $status = isset($_POST['status']) ? 1 : 0;
    $image = trim($_POST['image_url'] ?? '');

    // 图片上传
    if (!empty($_FILES['image_file']['name']) && $_FILES['image_file']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['image_file'];
        $allowTypes = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
        if ($file['size'] > 2 * 1024 * 1024) {
            redirect('products.php?msg=' . urlencode('图片不能超过 2MB'));
        }
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        if (!isset($allowTypes[$mime])) {
            redirect('products.php?msg=' . urlencode('仅支持 jpg / png / webp 格式'));
        }
        $dir = __DIR__ . '/../assets/uploads/products/';
        if (!is_dir($dir)) mkdir($dir, 0755, true);
        $filename = 'p_' . date('Ymd') . '_' . substr(md5(uniqid('', true)), 0, 10) . '.' . $allowTypes[$mime];
        if (move_uploaded_file($file['tmp_name'], $dir . $filename)) {
            chmod($dir . $filename, 0644);
            $image = 'assets/uploads/products/' . $filename;
            // 删除旧图
            if ($id) {
                $old = mysqli_fetch_assoc(mysqli_query($conn, "SELECT image FROM products WHERE id=$id"));
                if ($old && !empty($old['image']) && strpos($old['image'], 'assets/uploads/') === 0 && $old['image'] !== $image) {
                    $f = __DIR__ . '/../' . $old['image'];
                    if (is_file($f)) @unlink($f);
                }
            }
        } else {
            redirect('products.php?msg=' . urlencode('图片保存失败，请检查目录权限'));
        }
    }

    $imageEsc = mysqli_real_escape_string($conn, $image);

    if ($id) {
        mysqli_query($conn, "UPDATE products SET name='$name', description='$description', price='$price', image='$imageEsc', status=$status, sort=$sort WHERE id=$id");
    } else {
        mysqli_query($conn, "INSERT INTO products (name, description, price, image, status, sort) VALUES ('$name', '$description', '$price', '$imageEsc', $status, $sort)");
    }
    redirect('products.php');
}

redirect('products.php');
