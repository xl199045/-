/* 个人中心交互：资料保存 / 改密码 / 换绑邮箱 / 绑定手机号 / 解绑渠道 */
(function () {
    'use strict';
    if (!window.UC) return;

    var CFG = window.UC;

    function val(id) {
        var el = document.getElementById(id);
        return el ? el.value.trim() : '';
    }

    function post(action, data, extra) {
        var body = new URLSearchParams();
        body.append('action', action);
        body.append('csrf', CFG.csrf);
        var payload = Object.assign({}, data || {}, extra || {});
        Object.keys(payload).forEach(function (k) { body.append(k, payload[k]); });
        return fetch(CFG.url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            credentials: 'same-origin',
            body: body.toString()
        }).then(function (r) { return r.json(); });
    }

    function tip(id, text, ok) {
        var el = document.getElementById(id);
        if (!el) return;
        el.textContent = text || '';
        el.style.color = ok ? '#34d399' : '#f87171';
    }

    function toast(text, ok) {
        var el = document.getElementById('ucToast');
        if (!el) return;
        el.textContent = text || '';
        el.className = ok ? 'msg-ok' : 'msg-error';
        el.style.display = 'block';
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    function reloadSoon(delay) {
        setTimeout(function () { location.reload(); }, delay || 800);
    }

    /* 内联面板展开 / 收起 */
    document.querySelectorAll('.js-toggle').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var panel = document.getElementById(btn.dataset.panel);
            if (!panel) return;
            var hidden = !panel.style.display || panel.style.display === 'none';
            panel.style.display = hidden ? 'block' : 'none';
            if (hidden) panel.scrollIntoView({ behavior: 'smooth', block: 'center' });
        });
    });

    /* 验证码按钮倒数 */
    function cooldown(btn) {
        var left = 60;
        var raw = btn.textContent;
        btn.disabled = true;
        btn.textContent = left + 's';
        var timer = setInterval(function () {
            left--;
            if (left <= 0) {
                clearInterval(timer);
                btn.disabled = false;
                btn.textContent = raw;
            } else {
                btn.textContent = left + 's';
            }
        }, 1000);
    }

    /* 保存用户名 / 昵称 */
    var saveBtn = document.getElementById('saveProfileBtn');
    if (saveBtn) {
        saveBtn.addEventListener('click', function () {
            saveBtn.disabled = true;
            post('save_profile', { username: val('ucUsername'), nickname: val('ucNickname') })
                .then(function (res) {
                    toast(res.msg, res.ok);
                    if (res.ok) reloadSoon();
                    else saveBtn.disabled = false;
                })
                .catch(function () { toast('网络错误，请重试', false); saveBtn.disabled = false; });
        });
    }

    /* 修改 / 设置密码 */
    var pwdBtn = document.getElementById('changePwdBtn');
    if (pwdBtn) {
        pwdBtn.addEventListener('click', function () {
            var data = {
                old_password: val('oldPwd'),
                new_password: val('newPwd'),
                confirm_password: val('confirmPwd')
            };
            if (!data.new_password) { tip('pwdTip', '请输入新密码', false); return; }
            if (data.new_password !== data.confirm_password) { tip('pwdTip', '两次输入的新密码不一致', false); return; }
            pwdBtn.disabled = true;
            post('change_password', data).then(function (res) {
                tip('pwdTip', res.msg, res.ok);
                toast(res.msg, res.ok);
                pwdBtn.disabled = false;
                if (res.ok) {
                    ['oldPwd', 'newPwd', 'confirmPwd'].forEach(function (id) {
                        var el = document.getElementById(id);
                        if (el) el.value = '';
                    });
                }
            }).catch(function () { tip('pwdTip', '网络错误，请重试', false); pwdBtn.disabled = false; });
        });
    }

    /* 发送邮箱验证码 */
    var sendEmailBtn = document.getElementById('sendEmailCodeBtn');
    if (sendEmailBtn) {
        sendEmailBtn.addEventListener('click', function () {
            var email = val('newEmail');
            if (!email) { tip('emailTip', '请输入新邮箱', false); return; }
            tip('emailTip', '正在发送…', true);
            post('send_email_code', { email: email }).then(function (res) {
                tip('emailTip', res.msg, res.ok);
                if (res.ok) cooldown(sendEmailBtn);
            }).catch(function () { tip('emailTip', '网络错误，请重试', false); });
        });
    }

    /* 绑定 / 换绑邮箱 */
    var bindEmailBtn = document.getElementById('bindEmailBtn');
    if (bindEmailBtn) {
        bindEmailBtn.addEventListener('click', function () {
            bindEmailBtn.disabled = true;
            post('bind_email', { email: val('newEmail'), code: val('emailCode') }).then(function (res) {
                tip('emailTip', res.msg, res.ok);
                toast(res.msg, res.ok);
                bindEmailBtn.disabled = false;
                if (res.ok) reloadSoon();
            }).catch(function () { tip('emailTip', '网络错误，请重试', false); bindEmailBtn.disabled = false; });
        });
    }

    /* 发送手机验证码 */
    var sendPhoneBtn = document.getElementById('sendPhoneCodeBtn');
    if (sendPhoneBtn) {
        sendPhoneBtn.addEventListener('click', function () {
            var phone = val('newPhone');
            if (!phone) { tip('phoneTip', '请输入手机号', false); return; }
            tip('phoneTip', '正在发送…', true);
            post('send_phone_code', { phone: phone }).then(function (res) {
                tip('phoneTip', res.msg, res.ok);
                if (res.ok) cooldown(sendPhoneBtn);
            }).catch(function () { tip('phoneTip', '网络错误，请重试', false); });
        });
    }

    /* 绑定手机号 */
    var bindPhoneBtn = document.getElementById('bindPhoneBtn');
    if (bindPhoneBtn) {
        bindPhoneBtn.addEventListener('click', function () {
            bindPhoneBtn.disabled = true;
            post('bind_phone', { phone: val('newPhone'), code: val('phoneCode') }).then(function (res) {
                tip('phoneTip', res.msg, res.ok);
                toast(res.msg, res.ok);
                bindPhoneBtn.disabled = false;
                if (res.ok) reloadSoon();
            }).catch(function () { tip('phoneTip', '网络错误，请重试', false); bindPhoneBtn.disabled = false; });
        });
    }

    /* 解绑第三方渠道 */
    document.querySelectorAll('.js-unbind').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var channel = btn.dataset.channel;
            var title = btn.dataset.title || channel;
            if (!confirm('确定解绑「' + title + '」吗？解绑后将无法使用该账号登录。')) return;
            btn.disabled = true;
            post('unbind', { channel: channel }).then(function (res) {
                toast(res.msg, res.ok);
                if (res.ok) reloadSoon(500);
                else btn.disabled = false;
            }).catch(function () { toast('网络错误，请重试', false); btn.disabled = false; });
        });
    });

    /* 解绑邮箱 / 手机号 */
    document.querySelectorAll('.js-unbind-email').forEach(function (btn) {
        btn.addEventListener('click', function () {
            if (!confirm('确定解绑邮箱吗？解绑后将无法使用该邮箱接收验证码登录。')) return;
            post('unbind_email', {}).then(function (res) { toast(res.msg, res.ok); if (res.ok) reloadSoon(500); });
        });
    });
    document.querySelectorAll('.js-unbind-phone').forEach(function (btn) {
        btn.addEventListener('click', function () {
            if (!confirm('确定解绑手机号吗？')) return;
            post('unbind_phone', {}).then(function (res) { toast(res.msg, res.ok); if (res.ok) reloadSoon(500); });
        });
    });
})();
