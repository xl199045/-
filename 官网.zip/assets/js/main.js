/* PHP 聚合登录系统 - 前台脚本
   功能：右下角音乐播放器（随机播放 assets/music/*.mp3） */
(function () {
    'use strict';

    var musicList = [];
    var audio = null;
    var currentIndex = -1;

    // 读取 mp3 列表（music.php 返回 {total, files}，files 为完整相对路径）
    function loadMusicList() {
        fetch('music.php')
            .then(function (r) { return r.json(); })
            .then(function (data) {
                musicList = (data && Array.isArray(data.files)) ? data.files : [];
                if (musicList.length > 0 && audio === null) {
                    createPlayer();
                    playRandom();
                }
            })
            .catch(function () { /* 无音乐文件则静默 */ });
    }

    function createPlayer() {
        var wrap = document.createElement('div');
        wrap.id = 'music-player';
        wrap.style.cssText = 'position:fixed;right:18px;bottom:18px;z-index:99;display:flex;align-items:center;gap:8px;background:rgba(15,23,42,.85);border:1px solid #334155;border-radius:999px;padding:6px 14px;font-size:13px;color:#e2e8f0;backdrop-filter:blur(8px);box-shadow:0 8px 24px rgba(0,0,0,.4);cursor:pointer;user-select:none;';

        var icon = document.createElement('span');
        icon.textContent = '▶';
        icon.style.cssText = 'color:#22d3ee;font-size:12px;width:16px;text-align:center;';
        var label = document.createElement('span');
        label.textContent = '背景音乐';
        label.style.cssText = 'max-width:110px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;';

        wrap.appendChild(icon);
        wrap.appendChild(label);
        document.body.appendChild(wrap);

        wrap.addEventListener('click', function () {
            if (audio) {
                if (audio.paused) { audio.play(); icon.textContent = '❚❚'; }
                else { audio.pause(); icon.textContent = '▶'; }
            }
        });

        window.__musicIcon = icon;
        window.__musicLabel = label;
    }

    function setTitle(name) {
        if (window.__musicLabel) {
            window.__musicLabel.textContent = name || '背景音乐';
        }
    }

    function playRandom() {
        if (musicList.length === 0) return;
        var idx = Math.floor(Math.random() * musicList.length);
        currentIndex = idx;
        // music.php 已返回完整相对路径 assets/music/xxx.mp3
        var src = musicList[idx];
        if (!audio) {
            audio = new Audio();
            audio.volume = 0.25;
            audio.addEventListener('ended', function () { playRandom(); });
        }
        audio.src = src;
        audio.play().catch(function () { /* 浏览器限制时静默，点击播放器可播放 */ });
        setTitle(musicList[idx].replace(/\.mp3$/i, ''));
        if (window.__musicIcon) window.__musicIcon.textContent = '❚❚';
    }

    window.addEventListener('DOMContentLoaded', loadMusicList);
})();
