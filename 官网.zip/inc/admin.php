<?php
/**
 * 后台管理员角色与权限（超级管理员 / 分管理员）
 *
 * 由 config.php 引入。函数以 admin_ 前缀。
 *   - 超级管理员（super）：全部模块 + 分管理员管理（新增/编辑/删除/授权）
 *   - 分管理员（sub）    ：仅被勾选的模块；「管理员」模块只显示"我的账号"
 * 表结构升级幂等，老站点访问任意页面即完成升级。
 */

// 禁止直接访问（本文件只允许由 config.php 引入）
if (!isset($conn) || !($conn instanceof mysqli)) {
    http_response_code(404);
    exit;
}

/* ==================== 建表升级 ==================== */
function admin_migrate($conn)
{
    $columns = [
        'role'       => "ALTER TABLE `admin_user` ADD COLUMN `role` VARCHAR(20) NOT NULL DEFAULT 'sub' COMMENT 'super=超级管理员 sub=分管理员' AFTER `password`",
        'perms'      => "ALTER TABLE `admin_user` ADD COLUMN `perms` TEXT NULL COMMENT '分管理员可访问模块JSON' AFTER `role`",
        'status'     => "ALTER TABLE `admin_user` ADD COLUMN `status` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '1启用 0停用' AFTER `perms`",
        'remark'     => "ALTER TABLE `admin_user` ADD COLUMN `remark` VARCHAR(200) NOT NULL DEFAULT '' COMMENT '备注' AFTER `status`",
        'created_at' => "ALTER TABLE `admin_user` ADD COLUMN `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '加入时间' AFTER `remark`",
        'last_login' => "ALTER TABLE `admin_user` ADD COLUMN `last_login` DATETIME DEFAULT NULL AFTER `created_at`",
        'last_ip'    => "ALTER TABLE `admin_user` ADD COLUMN `last_ip` VARCHAR(64) NOT NULL DEFAULT '' AFTER `last_login`",
    ];
    foreach ($columns as $col => $sql) {
        $res = mysqli_query($conn, "SHOW COLUMNS FROM `admin_user` LIKE '{$col}'");
        if ($res && mysqli_num_rows($res) === 0) {
            mysqli_query($conn, $sql);
        }
    }
    // 升级后若没有任何超级管理员，把最早的账号设为超级管理员（避免出现无人可管理的状态）
    $res = mysqli_query($conn, "SELECT COUNT(*) AS n FROM `admin_user` WHERE `role` = 'super'");
    $n = ($res && ($row = mysqli_fetch_assoc($res))) ? (int)$row['n'] : 0;
    if ($n === 0) {
        mysqli_query($conn, "UPDATE `admin_user` SET `role` = 'super' WHERE `id` = (SELECT MIN(id) FROM (SELECT id FROM `admin_user`) AS t)");
    }
}

/* ==================== 模块（权限）定义 ==================== */
function admin_module_map()
{
    return [
        'dashboard'  => '概览',
        'products'   => '产品管理',
        'companies'  => '合作企业',
        'platforms'  => '渠道管理',
        'appearance' => '登录页设置',
        'smtp'       => '邮箱设置',
        'redirect'   => '跳转设置',
    ];
}

/* ==================== 会话 / 当前管理员 ==================== */
function admin_row($conn, $id)
{
    $id = (int)$id;
    if ($id <= 0) return null;
    $res = mysqli_query($conn, "SELECT * FROM `admin_user` WHERE id = {$id} LIMIT 1");
    return ($res && ($row = mysqli_fetch_assoc($res))) ? $row : null;
}

/** 当前登录管理员（已停用/已删除返回 null）；兼容仅写了 admin_login 的老会话 */
function admin_current($conn)
{
    static $cache = false;
    if ($cache !== false) return $cache;

    $id = (int)($_SESSION['admin_id'] ?? 0);
    if ($id <= 0 && !empty($_SESSION['admin_login'])) {
        $name = mysqli_real_escape_string($conn, (string)($_SESSION['admin_name'] ?? ''));
        if ($name !== '') {
            $res = mysqli_query($conn, "SELECT * FROM `admin_user` WHERE `username` = '{$name}' LIMIT 1");
            $row = ($res && ($r = mysqli_fetch_assoc($res))) ? $r : null;
            if ($row) {
                $id = (int)$row['id'];
                admin_set_session($row);
            }
        }
    }

    $row = $id > 0 ? admin_row($conn, $id) : null;
    if ($row && (int)$row['status'] !== 1) $row = null;
    $cache = $row;
    return $row;
}

function admin_set_session($row)
{
    $_SESSION['admin_login'] = true;
    $_SESSION['admin_id']    = (int)$row['id'];
    $_SESSION['admin_name']  = $row['username'];
    $_SESSION['admin_role']  = $row['role'];
    $_SESSION['admin_perms'] = admin_perms_of($row);
}

function admin_clear_session()
{
    unset($_SESSION['admin_login'], $_SESSION['admin_id'], $_SESSION['admin_name'], $_SESSION['admin_role'], $_SESSION['admin_perms']);
}

function admin_is_super($admin)
{
    return $admin && ($admin['role'] ?? '') === 'super';
}

/** 分管理员被勾选的模块列表 */
function admin_perms_of($row)
{
    if (!$row) return [];
    if (($row['role'] ?? '') === 'super') return array_keys(admin_module_map());
    $perms = json_decode((string)($row['perms'] ?? ''), true);
    if (!is_array($perms)) $perms = [];
    return array_values(array_intersect($perms, array_keys(admin_module_map())));
}

function admin_can($admin, $module)
{
    if (!$admin) return false;
    if (($admin['role'] ?? '') === 'super') return true;
    if ($module === '' || $module === 'admin') return true; // 自己的账号对所有管理员开放
    return in_array($module, admin_perms_of($admin), true);
}

/* ==================== 入口守卫 / 拒绝页 ==================== */
function admin_deny($msg)
{
    http_response_code(403);
    echo '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">'
        . '<title>无访问权限</title><link rel="stylesheet" href="../assets/css/style.css"></head><body class="admin-body">'
        . '<div class="container" style="max-width:560px;margin-top:8vh">'
        . '<div class="card glow-card"><h2>无访问权限</h2>'
        . '<p class="dim" style="margin-bottom:12px">' . e($msg) . '</p>'
        . '<p class="msg-error">需要该模块权限时，请让超级管理员在「管理员 → 分管理员」中勾选对应模块。</p>'
        . '<div class="form-actions"><a class="btn btn-primary" href="index.php">返回后台首页</a>'
        . '<a class="btn btn-ghost" href="logout.php">退出登录</a></div></div></div></body></html>';
    exit;
}

/**
 * 后台文件统一守卫
 * @param string $module 需要的模块，'__super' 表示仅超级管理员
 * @param string $loginPath 未登录时跳转的登录页（相对当前目录）
 */
function admin_guard($conn, $module = '', $loginPath = 'login.php')
{
    $admin = admin_current($conn);
    if (!$admin) {
        admin_clear_session();
        redirect($loginPath);
    }
    if ($module === '__super') {
        if (!admin_is_super($admin)) admin_deny('该功能仅超级管理员可用');
        return $admin;
    }
    if ($module !== '' && !admin_can($admin, $module)) {
        $map = admin_module_map();
        admin_deny('当前账号没有「' . ($map[$module] ?? $module) . '」模块的权限');
    }
    return $admin;
}

/* ==================== 密码 ==================== */
/** 校验密码：支持 password_hash，并兼容老的 32 位 MD5（校验通过返回 true） */
function admin_password_verify($row, $password)
{
    $stored = (string)($row['password'] ?? '');
    if ($stored === '') return false;
    // 兼容历史 MD5
    if (strlen($stored) === 32 && ctype_xdigit($stored)) {
        return hash_equals(strtolower($stored), md5((string)$password));
    }
    return password_verify((string)$password, $stored);
}

/** 老 MD5 密码在登录成功后自动升级为 password_hash */
function admin_password_upgrade($conn, $row, $password)
{
    $stored = (string)($row['password'] ?? '');
    if (strlen($stored) === 32 && ctype_xdigit($stored)) {
        $hash = mysqli_real_escape_string($conn, password_hash((string)$password, PASSWORD_DEFAULT));
        mysqli_query($conn, "UPDATE `admin_user` SET `password` = '{$hash}' WHERE id = " . (int)$row['id']);
    }
}

function admin_touch_login($conn, $id)
{
    $ip = mysqli_real_escape_string($conn, $_SERVER['REMOTE_ADDR'] ?? '');
    mysqli_query($conn, "UPDATE `admin_user` SET `last_login` = NOW(), `last_ip` = '{$ip}' WHERE id = " . (int)$id);
}

/* ==================== 分管理员列表 ==================== */
function admin_list($conn)
{
    $out = [];
    $res = mysqli_query($conn, "SELECT * FROM `admin_user` ORDER BY (role = 'super') DESC, id ASC");
    if ($res) {
        while ($row = mysqli_fetch_assoc($res)) $out[] = $row;
    }
    return $out;
}

function admin_super_count($conn, $excludeId = 0)
{
    $res = mysqli_query($conn, "SELECT COUNT(*) AS n FROM `admin_user` WHERE `role` = 'super' AND `status` = 1 AND id <> " . (int)$excludeId);
    return ($res && ($row = mysqli_fetch_assoc($res))) ? (int)$row['n'] : 0;
}

function admin_perm_text($row)
{
    if (!$row) return '';
    if (($row['role'] ?? '') === 'super') return '全部模块';
    $map = admin_module_map();
    $names = [];
    foreach (admin_perms_of($row) as $k) {
        $names[] = $map[$k] ?? $k;
    }
    return $names ? implode('、', $names) : '未授权';
}

/* 引入时立即升级表结构（幂等） */
if (isset($conn) && $conn instanceof mysqli) {
    admin_migrate($conn);
}
