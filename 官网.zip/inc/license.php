<?php
/**
 * 授权验证（对接惊霄授权系统 / 小笑授权系统 V7 的 /check.php）
 *
 * 用途：
 *   - 安装前校验：install/index.php 引入本文件，未授权不允许安装
 *   - 后台状态展示：admin/index.php 概览显示「已授权 / 未授权」
 *
 * 特点：
 *   - 不依赖数据库（config.php 尚未生成时也能在安装页使用）
 *   - 校验结果带文件缓存（inc/license.cache.php），避免每次访问都请求云端
 *   - 云端不可达时给出明确提示，不误判为「已授权」
 *
 * 配置：
 *   - inc/license.config.php   授权系统地址 / 应用 UID / 应用授权密钥（程序作者填写）
 *   - inc/license.authcode.php 授权码（授权系统下载安装包时自动注入，或在后台「授权状态」里填写）
 */

/**
 * 读取授权配置（host 去掉结尾斜杠；数字/空值归一化）
 */
function license_config()
{
    static $cfg = null;
    if ($cfg !== null) return $cfg;

    $cfg = [
        'host'      => '',
        'app_uid'   => '',
        'app_name'  => '',
        'app_key'   => '',
        'authcode'  => '',
        'cache_ttl' => 43200,
    ];
    $file = __DIR__ . '/license.config.php';
    if (is_file($file)) {
        $custom = include $file;
        if (is_array($custom)) {
            foreach ($custom as $k => $v) {
                if (array_key_exists($k, $cfg) && $v !== null && $v !== '') $cfg[$k] = $v;
            }
        }
    }
    $cfg['host']      = rtrim((string)$cfg['host'], '/');
    $cfg['app_uid']   = trim((string)$cfg['app_uid']);
    $cfg['app_name']  = trim((string)$cfg['app_name']);
    $cfg['app_key']   = trim((string)$cfg['app_key']);
    $cfg['authcode']  = trim((string)$cfg['authcode']);
    $cfg['cache_ttl'] = max(60, (int)$cfg['cache_ttl']);
    return $cfg;
}

/* ==================== 授权码（后台填写 / 授权系统注入） ==================== */

/** 授权码存放文件：格式与惊霄授权系统「程序管理 → 授权文件路径」注入模板一致（$authcode='...';） */
function license_authcode_file()
{
    return __DIR__ . '/license.authcode.php';
}

/** 读取当前授权码：优先授权码文件（授权系统下载安装包时自动注入、或后台填写），其次 inc/license.config.php */
function license_stored_authcode()
{
    $code = '';
    $file = license_authcode_file();
    if (is_file($file)) {
        $authcode = null;
        $ret = include $file;
        if (is_string($ret) && $ret !== '') {
            $code = $ret;
        } elseif (is_string($authcode)) {
            $code = $authcode;
        }
    }
    if (trim($code) === '') {
        $c = license_config();
        $code = (string)$c['authcode'];
    }
    return trim($code);
}

/** 授权码来源描述（后台 / 安装页展示用） */
function license_authcode_source()
{
    if (is_file(license_authcode_file()) && license_stored_authcode() !== '') {
        return 'inc/license.authcode.php（授权系统下载安装包时自动注入，或在后台填写的授权码）';
    }
    if (trim((string)(license_config()['authcode'])) !== '') {
        return 'inc/license.config.php';
    }
    return '未填写';
}

/** 写入授权码（与授权系统注入模板同格式，注入后仍可直接读取） */
function license_save_authcode($code)
{
    $code = trim((string)$code);
    $content = "<?php\n\$authcode=" . var_export($code, true) . ";\n\n?>\n";
    if (@file_put_contents(license_authcode_file(), $content, LOCK_EX) === false) return false;
    @chmod(license_authcode_file(), 0644);
    return true;
}

/** 授权码文件是否可写（后台提示用） */
function license_authcode_writable()
{
    $file = license_authcode_file();
    return is_file($file) ? is_writable($file) : is_writable(dirname($file));
}

/** 还缺哪些授权参数（用于提示文案） */
function license_missing_items($authcode = null)
{
    $c = license_config();
    $miss = [];
    if ($c['host'] === '')    $miss[] = '授权系统地址';
    if ($c['app_uid'] === '') $miss[] = '应用 UID';
    if ($c['app_key'] === '') $miss[] = '应用授权密钥';
    $code = ($authcode !== null && trim((string)$authcode) !== '') ? trim((string)$authcode) : license_stored_authcode();
    if ($code === '')         $miss[] = '授权码';
    return $miss;
}

/** 授权信息是否已填写完整（授权码可来自输入框 / 授权码文件 / 配置文件） */
function license_configured($authcode = null)
{
    return license_missing_items($authcode) === [];
}

/**
 * 小笑授权系统同款加解密（与云端 check.php 保持一致，PHP 7.4 / 8.x 均可用）
 */
function license_authcode_crypt($string, $operation = 'DECODE', $key = '', $expiry = 0)
{
    $ckey_length = 4;
    $string = (string)$string;
    $key = md5($key);
    $keya = md5(substr($key, 0, 16));
    $keyb = md5(substr($key, 16, 16));
    $keyc = $ckey_length ? ($operation == 'DECODE' ? substr($string, 0, $ckey_length) : substr(md5(microtime()), -$ckey_length)) : '';
    $cryptkey = $keya . md5($keya . $keyc);
    $key_length = strlen($cryptkey);
    $string = $operation == 'DECODE'
        ? (string)base64_decode(substr($string, $ckey_length))
        : sprintf('%010d', $expiry ? $expiry + time() : 0) . substr(md5($string . $keyb), 0, 16) . $string;
    $string_length = strlen($string);
    $result = '';
    $box = range(0, 255);
    $rndkey = [];
    for ($i = 0; $i <= 255; $i++) {
        $rndkey[$i] = ord($cryptkey[$i % $key_length]);
    }
    for ($j = $i = 0; $i < 256; $i++) {
        $j = ($j + $box[$i] + $rndkey[$i]) % 256;
        $tmp = $box[$i];
        $box[$i] = $box[$j];
        $box[$j] = $tmp;
    }
    for ($a = $j = $i = 0; $i < $string_length; $i++) {
        $a = ($a + 1) % 256;
        $j = ($j + $box[$a]) % 256;
        $tmp = $box[$a];
        $box[$a] = $box[$j];
        $box[$j] = $tmp;
        $result .= chr(ord($string[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
    }
    if ($operation == 'DECODE') {
        if (((int)substr($result, 0, 10) == 0 || (int)substr($result, 0, 10) - time() > 0)
            && substr($result, 10, 16) == substr(md5(substr($result, 26) . $keyb), 0, 16)) {
            return substr($result, 26);
        }
        return '';
    }
    return $keyc . str_replace('=', '', base64_encode($result));
}

/** 简单 GET（curl 优先，失败回退 file_get_contents） */
function license_http_get($url, $timeout = 5)
{
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; jingxiao-license/1.0)');
        $ret = curl_exec($ch);
        curl_close($ch);
        if ($ret !== false && $ret !== '') return $ret;
    }
    if (ini_get('allow_url_fopen')) {
        $ctx = stream_context_create(['http' => ['timeout' => $timeout, 'method' => 'GET']]);
        $ret = @file_get_contents($url, false, $ctx);
        if ($ret !== false) return $ret;
    }
    return '';
}

/**
 * 实时向授权云端校验一次（不读缓存）
 * @param string|null $host     要校验的域名，默认取当前访问域名
 * @param string|null $authcode 授权码，默认取已保存的授权码（授权码文件 → 配置文件）
 * @return array ok/code/msg/name/host/checked_at/cached
 */
function license_query($host = null, $authcode = null)
{
    $cfg  = license_config();
    $host = ($host !== null && $host !== '') ? $host : (string)($_SERVER['HTTP_HOST'] ?? '');
    $code = ($authcode !== null && trim((string)$authcode) !== '') ? trim((string)$authcode) : license_stored_authcode();

    $res = [
        'ok'         => false,
        'code'       => 0,
        'msg'        => '',
        'name'       => '',
        'host'       => $host,
        'checked_at' => time(),
        'cached'     => false,
    ];

    $miss = license_missing_items($code);
    if ($miss) {
        $res['code'] = -4;
        $res['msg']  = '授权信息未配置：还缺 ' . implode('、', $miss);
        return $res;
    }
    if ($host === '') {
        $res['code'] = -6;
        $res['msg']  = '无法确定当前域名，请通过绑定的域名访问后再校验';
        return $res;
    }

    $url = $cfg['host'] . '/check.php?url=' . urlencode($host)
         . '&authcode=' . urlencode($code)
         . '&app_uid=' . urlencode($cfg['app_uid']);
    $raw = license_http_get($url);

    if ($raw === '') {
        $res['code'] = -2;
        $res['msg']  = '授权云端连接失败：请确认服务器可以访问 ' . $cfg['host'];
        return $res;
    }
    $json = json_decode($raw, true);
    if (!is_array($json) || empty($json['data'])) {
        $res['code'] = -3;
        $res['msg']  = '授权云端返回异常，请稍后重试';
        return $res;
    }

    $plain = license_authcode_crypt(base64_decode((string)$json['data'], true) ?: '', 'DECODE', $cfg['app_key']);
    $data  = $plain !== '' ? json_decode($plain, true) : null;
    if (!is_array($data)) {
        $res['code'] = -5;
        $res['msg']  = '授权密钥校验失败：请核对「应用授权密钥」是否与授权系统内该应用一致';
        return $res;
    }

    $res['code'] = (int)($data['code'] ?? -1);
    $res['ok']   = $res['code'] === 1;
    $res['name'] = (string)($data['name'] ?? '');
    if ($res['name'] === '') $res['name'] = (string)$cfg['app_name'];
    if ($res['ok']) {
        $res['msg'] = '已授权';
    } else {
        // 云端未授权提示文案可能为空（应用里没填），此时给出兜底文案
        $cloudMsg = trim((string)($data['msg'] ?? ''));
        $res['msg'] = $cloudMsg !== ''
            ? $cloudMsg
            : '未授权：本站域名未加入授权列表（授权系统 → 授权列表），请添加授权后重新校验';
    }
    return $res;
}

/* ==================== 缓存 ==================== */

function license_cache_file()
{
    return __DIR__ . '/license.cache.php';
}

function license_cache_read()
{
    $f = license_cache_file();
    if (!is_file($f)) return [];
    $data = @include $f;
    return is_array($data) ? $data : [];
}

function license_cache_write(array $all)
{
    // 只保留最近 5 个域名的结果，避免文件无限增长
    if (count($all) > 5) $all = array_slice($all, -5, 5, true);
    $php = "<?php\n// 授权校验缓存（自动生成，可安全删除；删除后会自动重新校验）\nreturn " . var_export($all, true) . ";\n";
    return @file_put_contents(license_cache_file(), $php, LOCK_EX) !== false;
}

function license_cache_clear()
{
    $f = license_cache_file();
    if (is_file($f)) @unlink($f);
}

/**
 * 取授权状态（默认读缓存；缓存过期或换了域名会自动重新校验）
 * @param bool        $force    忽略缓存强制校验
 * @param string|null $authcode 指定授权码（后台/安装页输入框验证用）：直接实测，不读写缓存
 */
function license_status($force = false, $authcode = null)
{
    $cfg  = license_config();
    $host = (string)($_SERVER['HTTP_HOST'] ?? '');

    if ($authcode !== null && trim((string)$authcode) !== '') {
        return license_query($host, $authcode);
    }

    $all  = license_cache_read();
    $hit  = ($host !== '' && isset($all[$host]) && is_array($all[$host])) ? $all[$host] : null;

    if (!$force && $hit) {
        $ttl = !empty($hit['ok']) ? $cfg['cache_ttl'] : 600;
        if ((int)($hit['checked_at'] ?? 0) + $ttl > time()) {
            $hit['cached'] = true;
            return $hit;
        }
    }

    $fresh = license_query($host);
    if ($host !== '') {
        $all[$host] = $fresh;
        license_cache_write($all);
    }
    return $fresh;
}

function license_is_authorized($force = false)
{
    $s = license_status($force);
    return !empty($s['ok']);
}

/* ==================== 展示辅助 ==================== */

/** 已授权 / 未授权 徽标 */
function license_badge(array $status)
{
    if (!empty($status['ok'])) {
        return '<span class="badge" style="background:rgba(16,185,129,.15);color:#34d399;border-color:rgba(16,185,129,.4)">已授权</span>';
    }
    return '<span class="badge" style="background:rgba(239,68,68,.15);color:#f87171;border-color:rgba(239,68,68,.4)">未授权</span>';
}

/** 状态文字 */
function license_status_text(array $status)
{
    return !empty($status['ok']) ? '已授权' : '未授权';
}
