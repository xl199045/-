<?php
// 授权校验缓存（自动生成，可安全删除；删除后会自动重新校验）
return array (
  'zfdj.xn--keu002j.top' => 
  array (
    'ok' => true,
    'code' => 1,
    'msg' => '已授权',
    'name' => '官网',
    'host' => 'zfdj.xn--keu002j.top',
    'checked_at' => 1790680186,
    'cached' => false,
  ),
);
