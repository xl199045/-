<?php
/**
 * 用户账号体系（个人中心 · 多渠道绑定）
 *
 * 由 config.php 引入（require_once）。所有函数以 uc_ 前缀，避免与其它文件冲突。
 * 说明：
 *   - users         账号主表（用户名 / 邮箱 / 手机号 / 密码 / 注册时间）
 *   - oauth_users   登录渠道绑定表，新增 user_id 归属账号（老数据 user_id=0，登录时自动补齐）
 *   - verify_codes  验证码表（换绑邮箱 / 绑定手机号等场景，10 分钟有效、一次性）
 * 所有建表 / 升级语句均幂等，可直接在已存在的站点上运行。
 */

// 禁止直接访问（本文件只允许由 config.php 引入）
if (!isset($conn) || !($conn instanceof mysqli)) {
    http_response_code(404);
    exit;
}

/* ==================== 建表 / 升级 ==================== */
function uc_migrate($conn)
{
    mysqli_query($conn, "CREATE TABLE IF NOT EXISTS `users` (
      `id` INT PRIMARY KEY AUTO_INCREMENT,
      `username` VARCHAR(100) NOT NULL DEFAULT '' COMMENT '登录用户名',
      `nickname` VARCHAR(100) NOT NULL DEFAULT '' COMMENT '昵称',
      `email` VARCHAR(200) DEFAULT NULL COMMENT '绑定邮箱（QQ邮箱）',
      `phone` VARCHAR(30) DEFAULT NULL COMMENT '绑定手机号',
      `password` VARCHAR(255) NOT NULL DEFAULT '' COMMENT 'password_hash，空=未设置密码',
      `avatar` VARCHAR(500) NOT NULL DEFAULT '' COMMENT '头像',
      `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
      `last_login` DATETIME DEFAULT NULL,
      `last_ip` VARCHAR(64) NOT NULL DEFAULT '',
      UNIQUE KEY `uk_username` (`username`),
      UNIQUE KEY `uk_email` (`email`),
      UNIQUE KEY `uk_phone` (`phone`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户账号表'");

    // 登录渠道绑定表新增归属账号
    $col = mysqli_query($conn, "SHOW COLUMNS FROM `oauth_users` LIKE 'user_id'");
    if ($col && mysqli_num_rows($col) === 0) {
        mysqli_query($conn, "ALTER TABLE `oauth_users` ADD COLUMN `user_id` INT NOT NULL DEFAULT 0 COMMENT '归属用户ID' AFTER `id`, ADD KEY `idx_user_id` (`user_id`)");
    }

    mysqli_query($conn, "CREATE TABLE IF NOT EXISTS `verify_codes` (
      `id` INT PRIMARY KEY AUTO_INCREMENT,
      `target` VARCHAR(200) NOT NULL DEFAULT '' COMMENT '接收方（邮箱）',
      `code` VARCHAR(10) NOT NULL DEFAULT '',
      `scene` VARCHAR(30) NOT NULL DEFAULT '' COMMENT '场景：bind_email/change_email/bind_phone',
      `used` TINYINT(1) NOT NULL DEFAULT 0,
      `expire_at` INT NOT NULL DEFAULT 0,
      `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
      KEY `idx_target_scene` (`target`,`scene`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='验证码表'");
}

/* ==================== 账号读取 ==================== */
function uc_session_user_id()
{
    return (int)($_SESSION['user']['id'] ?? 0);
}

function uc_user_row($conn, $uid)
{
    $uid = (int)$uid;
    if ($uid <= 0) return null;
    $res = mysqli_query($conn, "SELECT * FROM `users` WHERE id = {$uid} LIMIT 1");
    return ($res && ($row = mysqli_fetch_assoc($res))) ? $row : null;
}

/** 当前登录账号（会话失效 / 账号被删时返回 null） */
function uc_current_user($conn)
{
    return uc_user_row($conn, uc_session_user_id());
}

function uc_user_by_email($conn, $email)
{
    $email = mysqli_real_escape_string($conn, trim((string)$email));
    if ($email === '') return null;
    $res = mysqli_query($conn, "SELECT * FROM `users` WHERE email = '{$email}' LIMIT 1");
    return ($res && ($row = mysqli_fetch_assoc($res))) ? $row : null;
}

function uc_user_by_phone($conn, $phone)
{
    $phone = mysqli_real_escape_string($conn, trim((string)$phone));
    if ($phone === '') return null;
    $res = mysqli_query($conn, "SELECT * FROM `users` WHERE phone = '{$phone}' LIMIT 1");
    return ($res && ($row = mysqli_fetch_assoc($res))) ? $row : null;
}

/** 生成不冲突的用户名（第三方昵称可能重复 / 含非法字符） */
function uc_unique_username($conn, $base)
{
    $base = trim(preg_replace('/[^\w\x{4e00}-\x{9fa5}.-]/u', '', (string)$base));
    if ($base === '' || mb_strlen($base) < 2) $base = 'user';
    $base = mb_substr($base, 0, 30);
    $name = $base;
    while (true) {
        $esc = mysqli_real_escape_string($conn, $name);
        $res = mysqli_query($conn, "SELECT id FROM `users` WHERE username = '{$esc}' LIMIT 1");
        if (!$res || mysqli_num_rows($res) === 0) return $name;
        $name = $base . random_int(10, 9999);
    }
}

/* ==================== 账号写入 ==================== */
function uc_create_user($conn, $nickname, $avatar = '', $email = null)
{
    $nickname = mb_substr(trim((string)$nickname), 0, 50);
    if ($nickname === '') $nickname = '新用户';
    $username = uc_unique_username($conn, $nickname);
    $uEsc = mysqli_real_escape_string($conn, $username);
    $nEsc = mysqli_real_escape_string($conn, $nickname);
    $aEsc = mysqli_real_escape_string($conn, (string)$avatar);
    $ip = mysqli_real_escape_string($conn, $_SERVER['REMOTE_ADDR'] ?? '');
    $eSql = ($email === null || trim((string)$email) === '') ? 'NULL' : "'" . mysqli_real_escape_string($conn, trim((string)$email)) . "'";
    mysqli_query($conn, "INSERT INTO `users` (`username`,`nickname`,`email`,`avatar`,`last_login`,`last_ip`)
        VALUES ('{$uEsc}','{$nEsc}',{$eSql},'{$aEsc}',NOW(),'{$ip}')");
    return (int)mysqli_insert_id($conn);
}

/** 把渠道绑定挂到账号上（同一渠道同一 openid 唯一） */
function uc_attach($conn, $uid, $channel, $openid, $nickname = '', $avatar = '')
{
    $uid = (int)$uid;
    $chEsc = mysqli_real_escape_string($conn, $channel);
    $opEsc = mysqli_real_escape_string($conn, (string)$openid);
    $nEsc = mysqli_real_escape_string($conn, mb_substr((string)$nickname, 0, 50));
    $aEsc = mysqli_real_escape_string($conn, mb_substr((string)$avatar, 0, 500));
    return (bool)mysqli_query($conn, "INSERT INTO `oauth_users` (`user_id`,`channel`,`openid`,`nickname`,`avatar`)
        VALUES ({$uid},'{$chEsc}','{$opEsc}','{$nEsc}','{$aEsc}')
        ON DUPLICATE KEY UPDATE `user_id` = {$uid}, `nickname` = VALUES(`nickname`), `avatar` = VALUES(`avatar`)");
}

function uc_detach($conn, $uid, $channel)
{
    $uid = (int)$uid;
    $chEsc = mysqli_real_escape_string($conn, $channel);
    return (bool)mysqli_query($conn, "DELETE FROM `oauth_users` WHERE `user_id` = {$uid} AND `channel` = '{$chEsc}'");
}

/** 该 openid 已被哪个账号占用（0=未被占用） */
function uc_binding_owner($conn, $channel, $openid)
{
    $chEsc = mysqli_real_escape_string($conn, $channel);
    $opEsc = mysqli_real_escape_string($conn, (string)$openid);
    $res = mysqli_query($conn, "SELECT user_id FROM `oauth_users` WHERE `channel` = '{$chEsc}' AND `openid` = '{$opEsc}' LIMIT 1");
    if ($res && ($row = mysqli_fetch_assoc($res))) return (int)$row['user_id'];
    return 0;
}

/* ==================== 绑定列表 ==================== */
/** 账号已绑定的渠道： [channel => row] */
function uc_bindings($conn, $uid)
{
    $uid = (int)$uid;
    $out = [];
    $res = mysqli_query($conn, "SELECT * FROM `oauth_users` WHERE `user_id` = {$uid} ORDER BY id ASC");
    if ($res) {
        while ($row = mysqli_fetch_assoc($res)) {
            $out[$row['channel']] = $row;
        }
    }
    return $out;
}

/** 可用登录方式数量（解绑时至少要保留一种） */
function uc_login_methods($conn, $uid)
{
    $n = count(uc_bindings($conn, $uid));
    $user = uc_user_row($conn, $uid);
    if ($user && !empty($user['password'])) $n++; // 账号密码本身也是一种登录方式
    return $n;
}

/* ==================== 登录解析 ==================== */
function uc_login_log($conn, $channel, $openid, $nickname)
{
    $chEsc = mysqli_real_escape_string($conn, $channel);
    $opEsc = mysqli_real_escape_string($conn, (string)$openid);
    $nEsc = mysqli_real_escape_string($conn, mb_substr((string)$nickname, 0, 50));
    $ip = mysqli_real_escape_string($conn, $_SERVER['REMOTE_ADDR'] ?? '');
    mysqli_query($conn, "INSERT INTO `login_logs` (`channel`,`openid`,`nickname`,`ip`) VALUES ('{$chEsc}','{$opEsc}','{$nEsc}','{$ip}')");
}

/** 写入登录会话 */
function uc_set_session($conn, $uid, $channel, $openid, $nickname, $avatar)
{
    $uid = (int)$uid;
    $ip = mysqli_real_escape_string($conn, $_SERVER['REMOTE_ADDR'] ?? '');
    mysqli_query($conn, "UPDATE `users` SET `last_login` = NOW(), `last_ip` = '{$ip}' WHERE id = {$uid}");
    $_SESSION['user'] = [
        'id' => $uid,
        'channel' => $channel,
        'openid' => (string)$openid,
        'nickname' => $nickname,
        'avatar' => $avatar,
    ];
}

/**
 * 第三方渠道登录：按绑定归属登录，没有则建号并绑定
 * @return int 账号 id
 */
function uc_resolve_login($conn, $channel, $openid, $nickname, $avatar = '')
{
    $owner = uc_binding_owner($conn, $channel, $openid);
    $user = $owner > 0 ? uc_user_row($conn, $owner) : null;
    if ($user) {
        // 已绑定：刷新昵称 / 头像，头像为空时补齐
        uc_attach($conn, $owner, $channel, $openid, $nickname !== '' ? $nickname : $user['nickname'], $avatar);
        if (!empty($avatar) && empty($user['avatar'])) {
            $aEsc = mysqli_real_escape_string($conn, mb_substr((string)$avatar, 0, 500));
            mysqli_query($conn, "UPDATE `users` SET `avatar` = '{$aEsc}' WHERE id = {$owner}");
        }
        return $owner;
    }
    $uid = uc_create_user($conn, $nickname, $avatar);
    uc_attach($conn, $uid, $channel, $openid, $nickname, $avatar);
    return $uid;
}

/**
 * 邮箱验证码登录：邮箱即账号（已存在则登录，不存在则注册并绑定邮箱）
 * @return int 账号 id
 */
function uc_resolve_email_login($conn, $email)
{
    $user = uc_user_by_email($conn, $email);
    $uid = $user ? (int)$user['id'] : uc_create_user($conn, explode('@', $email)[0], '', $email);
    uc_attach($conn, $uid, 'email', $email, explode('@', $email)[0], '');
    return $uid;
}

/* ==================== CSRF ==================== */
function uc_csrf_token()
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
    }
    return $_SESSION['csrf_token'];
}

function uc_check_csrf($token)
{
    return !empty($_SESSION['csrf_token']) && is_string($token) && hash_equals($_SESSION['csrf_token'], $token);
}

/* ==================== 验证码 ==================== */
/**
 * 发送验证码（走站点 SMTP）
 * @return true|string 成功返回 true，失败返回错误信息
 */
function uc_send_code($conn, $email, $scene, $cfg)
{
    $email = trim((string)$email);
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) return '邮箱格式不正确';
    $sceneNames = ['bind_email' => '绑定邮箱', 'change_email' => '换绑邮箱', 'bind_phone' => '绑定手机号'];
    $sceneName = $sceneNames[$scene] ?? '安全验证';

    if (empty($cfg['smtp_user']) || empty($cfg['smtp_pass'])) {
        return '管理员尚未配置邮箱 SMTP，请先在后台「邮箱设置」中配置';
    }

    $eEsc = mysqli_real_escape_string($conn, $email);
    $sEsc = mysqli_real_escape_string($conn, $scene);
    $res = mysqli_query($conn, "SELECT created_at FROM `verify_codes` WHERE `target` = '{$eEsc}' AND `scene` = '{$sEsc}' ORDER BY id DESC LIMIT 1");
    if ($res && ($row = mysqli_fetch_assoc($res)) && strtotime($row['created_at']) > time() - 60) {
        return '请求过于频繁，请 60 秒后再试';
    }

    $code = (string)random_int(100000, 999999);
    $siteName = $cfg['site_name'] ?? '聚合登录';
    $mailCfg = [
        'smtp_host' => $cfg['smtp_host'] ?? '',
        'smtp_port' => $cfg['smtp_port'] ?? '',
        'smtp_user' => $cfg['smtp_user'] ?? '',
        'smtp_pass' => $cfg['smtp_pass'] ?? '',
        'smtp_from' => $cfg['smtp_from'] ?? '',
        'site_name' => $siteName,
    ];
    $subject = "【{$siteName}】{$sceneName}验证码";
    $body = "您正在{$sceneName}，验证码：{$code}\n\n10 分钟内有效，请勿泄露给他人。\n（本邮件由系统自动发送，请勿回复）";
    $sent = smtp_send($email, $subject, $body, $mailCfg);
    if ($sent !== true) return '发送失败：' . $sent;

    $cEsc = mysqli_real_escape_string($conn, $code);
    $expire = time() + 600;
    mysqli_query($conn, "INSERT INTO `verify_codes` (`target`,`code`,`scene`,`expire_at`) VALUES ('{$eEsc}','{$cEsc}','{$sEsc}',{$expire})");
    return true;
}

/** 校验验证码（一次性，成功后立即作废） */
function uc_check_code($conn, $email, $code, $scene)
{
    $code = trim((string)$code);
    if ($code === '') return false;
    $eEsc = mysqli_real_escape_string($conn, trim((string)$email));
    $sEsc = mysqli_real_escape_string($conn, $scene);
    $res = mysqli_query($conn, "SELECT * FROM `verify_codes` WHERE `target` = '{$eEsc}' AND `scene` = '{$sEsc}' AND `used` = 0 ORDER BY id DESC LIMIT 1");
    if (!$res || !($row = mysqli_fetch_assoc($res))) return false;
    if ((int)$row['expire_at'] < time()) return false;
    if (!hash_equals((string)$row['code'], $code)) return false;
    mysqli_query($conn, "UPDATE `verify_codes` SET `used` = 1 WHERE id = " . (int)$row['id']);
    return true;
}

/* ==================== 展示用元数据 ==================== */
/** 渠道图标字 / 品牌色（与 login.php、index.php、后台保持一致） */
function uc_channel_meta()
{
    return [
        'icons' => [
            'github' => 'GH', 'gitee' => 'G', 'alipay' => '支', 'qq' => 'Q',
            'wechat' => '微', 'weibo' => '博', 'baidu' => '百', 'dingtalk' => '钉',
            'douyin' => '抖', 'feishu' => '飞', 'oschina' => 'OS', 'coding' => 'COD',
            'huawei' => 'HW', 'google' => 'G', 'microsoft' => 'MS', 'wework' => '企',
            'xiaomi' => '米', 'bilibili' => 'B',
            'gitlab' => 'GL', 'twitter' => 'X', 'facebook' => 'f', 'discord' => 'DC',
            'line' => 'L', 'linkedin' => 'in', 'qihoo' => '360', 'douban' => '豆',
            'netease' => '易', 'taobao' => '淘', 'juhe' => '聚', 'email' => '邮',
        ],
        'colors' => [
            'github' => '#24292F', 'gitee' => '#C71D23', 'alipay' => '#1677FF', 'qq' => '#12B7F5',
            'wechat' => '#07C160', 'weibo' => '#E6162D', 'baidu' => '#2932E1', 'dingtalk' => '#0089FF',
            'douyin' => '#111111', 'feishu' => '#3370FF', 'oschina' => '#4E9A44', 'coding' => '#15C072',
            'huawei' => '#C7000B', 'google' => '#4285F4', 'microsoft' => '#00A4EF', 'wework' => '#0082EF',
            'xiaomi' => '#FF6900', 'bilibili' => '#00A1D6',
            'gitlab' => '#FC6D26', 'twitter' => '#1DA1F2', 'facebook' => '#1877F2', 'discord' => '#5865F2',
            'line' => '#06C755', 'linkedin' => '#0A66C2', 'qihoo' => '#DE1616', 'douban' => '#00B51D',
            'netease' => '#E60012', 'taobao' => '#FF5000', 'juhe' => '#8B5CF6', 'email' => '#22d3ee',
        ],
    ];
}

/* 引入时立即升级表结构（幂等） */
if (isset($conn) && $conn instanceof mysqli) {
    uc_migrate($conn);
}
