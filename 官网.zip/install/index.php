<?php
/**
 * 安装向导：填写数据库信息 → 自动建库建表 → 生成 config.php → 完成
 * 访问：/install/
 */
error_reporting(E_ALL & ~E_NOTICE);
$root = dirname(__DIR__);
$configFile = $root . '/config.php';
$lockFile = $root . '/install.lock';

/* ---------- 授权验证（未授权不允许安装） ---------- */
require_once $root . '/inc/license.php';
$license   = license_status(isset($_GET['license_check']));   // ?license_check=1 强制重新校验
$licenseOk = !empty($license['ok']);
$codeField = license_stored_authcode();                      // 授权码输入框默认值（授权系统注入 / 已保存）

/**
 * 从 config.php 中读取数据库常量（只解析文本，不执行该文件）
 * 不能直接 include：config.php 连接失败时会 die() 中断本页，且会触发 session_start / 自动建表等副作用
 * @return array|null 解析失败返回 null
 */
function install_read_db_config($file)
{
    $src = @file_get_contents($file);
    if ($src === false || $src === '') return null;

    $fields = ['DB_HOST' => 'host', 'DB_PORT' => 'port', 'DB_USER' => 'user', 'DB_PASS' => 'pass', 'DB_NAME' => 'name'];
    $cfg = ['host' => '127.0.0.1', 'port' => 3306, 'user' => '', 'pass' => '', 'name' => ''];
    $found = 0;
    foreach ($fields as $const => $field) {
        if (preg_match('/define\s*\(\s*[\'"]' . $const . '[\'"]\s*,\s*([\'"])((?:\\\\.|(?!\1).)*)\1\s*\)/s', $src, $m)) {
            $cfg[$field] = str_replace(['\\\\', "\\'"], ['\\', "'"], $m[2]);
            $found++;
        }
    }
    if ($found < 4 || $cfg['user'] === '' || $cfg['name'] === '') return null;
    $cfg['port'] = ((int)$cfg['port'] > 0) ? (int)$cfg['port'] : 3306;
    return $cfg;
}

/* ---------- 已安装检测 ---------- */
$installed = false;
$installedNote = '';
$reinstallHint = '';
$detectNote = '';
if (file_exists($lockFile)) {
    $installed = true;
    $installedNote = '检测到安装锁文件 install.lock，系统已安装。';
    $reinstallHint = '如需重新安装，请删除根目录下的 <b>install.lock</b> 文件后刷新本页。';
} elseif (file_exists($configFile)) {
    // 没有 install.lock 时，按 config.php 里的数据库配置连一次库、看 system_config 表是否存在来推断
    $dbCfg = install_read_db_config($configFile);
    if ($dbCfg === null) {
        $detectNote = '检测到 config.php，但无法解析其中的数据库配置，无法确认系统是否已初始化。';
    } else {
        $probe = @mysqli_connect($dbCfg['host'], $dbCfg['user'], $dbCfg['pass'], $dbCfg['name'], $dbCfg['port']);
        if (!$probe) {
            $detectNote = '检测到 config.php，但按其中的配置连接数据库失败：' . mysqli_connect_error();
        } else {
            $t = @mysqli_query($probe, "SHOW TABLES LIKE 'system_config'");
            if ($t && mysqli_num_rows($t) > 0) {
                $installed = true;
                $installedNote = '未发现 install.lock，但检测到 config.php 且数据库已初始化（存在 system_config 表），系统已安装。';
                $reinstallHint = '本站在安装时没有留下 install.lock，所以删它没用。重新安装请先备份并删除（或改名）根目录下的 <b>config.php</b>，再刷新本页；'
                    . '数据库中的表不会被自动清空，重装只会在现有表上补建、补写默认数据。';
            } else {
                $detectNote = '检测到 config.php，但数据库中没有 system_config 表（尚未初始化），可以继续安装。';
            }
            mysqli_close($probe);
        }
    }
}

/* ---------- 环境检测 ---------- */
$envChecks = [
    ['PHP 版本 >= 7.4', PHP_VERSION_ID >= 70400, PHP_VERSION],
    ['mysqli 扩展', function_exists('mysqli_connect'), '必需'],
    ['curl 扩展', function_exists('curl_init'), '必需'],
    ['openssl 扩展', function_exists('openssl_sign'), '必需（SMTP/支付宝）'],
    ['zip 扩展（后台下载源码）', class_exists('ZipArchive'), '可选'],
    ['根目录可写', is_writable($root), '写 config.php / install.lock'],
];
$envAllOk = true;
foreach ($envChecks as $c) { if (!$c[1]) { $envAllOk = false; } }

/* ---------- 执行安装 ---------- */
$errors = [];
$licenseNote = '';
$done = false;
$form = ['db_host' => '127.0.0.1', 'db_port' => '3306', 'db_user' => 'root', 'db_pass' => '', 'db_name' => 'oauth_login', 'admin_user' => 'admin', 'admin_pass' => '', 'admin_pass2' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$installed) {
    $form = array_merge($form, [
        'db_host'    => trim($_POST['db_host'] ?? '127.0.0.1'),
        'db_port'    => trim($_POST['db_port'] ?? '3306'),
        'db_user'    => trim($_POST['db_user'] ?? ''),
        'db_pass'    => $_POST['db_pass'] ?? '',
        'db_name'    => trim($_POST['db_name'] ?? ''),
        'admin_user' => trim($_POST['admin_user'] ?? ''),
        'admin_pass' => $_POST['admin_pass'] ?? '',
        'admin_pass2'=> $_POST['admin_pass2'] ?? '',
    ]);

    // 授权验证：本次提交了授权码就按它实测；未授权（授权码错误 / 域名未加授权 / 云端不可达）一律中止安装
    $codeField = trim((string)($_POST['license_authcode'] ?? ''));
    $license   = $codeField !== '' ? license_status(true, $codeField) : license_status(true);
    $licenseOk = !empty($license['ok']);
    if (!$licenseOk) {
        $errors[] = '未通过授权验证：' . ($license['msg'] !== '' ? $license['msg'] : '当前域名未获得授权')
                  . '（校验域名：' . ($license['host'] !== '' ? $license['host'] : '未知') . '）';
    }

    // 校验
    if ($form['db_user'] === '' || $form['db_name'] === '') $errors[] = '数据库用户名和数据库名不能为空';
    if (!preg_match('/^[A-Za-z0-9_]+$/', $form['db_name'])) $errors[] = '数据库名只能包含字母、数字、下划线';
    if ($form['admin_pass'] !== '' && $form['admin_pass'] !== $form['admin_pass2']) $errors[] = '两次输入的管理员密码不一致';

    if (!$errors) {
        // 1. 连接测试（先不选库）
        $link = @mysqli_connect($form['db_host'], $form['db_user'], $form['db_pass'], '', (int)$form['db_port']);
        if (!$link) {
            $errors[] = '数据库连接失败：' . mysqli_connect_error();
        } else {
            // 2. 建库
            if (!mysqli_query($link, "CREATE DATABASE IF NOT EXISTS `" . $form['db_name'] . "` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")) {
                $errors[] = '创建数据库失败：' . mysqli_error($link);
            }
            // 3. 选库
            if (!$errors && !mysqli_select_db($link, $form['db_name'])) {
                $errors[] = '选择数据库失败：' . mysqli_error($link);
            }
            // 4. 执行 sql.sql
            if (!$errors) {
                $sql = @file_get_contents($root . '/sql.sql');
                if ($sql === false) {
                    $errors[] = '读取 sql.sql 失败，请确认文件存在';
                } else {
                    if (!mysqli_multi_query($link, $sql)) {
                        $errors[] = '执行 SQL 失败：' . mysqli_error($link);
                    } else {
                        do { if ($r = mysqli_store_result($link)) mysqli_free_result($r); } while (mysqli_more_results($link) && mysqli_next_result($link));
                    }
                }
            }
            // 5. 自定义管理员（首个管理员固定为超级管理员；密码用 password_hash 存储）
            if (!$errors && $form['admin_user'] !== '' && $form['admin_pass'] !== '') {
                $au = mysqli_real_escape_string($link, $form['admin_user']);
                $hash = mysqli_real_escape_string($link, password_hash($form['admin_pass'], PASSWORD_DEFAULT));
                mysqli_query($link, "UPDATE admin_user SET username='$au', password='$hash' WHERE id=1");
                mysqli_query($link, "UPDATE admin_user SET role='super', status=1 WHERE id=1");
            }
            mysqli_close($link);
        }

        // 6. 生成 config.php
        if (!$errors) {
            $tpl = file_get_contents(__DIR__ . '/config.tpl.php');
            $content = str_replace(
                ['__HOST__', '__PORT__', '__USER__', '__PASS__', '__NAME__'],
                [$form['db_host'], (int)$form['db_port'], addslashes($form['db_user']), addslashes($form['db_pass']), $form['db_name']],
                $tpl
            );
            if (@file_put_contents($configFile, $content) === false) {
                $errors[] = '生成 config.php 失败，请检查根目录写入权限';
            }
        }

        // 7. 写安装锁
        if (!$errors) {
            @file_put_contents($lockFile, date('Y-m-d H:i:s'));
        }

        // 8. 保存本次验证通过的授权码（不阻断安装）
        if (!$errors && $licenseOk && $codeField !== '' && !license_save_authcode($codeField)) {
            $licenseNote = '授权码未能写入 inc/license.authcode.php（目录不可写），请检查目录权限后到后台重新验证授权码。';
        }

        if (!$errors) $done = true;
    }
}

/* ---------- 页面 ---------- */
$h = fn($s) => htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>安装向导 - 聚合登录系统</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="install-page">

<div class="install-shell">
    <div class="install-head">
        <div class="install-logo">
            <svg viewBox="0 0 40 40" fill="none" aria-hidden="true">
                <rect x="2" y="2" width="36" height="36" rx="10" stroke="#22d3ee" stroke-width="2.2"/>
                <circle cx="20" cy="20" r="4.5" fill="#22d3ee"/>
                <circle cx="10" cy="10" r="2.4" fill="#22d3ee" opacity=".55"/>
                <circle cx="30" cy="10" r="2.4" fill="#22d3ee" opacity=".55"/>
                <circle cx="10" cy="30" r="2.4" fill="#22d3ee" opacity=".55"/>
                <circle cx="30" cy="30" r="2.4" fill="#22d3ee" opacity=".55"/>
            </svg>
        </div>
        <h1>聚合登录系统 · 安装向导</h1>
        <p>填写数据库信息，自动完成建库、建表、生成配置</p>
    </div>

    <!-- 授权验证状态 -->
    <div class="card glow-card">
        <h2>授权验证 <?php echo license_badge($license); ?></h2>
        <p class="form-tip" style="margin-bottom:8px">
            校验域名：<b><?php echo $h($license['host'] !== '' ? $license['host'] : ($_SERVER['HTTP_HOST'] ?? '')); ?></b>
            · 应用：<b><?php echo $h($license['name'] !== '' ? $license['name'] : '未知'); ?></b>
            · 校验时间：<?php echo $h(date('Y-m-d H:i:s', (int)$license['checked_at'])); ?><?php echo !empty($license['cached']) ? '（缓存）' : '（实时）'; ?>
        </p>
        <p class="<?php echo $licenseOk ? 'msg-ok' : 'msg-error'; ?>" style="margin-bottom:10px"><?php echo $h($license['msg']); ?></p>
        <p class="form-tip">授权码来源：<?php echo $h(license_authcode_source()); ?> · 授权系统：<?php echo $h(license_config()['host'] !== '' ? license_config()['host'] : '未配置（请联系程序作者）'); ?> · <a href="?license_check=1">重新校验</a></p>
    </div>

    <?php if ($done): ?>
    <div class="card glow-card install-ok">
        <h2>安装成功</h2>
        <p>系统已完成初始化，请立即删除 <b>/install</b> 目录（或保留 install.lock 防止重复安装）。</p>
        <?php if ($licenseNote !== ''): ?>
        <p class="msg-error"><?php echo $h($licenseNote); ?></p>
        <?php endif; ?>
        <div class="install-links">
            <a class="btn btn-primary" href="/">前台官网</a>
            <a class="btn btn-ghost" href="/login.php">登录页</a>
            <a class="btn btn-ghost" href="/admin/">管理后台</a>
        </div>
    </div>

    <?php elseif ($installed): ?>
    <div class="card glow-card">
        <h2>系统已安装</h2>
        <p><?php echo $h($installedNote); ?></p>
        <p class="form-tip"><?php echo $reinstallHint; ?></p>
        <div class="install-links">
            <a class="btn btn-primary" href="/">前台官网</a>
            <a class="btn btn-ghost" href="/admin/">管理后台</a>
        </div>
    </div>

    <?php else: ?>

    <?php if (!$licenseOk): ?>
    <!-- 未授权提示：仍可填授权码，但校验不通过不会执行安装 -->
    <div class="card glow-card">
        <h2>当前未授权</h2>
        <p class="msg-error"><?php echo $h($license['msg']); ?></p>
        <p class="form-tip">请在惊霄授权系统「授权列表」中为域名 <b><?php echo $h($_SERVER['HTTP_HOST'] ?? ''); ?></b> 添加授权（应用「官网」），
            再把该记录里的「授权代码」填入下方安装表单的「授权码」后提交；授权码校验通过才会执行安装。
            应用 UID / 应用授权密钥由程序作者配置在 <b>inc/license.config.php</b>。</p>
        <div class="install-links">
            <a class="btn btn-ghost" href="?license_check=1">重新校验</a>
        </div>
    </div>
    <?php endif; ?>

    <!-- 环境检测 -->
    <div class="card glow-card">
        <h2>环境检测</h2>
        <table class="env-table">
            <?php foreach ($envChecks as $c): ?>
            <tr>
                <td><?php echo $h($c[0]); ?></td>
                <td class="env-val"><?php echo $h($c[2]); ?></td>
                <td class="<?php echo $c[1] ? 'env-ok' : 'env-fail'; ?>"><?php echo $c[1] ? '✓ 通过' : '✕ 未通过'; ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php if (!$envAllOk): ?>
        <p class="msg-error">存在未通过项，请先解决后再安装（zip 为可选）。</p>
        <?php endif; ?>
    </div>

    <!-- 安装表单 -->
    <div class="card glow-card">
        <h2>数据库配置</h2>
        <?php foreach ($errors as $er): ?>
        <p class="msg-error"><?php echo $h($er); ?></p>
        <?php endforeach; ?>
        <?php if ($detectNote !== ''): ?>
        <p class="form-tip"><?php echo $h($detectNote); ?></p>
        <?php endif; ?>
        <form method="post" class="install-form">
            <h3 style="margin:0 0 4px">授权码验证</h3>
            <p class="form-tip" style="margin-bottom:10px">填写授权系统「授权列表」中本站域名对应的授权代码；授权码错误或域名未添加授权将无法安装。若安装包已由授权系统自动注入授权码，此处可留空。</p>
            <div class="form-grid">
                <div class="form-item form-item-wide">
                    <label>授权码</label>
                    <input type="text" name="license_authcode" value="<?php echo $h($codeField); ?>" placeholder="粘贴授权码">
                </div>
            </div>
            <div class="form-grid">
                <div class="form-item">
                    <label>数据库地址</label>
                    <input type="text" name="db_host" value="<?php echo $h($form['db_host']); ?>" placeholder="127.0.0.1">
                </div>
                <div class="form-item">
                    <label>端口</label>
                    <input type="text" name="db_port" value="<?php echo $h($form['db_port']); ?>" placeholder="3306">
                </div>
                <div class="form-item">
                    <label>数据库用户名</label>
                    <input type="text" name="db_user" value="<?php echo $h($form['db_user']); ?>" required placeholder="root">
                </div>
                <div class="form-item">
                    <label>数据库密码</label>
                    <input type="password" name="db_pass" value="<?php echo $h($form['db_pass']); ?>" placeholder="数据库密码">
                </div>
                <div class="form-item form-item-wide">
                    <label>数据库名（不存在将自动创建）</label>
                    <input type="text" name="db_name" value="<?php echo $h($form['db_name']); ?>" required placeholder="oauth_login">
                </div>
            </div>

            <h3 style="margin:22px 0 4px">管理员账号（可选，默认 admin / 123456）</h3>
            <div class="form-grid">
                <div class="form-item">
                    <label>管理员用户名</label>
                    <input type="text" name="admin_user" value="<?php echo $h($form['admin_user']); ?>" placeholder="admin">
                </div>
                <div class="form-item">
                    <label>管理员密码</label>
                    <input type="password" name="admin_pass" placeholder="留空使用默认 123456">
                </div>
                <div class="form-item">
                    <label>确认密码</label>
                    <input type="password" name="admin_pass2" placeholder="再次输入">
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary btn-lg" <?php echo $envAllOk ? '' : 'disabled'; ?>>开始安装</button>
            </div>
            <p class="form-tip">点击安装即表示同意自动创建数据库表与初始化配置，安装完成后请删除 install 目录。</p>
        </form>
    </div>
    <?php endif; /* 未安装 */ ?>
</div>

</body>
</html>
