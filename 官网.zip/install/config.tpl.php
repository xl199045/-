<?php
/**
 * 全局配置模板（由 /install/ 安装向导自动生成，勿手动编辑数据库配置）
 * 生成时间：自动写入
 */
session_start();

define('DB_HOST', '__HOST__');
define('DB_PORT', __PORT__);
define('DB_USER', '__USER__');
define('DB_PASS', '__PASS__');
define('DB_NAME', '__NAME__');

/* ===== 连接数据库 ===== */
$conn = @mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);
if (!$conn) {
    die('数据库连接失败，请重新运行 /install/ 安装向导：' . mysqli_connect_error());
}
mysqli_set_charset($conn, 'utf8mb4');

/* ===== 读取系统配置 ===== */
$systemConfig = [];
$res = mysqli_query($conn, "SELECT key_name, value FROM system_config");
if ($res) {
    while ($row = mysqli_fetch_assoc($res)) {
        $systemConfig[$row['key_name']] = $row['value'];
    }
}

/* ===== 读取 OAuth 渠道列表 ===== */
$channels = [];
$chRes = mysqli_query($conn, "SELECT * FROM oauth_channels ORDER BY sort ASC");
if ($chRes) {
    while ($r = mysqli_fetch_assoc($chRes)) {
        $channels[$r['name']] = $r;
    }
}

/* ===== 工具函数 ===== */
function isAdminLogin() {
    return isset($_SESSION['admin_login']) && $_SESSION['admin_login'] === true;
}

function e($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

function redirect($url) {
    header('Location: ' . $url);
    exit;
}

function http_request($url, $method = 'GET', $params = [], $headers = []) {
    $ch = curl_init();
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, is_array($params) ? http_build_query($params) : $params);
    } elseif (!empty($params)) {
        $url .= (strpos($url, '?') === false ? '?' : '&') . http_build_query($params);
    }
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    if ($headers) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }
    $resp = curl_exec($ch);
    curl_close($ch);
    return $resp;
}

/**
 * 支付宝 RSA2 签名（SHA256withRSA）
 */
function alipaySign($params, $privateKey) {
    ksort($params);
    $str = '';
    foreach ($params as $k => $v) {
        if ($v === '' || $v === null) continue;
        $str .= $k . '=' . $v . '&';
    }
    $str = rtrim($str, '&');
    $ok = openssl_sign($str, $sign, $privateKey, OPENSSL_ALGO_SHA256);
    return $ok ? base64_encode($sign) : '';
}

/**
 * SMTP 发送邮件（支持 QQ 邮箱 465 SSL）
 * @param array $cfg  smtp_host/smtp_port/smtp_user/smtp_pass/smtp_from
 * @return true|string 成功返回 true，失败返回错误信息
 */
function smtp_send($to, $subject, $body, $cfg) {
    $host = !empty($cfg['smtp_host']) ? $cfg['smtp_host'] : 'smtp.qq.com';
    $port = !empty($cfg['smtp_port']) ? (int)$cfg['smtp_port'] : 465;
    $user = $cfg['smtp_user'] ?? '';
    $pass = $cfg['smtp_pass'] ?? '';
    $from = !empty($cfg['smtp_from']) ? $cfg['smtp_from'] : $user;
    if ($user === '' || $pass === '') return 'SMTP 账号或授权码未配置';

    $fp = @fsockopen('ssl://' . $host, $port, $errno, $errstr, 15);
    if (!$fp) return '无法连接 SMTP 服务器：' . $errstr;
    stream_set_timeout($fp, 15);

    $read = function () use ($fp) {
        $resp = '';
        while ($line = fgets($fp, 515)) {
            $resp .= $line;
            if (isset($line[3]) && $line[3] === ' ') break;
        }
        return trim($resp);
    };
    $write = function ($cmd) use ($fp, $read) {
        fwrite($fp, $cmd . "\r\n");
        return $read();
    };

    $read();
    $write('EHLO juhelogin.local');
    if (stripos($write('AUTH LOGIN'), '334') !== 0) return 'SMTP 服务器不支持 AUTH LOGIN';
    if (stripos($write(base64_encode($user)), '334') !== 0) return 'SMTP 用户名校验失败';
    $authResp = $write(base64_encode($pass));
    if (stripos($authResp, '235') !== 0) return 'SMTP 认证失败：' . $authResp . '（QQ 邮箱请使用授权码而非登录密码）';
    if (stripos($write('MAIL FROM:<' . $from . '>'), '250') !== 0) return 'MAIL FROM 失败';
    if (stripos($write('RCPT TO:<' . $to . '>'), '250') !== 0) return 'RCPT TO 失败';
    if (stripos($write('DATA'), '354') !== 0) return 'DATA 阶段失败';
    $header = "From: =?UTF-8?B?" . base64_encode($cfg['site_name'] ?? '聚合登录') . "?= <" . $from . ">\r\n"
        . "To: <" . $to . ">\r\n"
        . "Subject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\n"
        . "MIME-Version: 1.0\r\n"
        . "Content-Type: text/plain; charset=UTF-8\r\n\r\n";
    fwrite($fp, $header . $body . "\r\n.\r\n");
    $dataResp = $read();
    fwrite($fp, "QUIT\r\n");
    fclose($fp);
    return (strpos($dataResp, '250') !== false) ? true : '发送失败：' . $dataResp;
}

/* ===== 自动建表（升级兼容：确保产品表 / 合作企业表存在） ===== */
mysqli_query($conn, "CREATE TABLE IF NOT EXISTS `products` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `name` VARCHAR(200) NOT NULL,
  `description` TEXT,
  `price` VARCHAR(50) DEFAULT '',
  `image` VARCHAR(255) DEFAULT '',
  `status` TINYINT(1) DEFAULT 1,
  `sort` INT DEFAULT 0,
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
mysqli_query($conn, "CREATE TABLE IF NOT EXISTS `companies` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `name` VARCHAR(200) NOT NULL,
  `email` VARCHAR(200) DEFAULT '',
  `website` VARCHAR(255) DEFAULT '',
  `logo` VARCHAR(255) DEFAULT '',
  `status` TINYINT(1) DEFAULT 0,
  `sort` INT DEFAULT 0,
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

/* ===== 自动补齐聚合渠道（升级兼容：新增渠道自动插入，不覆盖已有配置） ===== */
// 渠道表新增 mode 列（每渠道可选：0直连官方 / 1对接聚合平台）
$modeCol = mysqli_query($conn, "SHOW COLUMNS FROM `oauth_channels` LIKE 'mode'");
if ($modeCol && mysqli_num_rows($modeCol) == 0) {
    mysqli_query($conn, "ALTER TABLE `oauth_channels` ADD COLUMN `mode` TINYINT(1) DEFAULT 0 COMMENT '0直连官方OAuth 1对接聚合平台' AFTER `redirect_uri`");
}
// 自动补齐系统配置项（升级兼容：老库缺少的 key 自动插入空值）
foreach (['juhe_host','juhe_appid','juhe_appkey','shop_url','smtp_host','smtp_port','smtp_user','smtp_pass','smtp_from'] as $ck) {
    mysqli_query($conn, "INSERT IGNORE INTO `system_config` (`key_name`,`value`) VALUES ('$ck','')");
}
$defaultChannels = [
    ['huawei', '华为登录', 13],
    ['google', '谷歌登录', 14],
    ['microsoft', '微软登录', 15],
    ['wework', '企业微信登录', 16],
    ['xiaomi', '小米登录', 17],
    ['bilibili', '哔哩哔哩登录', 18],
    ['gitlab', 'GitLab登录', 19],
    ['twitter', 'X(Twitter)登录', 20],
    ['facebook', 'Facebook登录', 21],
    ['discord', 'Discord登录', 22],
    ['line', 'LINE登录', 23],
    ['linkedin', '领英登录', 24],
    ['qihoo', '360登录', 25],
    ['douban', '豆瓣登录', 26],
    ['netease', '网易登录', 27],
    ['taobao', '淘宝登录', 28],
];
foreach ($defaultChannels as $dc) {
    $dcName = mysqli_real_escape_string($conn, $dc[0]);
    $dcTitle = mysqli_real_escape_string($conn, $dc[1]);
    $dcSort = (int)$dc[2];
    mysqli_query($conn, "INSERT IGNORE INTO `oauth_channels` (`name`,`title`,`enable`,`appid`,`appsecret`,`redirect_uri`,`sort`)
        VALUES ('$dcName','$dcTitle',1,'','','',$dcSort)");
}

/* ===== 用户账号体系（个人中心 / 多渠道绑定）：表结构自动升级 + 通用函数 ===== */
require_once __DIR__ . '/inc/user.php';

/* ===== 后台管理员角色与权限（超级管理员 / 分管理员） ===== */
require_once __DIR__ . '/inc/admin.php';
