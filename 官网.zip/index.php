<?php
/**
 * 前台官网首页（主域名访问）
 * 展示：惊霄科技官网渠道 + 产品展示（后台可管理） + 合作企业（后台可管理/入驻申请）
 */
if (!file_exists(__DIR__ . '/config.php')) {
    header('Location: install/');
    exit;
}
require __DIR__ . '/config.php';

$siteName = $systemConfig['site_name'] ?? '惊霄科技官网';
$theme = $systemConfig['theme_color'] ?? '#22d3ee';
$shopUrl = trim((string)($systemConfig['shop_url'] ?? '')); // 后台「跳转设置 → 商城跳转网址」
$user = uc_current_user($conn);

$iconMap = [
    'github' => 'GH', 'gitee' => 'G', 'alipay' => '支', 'qq' => 'Q',
    'wechat' => '微', 'weibo' => '博', 'baidu' => '百', 'dingtalk' => '钉',
    'douyin' => '抖', 'feishu' => '飞', 'oschina' => 'OS', 'coding' => 'COD',
    'huawei' => 'HW', 'google' => 'G', 'microsoft' => 'MS', 'wework' => '企',
    'xiaomi' => '米', 'bilibili' => 'B',
    'gitlab' => 'GL', 'twitter' => 'X', 'facebook' => 'f', 'discord' => 'DC',
    'line' => 'L', 'linkedin' => 'in', 'qihoo' => '360', 'douban' => '豆',
    'netease' => '易', 'taobao' => '淘', 'juhe' => '聚',
];
$colorMap = [
    'github' => '#24292F', 'gitee' => '#C71D23', 'alipay' => '#1677FF', 'qq' => '#12B7F5',
    'wechat' => '#07C160', 'weibo' => '#E6162D', 'baidu' => '#2932E1', 'dingtalk' => '#0089FF',
    'douyin' => '#111111', 'feishu' => '#3370FF', 'oschina' => '#4E9A44', 'coding' => '#15C072',
    'huawei' => '#C7000B', 'google' => '#4285F4', 'microsoft' => '#00A4EF', 'wework' => '#0082EF',
    'xiaomi' => '#FF6900', 'bilibili' => '#00A1D6',
    'gitlab' => '#FC6D26', 'twitter' => '#1DA1F2', 'facebook' => '#1877F2', 'discord' => '#5865F2',
    'line' => '#06C755', 'linkedin' => '#0A66C2', 'qihoo' => '#DE1616', 'douban' => '#00B51D',
    'netease' => '#E60012', 'taobao' => '#FF5000', 'juhe' => '#8B5CF6',
];
$enabled = array_filter($channels, fn($c) => $c['enable'] == 1);

// 产品（仅展示启用的）
$products = mysqli_query($conn, "SELECT * FROM products WHERE status=1 ORDER BY sort ASC, id ASC");
// 合作企业（仅展示审核通过 status=1）
$companies = mysqli_query($conn, "SELECT * FROM companies WHERE status=1 ORDER BY sort ASC, id ASC");
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo e($siteName); ?> - 惊霄科技官网</title>
<link rel="stylesheet" href="assets/css/style.css">
<style>:root{--tc:<?php echo e($theme); ?>}</style>
</head>
<body>

<nav class="nav">
    <div class="nav-logo"><?php echo e($siteName); ?></div>
    <div class="nav-menu">
        <a href="/">首页</a>
        <a href="#products">产品</a>
        <a href="#partners">合作企业</a>
        <?php if ($shopUrl !== ''): ?><a href="<?php echo e($shopUrl); ?>" target="_blank" rel="noopener">商城</a><?php endif; ?>
        <?php if ($user): ?>
        <a href="user.php">个人中心</a>
        <a href="logout.php">退出登录</a>
        <?php else: ?>
        <a href="login.php">登录</a>
        <?php endif; ?>
        <a href="join.php">企业入驻</a>
    </div>
</nav>

<header class="hero">
    <div class="hero-inner">
        <span class="hero-badge">OAUTH2.0 · <?php echo count($enabled); ?> 渠道已启用</span>
        <h1>惊霄<span class="grad">科技</span></h1>
        <p class="hero-sub">惊霄科技，提供域名注册，服务器购买</p>
        <p class="hero-sub dim">惊霄科技欢迎入住合作</p>
        <div class="hero-actions">
            <?php if ($user): ?>
            <a class="btn btn-primary" href="user.php">进入个人中心</a>
            <?php else: ?>
            <a class="btn btn-primary" href="login.php">立即登录</a>
            <?php endif; ?>
            <a class="btn btn-ghost" href="#products">查看产品</a>
            <?php if ($shopUrl !== ''): ?><a class="btn btn-ghost" href="<?php echo e($shopUrl); ?>" target="_blank" rel="noopener">进入商城 →</a><?php endif; ?>
        </div>
    </div>
    <div class="hero-orb" aria-hidden="true"></div>
</header>

<div class="container">

    <!-- 已开启的登录渠道 -->
    <div class="card glow-card">
        <h2>已开启的登录渠道</h2>
        <div class="chip-grid">
            <?php if (count($enabled) === 0): ?>
                <p class="dim">暂未开启任何渠道，请先进入管理后台开启。</p>
            <?php endif; ?>
            <?php foreach ($enabled as $item): ?>
            <span class="chip" style="--oc:<?php echo e($colorMap[$item['name']] ?? '#22d3ee'); ?>">
                <i><?php echo e($iconMap[$item['name']] ?? '登'); ?></i>
                <?php echo e($item['title']); ?>
            </span>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- 产品展示区（后台可增删改） -->
    <section id="products" class="section-block">
        <div class="section-head">
            <h2>产品方案</h2>
            <p>面向不同场景的产品，后台可随时增删改。</p>
        </div>
        <div class="product-grid">
            <?php
            $hasProduct = false;
            while ($p = mysqli_fetch_assoc($products)) {
                $hasProduct = true;
            ?>
            <div class="product-card glow-card">
                <?php if (!empty($p['image'])): ?>
                <div class="product-img" style="background-image:url('<?php echo e($p['image']); ?>')"></div>
                <?php else: ?>
                <div class="product-img product-img-empty">
                    <span><?php echo e(mb_substr($p['name'], 0, 1)); ?></span>
                </div>
                <?php endif; ?>
                <div class="product-body">
                    <div class="product-top">
                        <h3><?php echo e($p['name']); ?></h3>
                        <span class="product-price"><?php echo e($p['price']); ?></span>
                    </div>
                    <p class="product-desc"><?php echo e($p['description']); ?></p>
                </div>
            </div>
            <?php } ?>
            <?php if (!$hasProduct): ?>
            <p class="dim">暂无产品，请到管理后台添加。</p>
            <?php endif; ?>
        </div>
    </section>

    <!-- 合作企业展示区（后台可添加/删除，入驻申请审核通过后展示） -->
    <section id="partners" class="section-block">
        <div class="section-head">
            <h2>合作企业</h2>
            <p>与我们携手共建的企业伙伴，欢迎入驻。</p>
        </div>
        <div class="company-grid">
            <?php
            $hasCompany = false;
            while ($c = mysqli_fetch_assoc($companies)) {
                $hasCompany = true;
            ?>
            <a class="company-card glow-card" <?php if (!empty($c['website'])) { echo 'href="' . e($c['website']) . '" target="_blank" rel="noopener"'; } ?>>
                <div class="company-logo">
                    <?php if (!empty($c['logo'])): ?>
                        <img src="<?php echo e($c['logo']); ?>" alt="<?php echo e($c['name']); ?>">
                    <?php else: ?>
                        <span><?php echo e(mb_substr($c['name'], 0, 1)); ?></span>
                    <?php endif; ?>
                </div>
                <h3><?php echo e($c['name']); ?></h3>
                <?php if (!empty($c['website'])): ?>
                <p class="company-site"><?php echo e($c['website']); ?></p>
                <?php else: ?>
                <p class="company-site dim">合作企业</p>
                <?php endif; ?>
            </a>
            <?php } ?>
            <?php if (!$hasCompany): ?>
            <p class="dim">暂无合作企业，欢迎申请入驻。</p>
            <?php endif; ?>
        </div>
        <div class="section-foot-cta">
            <a class="btn btn-ghost" href="join.php">申请入驻 →</a>
        </div>
    </section>

</div>

<footer class="footer">
    <div class="container foot-inner">
        <span>© <?php echo date('Y'); ?> <?php echo e($siteName); ?> · PHP 惊霄科技官网系统</span>
        <span><?php if ($user): ?><a href="user.php">个人中心</a><?php else: ?><a href="login.php">登录</a><?php endif; ?><?php if ($shopUrl !== ''): ?> · <a href="<?php echo e($shopUrl); ?>" target="_blank" rel="noopener">商城</a><?php endif; ?> · <a href="join.php">企业入驻</a></span>
    </div>
</footer>

<script src="assets/js/main.js"></script>
</body>
</html>
