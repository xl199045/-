<?php
/**
 * 聚合登录页：第三方渠道按钮 + QQ 邮箱验证码登录
 * 背景 / 主题色 / 站点名 均读取后台配置
 */
if (!file_exists(__DIR__ . '/config.php')) {
    header('Location: install/');
    exit;
}
require __DIR__ . '/config.php';

$siteName = $systemConfig['site_name'] ?? '聚合登录';
$theme = $systemConfig['theme_color'] ?? '#22d3ee';
// 已登录用户不再展示登录页（会话对应账号不存在时按未登录处理，避免跳转死循环）
if (uc_current_user($conn)) {
    redirect('user.php');
}

$iconMap = [
    'github' => 'GH', 'gitee' => 'G', 'alipay' => '支', 'qq' => 'Q',
    'wechat' => '微', 'weibo' => '博', 'baidu' => '百', 'dingtalk' => '钉',
    'douyin' => '抖', 'feishu' => '飞', 'oschina' => 'OS', 'coding' => 'COD',
    'huawei' => 'HW', 'google' => 'G', 'microsoft' => 'MS', 'wework' => '企',
    'xiaomi' => '米', 'bilibili' => 'B',
    'gitlab' => 'GL', 'twitter' => 'X', 'facebook' => 'f', 'discord' => 'DC',
    'line' => 'L', 'linkedin' => 'in', 'qihoo' => '360', 'douban' => '豆',
    'netease' => '易', 'taobao' => '淘', 'juhe' => '聚',
];
$colorMap = [
    'github' => '#24292F', 'gitee' => '#C71D23', 'alipay' => '#1677FF', 'qq' => '#12B7F5',
    'wechat' => '#07C160', 'weibo' => '#E6162D', 'baidu' => '#2932E1', 'dingtalk' => '#0089FF',
    'douyin' => '#111111', 'feishu' => '#3370FF', 'oschina' => '#4E9A44', 'coding' => '#15C072',
    'huawei' => '#C7000B', 'google' => '#4285F4', 'microsoft' => '#00A4EF', 'wework' => '#0082EF',
    'xiaomi' => '#FF6900', 'bilibili' => '#00A1D6',
    'gitlab' => '#FC6D26', 'twitter' => '#1DA1F2', 'facebook' => '#1877F2', 'discord' => '#5865F2',
    'line' => '#06C755', 'linkedin' => '#0A66C2', 'qihoo' => '#DE1616', 'douban' => '#00B51D',
    'netease' => '#E60012', 'taobao' => '#FF5000', 'juhe' => '#8B5CF6',
];
$bg = $systemConfig['login_bg'] ?? '';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>登录 - <?php echo e($siteName); ?></title>
<link rel="stylesheet" href="assets/css/style.css">
<style>
:root{--tc:<?php echo e($theme); ?>}
body.login-page{
    background:
        <?php if ($bg): ?>url("../<?php echo e($bg); ?>") center/cover no-repeat fixed,
        <?php endif; ?>
        radial-gradient(ellipse 80% 60% at 50% -10%, rgba(34,211,238,.18), transparent),
        #070b14;
}
</style>
</head>
<body class="login-page">

<div class="login-shell">
    <div class="login-box glow-card">
        <h2><?php echo e($siteName); ?></h2>
        <p class="login-sub">选择一种方式，授权后直达用户中心</p>

        <!-- 登录渠道按钮：固定高度滚动区 + 双列网格，渠道多也不撑长页面；
             走官方 OAuth 还是聚合中转，由后台每个渠道的「对接方式」决定 -->
        <?php $enabledList = array_filter($channels, fn($c) => $c['enable'] == 1 && $c['name'] !== 'juhe'); ?>
        <?php if (count($enabledList) > 0): ?>
        <div class="oauth-section-label">第三方账号登录 <span><?php echo count($enabledList); ?> 种方式</span></div>
        <div class="oauth-scroll">
            <div class="oauth-list">
                <?php foreach ($enabledList as $item): ?>
                <a href="callback.php?channel=<?php echo e($item['name']); ?>" class="oauth-btn" style="--oc:<?php echo $colorMap[$item['name']] ?? '#22d3ee'; ?>">
                    <span class="oauth-icon"><?php echo $iconMap[$item['name']] ?? '登'; ?></span>
                    <span><?php echo e($item['title']); ?></span>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
        <?php else: ?>
        <p class="dim">暂无可用的登录方式，请先在后台开启渠道。</p>
        <?php endif; ?>

        <!-- QQ 邮箱验证码登录 -->
        <div class="login-divider"><span>或使用邮箱验证码登录</span></div>
        <div class="email-form">
            <div class="form-item">
                <label>QQ 邮箱</label>
                <input type="email" id="loginEmail" placeholder="你的QQ号@qq.com" autocomplete="email">
            </div>
            <div class="form-item code-row">
                <div style="flex:1">
                    <label>验证码</label>
                    <input type="text" id="loginCode" placeholder="6 位验证码" maxlength="6" inputmode="numeric">
                </div>
                <button type="button" class="btn btn-ghost code-btn" id="sendBtn">获取验证码</button>
            </div>
            <button class="btn btn-primary btn-block" id="emailLoginBtn">登录</button>
            <p class="form-tip" id="emailMsg"></p>
        </div>

        <!-- 账号密码登录（个人中心可设置 / 修改密码） -->
        <div class="login-divider"><span>或使用账号密码登录</span></div>
        <div class="email-form">
            <div class="form-item">
                <label>用户名 / 邮箱</label>
                <input type="text" id="pwdAccount" placeholder="用户名或绑定的QQ邮箱" autocomplete="username">
            </div>
            <div class="form-item">
                <label>密码</label>
                <input type="password" id="pwdPassword" placeholder="账号密码" autocomplete="current-password">
            </div>
            <button class="btn btn-ghost btn-block" id="pwdLoginBtn">登录</button>
            <p class="form-tip" id="pwdMsg"></p>
        </div>

        <div class="login-foot">
            <a href="/">← 返回官网</a>
        </div>
    </div>
</div>

<script src="assets/js/main.js"></script>
<script>
/* QQ 邮箱验证码登录：发送验证码 / 校验登录（调用 send_code.php） */
(function () {
    var emailInput = document.getElementById('loginEmail');
    var codeInput  = document.getElementById('loginCode');
    var sendBtn    = document.getElementById('sendBtn');
    var loginBtn   = document.getElementById('emailLoginBtn');
    var msgEl      = document.getElementById('emailMsg');
    if (!sendBtn || !loginBtn) return;

    var countdown = 0, timer = null;
    function setMsg(text, ok) {
        msgEl.textContent = text || '';
        msgEl.style.color = ok ? '#34d399' : '#f87171';
    }
    function post(action, body) {
        return fetch('send_code.php?action=' + action, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body
        }).then(function (r) { return r.json(); });
    }

    sendBtn.addEventListener('click', function () {
        if (countdown > 0) return;
        var email = emailInput.value.trim();
        if (!email) { setMsg('请输入 QQ 邮箱', false); return; }
        sendBtn.disabled = true;
        setMsg('正在发送…', true);
        post('send', 'email=' + encodeURIComponent(email)).then(function (res) {
            setMsg(res.msg || '', !!res.ok);
            if (res.ok) {
                countdown = 60;
                sendBtn.textContent = countdown + 's';
                timer = setInterval(function () {
                    countdown--;
                    if (countdown <= 0) {
                        clearInterval(timer);
                        sendBtn.disabled = false;
                        sendBtn.textContent = '获取验证码';
                    } else {
                        sendBtn.textContent = countdown + 's';
                    }
                }, 1000);
            } else {
                sendBtn.disabled = false;
            }
        }).catch(function () {
            setMsg('网络错误，请重试', false);
            sendBtn.disabled = false;
        });
    });

    loginBtn.addEventListener('click', function () {
        var email = emailInput.value.trim();
        var code = codeInput.value.trim();
        if (!email || !code) { setMsg('请输入邮箱和验证码', false); return; }
        loginBtn.disabled = true;
        setMsg('正在登录…', true);
        post('verify', 'email=' + encodeURIComponent(email) + '&code=' + encodeURIComponent(code)).then(function (res) {
            if (res.ok) {
                setMsg(res.msg || '登录成功', true);
                location.href = res.redirect || 'user.php';
            } else {
                setMsg(res.msg || '登录失败', false);
                loginBtn.disabled = false;
            }
        }).catch(function () {
            setMsg('网络错误，请重试', false);
            loginBtn.disabled = false;
        });
    });
})();
</script>
<script>
/* 账号密码登录：调用 user_action.php?action=login（密码在个人中心设置 / 修改） */
(function () {
    var account = document.getElementById('pwdAccount');
    var password = document.getElementById('pwdPassword');
    var btn = document.getElementById('pwdLoginBtn');
    var msg = document.getElementById('pwdMsg');
    if (!btn) return;

    function setMsg(text, ok) {
        msg.textContent = text || '';
        msg.style.color = ok ? '#34d399' : '#f87171';
    }

    btn.addEventListener('click', function () {
        var acc = account.value.trim();
        var pwd = password.value;
        if (!acc || !pwd) { setMsg('请输入账号和密码', false); return; }
        btn.disabled = true;
        setMsg('正在登录…', true);
        var body = new URLSearchParams();
        body.append('action', 'login');
        body.append('account', acc);
        body.append('password', pwd);
        fetch('user_action.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            credentials: 'same-origin',
            body: body.toString()
        }).then(function (r) { return r.json(); }).then(function (res) {
            if (res.ok) {
                setMsg(res.msg || '登录成功', true);
                location.href = res.redirect || 'user.php';
            } else {
                setMsg(res.msg || '登录失败', false);
                btn.disabled = false;
            }
        }).catch(function () {
            setMsg('网络错误，请重试', false);
            btn.disabled = false;
        });
    });
})();
</script>
</body>
</html>
