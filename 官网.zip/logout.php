<?php
/**
 * 前台退出登录
 */
if (!file_exists(__DIR__ . '/config.php')) {
    header('Location: install/');
    exit;
}
require __DIR__ . '/config.php';
unset($_SESSION['user']);
redirect('login.php');
