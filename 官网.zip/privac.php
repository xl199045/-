<?php
header("Content-type:text/html;charset=utf-8");
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>隐私政策</title>
    <style>
        body{max-width:900px;margin:30px auto;padding:0 20px;font-family:system-ui;line-height:1.7;color:#333;}
        h1{text-align:center;color:#222;}
    </style>
</head>
<body>
<h1>隐私政策</h1>
<p>更新日期：2026年09月28日</p>
<h3>1. 信息收集</h3>
<p>当您使用本站登录服务时，我们可能获取第三方登录渠道返回的公开信息，包括昵称、头像，不会主动收集身份证、手机号等敏感隐私信息。</p>
<h3>2. 信息使用</h3>
<p>收集的信息仅用于系统账号识别、登录，不会出售、出租给任何第三方。</p>
<h3>3. Cookie</h3>
<p>本站使用Cookie维持登录会话，您可以在浏览器设置关闭Cookie，但会影响登录功能。</p>
<h3>4. 联系我们</h3>
<p>邮箱：3917698503@qq.com</p>
</body>
</html>
