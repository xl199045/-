<?php
/**
 * 企业入驻申请页面（前台）
 */
if (!file_exists(__DIR__ . '/config.php')) {
    header('Location: install/');
    exit;
}
require __DIR__ . '/config.php';
$siteName = $systemConfig['site_name'] ?? '聚合登录';
$theme = $systemConfig['theme_color'] ?? '#22d3ee';
$shopUrl = trim((string)($systemConfig['shop_url'] ?? '')); // 后台「跳转设置 → 商城跳转网址」
$user = uc_current_user($conn);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>企业入驻申请 - <?php echo e($siteName); ?></title>
<link rel="stylesheet" href="assets/css/style.css">
<style>:root{--tc:<?php echo e($theme); ?>}</style>
</head>
<body>

<nav class="nav">
    <div class="nav-logo"><?php echo e($siteName); ?></div>
    <div class="nav-menu">
        <a href="./">首页</a>
        <a href="./#products">产品</a>
        <a href="./#partners">合作企业</a>
        <?php if ($shopUrl !== ''): ?><a href="<?php echo e($shopUrl); ?>" target="_blank" rel="noopener">商城</a><?php endif; ?>
        <?php if ($user): ?>
        <a href="user.php">个人中心</a>
        <?php else: ?>
        <a href="login.php">登录</a>
        <?php endif; ?>
        <a href="join.php">企业入驻</a>
    </div>
</nav>

<div class="container">
    <div class="join-wrap">
        <div class="ad-panel join-card">
            <h2>企业入驻申请</h2>
            <p class="dim">提交入驻申请后，管理员审核通过即可在首页「合作企业」展示。</p>
            <form method="post" action="join_submit.php">
                <div class="form-item"><label>公司 / 企业名称 *</label><input type="text" name="name" required maxlength="200" placeholder="企业全称"></div>
                <div class="form-item"><label>联系邮箱 *</label><input type="email" name="email" required maxlength="200" placeholder="you@company.com"></div>
                <div class="form-item"><label>企业网址（选填，首页卡片可点击跳转）</label><input type="text" name="website" maxlength="255" placeholder="https://example.com"></div>
                <div class="form-actions"><button class="btn btn-primary" type="submit">提交入驻申请</button></div>
            </form>
        </div>
    </div>
</div>

<footer class="footer">
    <div class="container foot-inner">
        <span>© <?php echo date('Y'); ?> <?php echo e($siteName); ?> · PHP 聚合登录系统</span>
    </div>
</footer>

<script src="assets/js/main.js"></script>
</body>
</html>
