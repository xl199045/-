# PHP 聚合登录系统（前台 + 后台）

纯 PHP + MySQL 的多平台聚合登录系统。支持 29 种 OAuth 登录渠道（含聚合平台对接）、QQ 邮箱验证码登录、
前台产品展示（后台可增删改）、合作企业展示（后台可添加/删除/审核）、随机背景音乐、
在线安装向导，后台全可视化配置。

## 功能清单

| 模块 | 说明 |
| --- | --- |
| 在线安装 | 访问 `/install/` 填写数据库信息，自动建库建表、生成 config.php |
| 聚合登录 | GitHub / Gitee / 支付宝 / QQ / 微信 / 微博 / 百度 / 钉钉 / 抖音 / 飞书 / 开源中国 / Coding / 华为 / 谷歌 / 微软 / 企业微信 / 小米 / 哔哩哔哩 / GitLab / X / Facebook / Discord / LINE / 领英 / 360 / 豆瓣 / 网易 / 淘宝 / 聚合平台，共 29 渠道 |
| 邮箱登录 | QQ 邮箱验证码登录（后台配置 SMTP，需开启授权码） |
| 后台 | `/admin`，账号密码安装时设置（默认 admin / 123456） |
| 产品管理 | 后台增删改产品（名称/价格/描述/图片/排序/上下架），前台产品区自动展示 |
| 合作企业 | 前台可提交入驻申请；后台可添加、删除、审核（通过/拒绝/隐藏），前台展示审核通过的企业 |
| 自定义登录页 | 后台上传背景图、主题色、站点名，登录页实时生效 |
| 跳转设置 | 配置登录成功跳转网址、商城跳转网址 |
| 商城入口 | 后台「跳转设置 → 商城跳转网址」填一次，前台导航 / 首屏 / 页脚与个人中心同步出现「商城」入口（新窗口打开） |
| 分管理员 | 后台「管理员」可新增分管理员并逐模块授权（概览/产品管理/合作企业/渠道管理/登录页设置/邮箱设置/跳转设置）；超级管理员固定拥有全部权限 |
| 个人中心 | `/user.php`：基本信息（用户名/昵称/邮箱/手机号/注册时间）+ 修改密码 + 账号绑定（全部渠道 + QQ 邮箱），支持绑定/解绑/换绑 |
| 账号密码登录 | 个人中心设置密码后，登录页可用「用户名 / 绑定的邮箱 + 密码」登录 |
| 音乐模式 | MP3 放入 `assets/music/`，前台右下角播放器随机播放 |
| 后台下载源码 | `/admin/download_source.php` 可直接打包下载当前源码 |

## 目录结构

```
网站根目录
├─ install/                在线安装向导
│  ├─ index.php
│  └─ config.tpl.php       config 模板（含公共函数、自动建表）
├─ config.php              数据库配置（安装向导自动生成）
├─ sql.sql                 手动安装时导入（phpMyAdmin）
├─ index.php               前台首页（登录渠道 + 产品 + 合作企业）
├─ login.php               聚合登录页
├─ callback.php            OAuth 统一回调（29 渠道，含聚合平台对接）
├─ send_code.php           QQ 邮箱验证码发送
├─ user.php                个人中心（基本信息 / 修改密码 / 账号绑定）
├─ user_action.php         个人中心接口（绑定、解绑、换绑邮箱手机、改密码、密码登录，JSON）
├─ inc/
│  ├─ user.php             用户账号体系：建表升级 + 账号/绑定/验证码/CSRF 通用函数
│  └─ admin.php            后台管理员角色与权限：建表升级 + 权限校验/入口守卫
├─ logout.php              退出登录
├─ join.php                企业入驻申请页
├─ join_submit.php         入驻申请提交
├─ music.php               MP3 列表接口
├─ assets/
│  ├─ css/style.css        科技感样式
│  ├─ js/main.js           前台脚本（音乐播放器）
│  ├─ js/user.js           个人中心交互脚本（绑定/解绑/换绑/改密码）
│  ├─ uploads/             登录背景上传目录
│  ├─ uploads/products/    产品图片目录
│  └─ music/               MP3 音乐目录（自己放入 mp3）
└─ admin/
   ├─ index.php            后台主页（概览/渠道/登录页/邮箱/跳转/管理员）
   ├─ products.php         产品管理（新增/编辑/上下架/删除）
   ├─ products_save.php    产品保存处理
   ├─ companies.php        合作企业管理（新增/编辑/审核/删除）
   ├─ companies_save.php   企业保存处理
   ├─ login.php            后台登录
   ├─ logout.php           退出
   ├─ save_config.php      配置保存
   ├─ upload_bg.php        登录背景上传
   └─ download_source.php  后台打包下载源码
```

## 安装部署（二选一）

### 方式一：在线安装向导（推荐）
1. 全部文件上传到网站根目录
2. 浏览器访问 `http://你的域名/install/`
3. 填写数据库地址/账号/密码/库名和管理员账号密码，点击安装
4. 安装完成后**删除 `install/` 目录**（防止被重新安装）

### 方式二：手动安装
1. 上传文件到网站根目录
2. phpMyAdmin 导入 `sql.sql`
3. 把 `install/config.tpl.php` 中占位符替换为真实配置，另存为根目录 `config.php`
4. 后台默认账号 admin / 123456

## 后台使用

- 访问 `http://你的域名/admin/`
- **渠道管理**：12 个渠道开关、AppID、AppSecret、回调地址一键配置
  - 回调地址统一格式：`https://你的域名/callback.php?channel=渠道名`
- **产品管理**：添加产品（名称/价格/描述/图片/排序），可编辑、上下架、删除
- **合作企业**：后台直接添加；前台入驻申请在此审核（通过/拒绝）；随时删除
- **登录页设置**：上传背景图（jpg/png/webp ≤2MB）、站点名、主题色
- **邮箱设置**：SMTP 配置（QQ 邮箱用授权码）
- **跳转设置**：登录成功跳转网址、商城网址

## 个人中心（/user.php）

登录后进入个人中心，分三块：

| 区块 | 能力 |
| --- | --- |
| 基本信息 | 修改用户名 / 昵称；邮箱（QQ 邮箱）绑定与换绑；手机号绑定与解绑；查看注册时间、上次登录 |
| 修改密码 | 未设置密码时直接设置，已设置需校验原密码；设置后登录页「账号密码登录」可用「用户名或邮箱 + 密码」登录 |
| 账号绑定 | 后台已开启的渠道全部列出：已绑定显示渠道昵称并可解绑，未绑定显示「绑定」；后台未开启的渠道灰显；QQ 邮箱同样在此绑定 / 换绑 / 解绑 |

数据模型（由 `inc/user.php` 自动建表升级，老站点访问任意页面即完成升级，无需手动执行 SQL）：

- `users`：账号主表，`username` / `email` / `phone` 唯一，`password` 存 `password_hash`，`created_at` 即注册时间
- `oauth_users.user_id`：绑定归属账号；老数据的 `user_id=0`，下次登录自动建号并补齐
- `verify_codes`：验证码（10 分钟有效、一次性、同一邮箱同一场景 60 秒内不可重复发送）

登录与账号的对应关系：任意渠道（第三方 / QQ 邮箱验证码）首次登录自动建号并绑定该渠道，之后同一渠道登录进入同一账号；在个人中心绑定其他渠道后，多个渠道都能进入同一账号。

绑定第三方渠道的实现：个人中心「绑定」按钮跳转 `callback.php?channel=xxx&bind=1`，绑定意图记录在 session（第三方侧回调地址是登记好的，不能附加自定义参数），回调时校验该第三方账号未被其他账号占用后写入绑定。

安全限制：

- 个人中心的写操作统一走 `user_action.php`，需登录 + session CSRF 校验
- 解绑时至少保留一种登录方式（含账号密码）
- 同一第三方账号不能同时绑定到两个账号
- 换绑邮箱用「发送到新邮箱」的验证码校验；手机号验证码发送到已绑定邮箱（站点未接入短信通道）
- 账号密码登录密码错误 5 次锁定 5 分钟

> 邮箱相关功能（邮箱验证码登录、绑定/换绑邮箱、绑定手机号）依赖后台「邮箱设置」中的 SMTP 配置，未配置时接口会明确提示。

## 商城入口

后台「跳转设置 → 商城跳转网址」填一次地址（例如 `https://dp.你的域名.top`），以下位置自动出现「商城」入口（新窗口打开，留空则不显示）：

- 前台首页：顶部导航「商城」、首屏「进入商城 →」按钮、页脚「商城」
- 企业入驻页：顶部导航「商城」
- 个人中心 `/user.php`：顶部导航「商城」、左侧边栏「商城 ↗」

## 管理员与权限（超级管理员 / 分管理员）

后台「管理员」页面：

| 角色 | 权限 |
| --- | --- |
| 超级管理员（super） | 全部模块 + 「分管理员」的新增 / 编辑 / 授权 / 停用 / 删除 + 源码打包下载 |
| 分管理员（sub） | 仅被勾选的模块；「管理员」页只显示「我的账号」（可改自己密码） |

- 授权粒度即后台模块：概览 / 产品管理 / 合作企业 / 渠道管理 / 登录页设置 / 邮箱设置 / 跳转设置
- 未授权模块**后台隐藏菜单 + 直接访问地址也会被拦截**：页面显示「无访问权限」，保存类接口（`save_config.php`、`products_save.php`、`companies_save.php`、`upload_bg.php`）返回 403，不会写入
- 安全约束：不能停用/降级/删除当前登录账号；始终至少保留一个启用状态的超级管理员；用户名唯一；新密码至少 6 位
- 密码存储：新建/改密使用 `password_hash`；历史 MD5 密码继续可用，并在首次登录成功后自动升级为 `password_hash`
- 账号被停用或删除后，已登录的会话会在下一次请求时自动失效并跳回登录页

> 升级兼容：老站点的第一个管理员账号会被自动识别为超级管理员；`admin_user` 表的新增字段由 `inc/admin.php` 幂等升级，无需手动执行 SQL。

## 对接方式（每渠道可选）

后台「渠道管理」里每个渠道都有**对接方式**下拉：

| 方式 | 说明 |
| --- | --- |
| 直连官方 OAuth | 默认方式。在该平台开放平台申请自己的 AppID/密钥，走官方授权 |
| 对接聚合平台 | 经惊霄/彩虹聚合登录中转：AppID/AppSecret 填聚合平台分配的凭证，「跳转设置」中填聚合平台 API 域名；回调地址仍为 `callback.php?channel=xxx` |

适用渠道（聚合平台支持的中转类型）：QQ / 微信 / 支付宝 / 微博 / 百度 / 抖音 / 华为 / 小米 / 哔哩哔哩 / 谷歌 / Facebook / Twitter / 飞书 / 钉钉 / Gitee / GitHub。
「聚合平台登录」渠道本身为聚合平台统一入口，固定直连。

## 聚合平台对接（惊霄 / 彩虹聚合登录）

系统内置 `juhe` 渠道，用于把另一套聚合登录平台（如惊霄聚合登录 jhdl.惊霄.top）作为登录提供方接入：

1. 在惊霄/彩虹聚合登录平台后台创建应用，拿到 **AppID** 和 **AppKey**
2. 本系统后台「渠道管理」开启「聚合平台登录」，填入：
   - AppID → 惊霄平台的应用 ID
   - AppSecret → 惊霄平台的应用密钥（AppKey）
   - 回调地址 → `https://你的域名/callback.php?channel=juhe`
3. 本系统后台「跳转设置」填写「聚合平台 API 域名」：`https://jhdl.你的域名.top`（去掉结尾斜杠）
4. 登录页点击「聚合平台登录」→ 选择 QQ/微信/支付宝 等任一方式 → 跳转惊霄平台授权 → 回调后自动登录

对接协议（彩虹聚合登录规范）：
- 取登录地址：`GET /connect.php?act=login&appid=..&appkey=..&type=..&redirect_uri=..` → 返回 `{code,url,qrcode}`
- 换用户信息：`GET /connect.php?act=callback&appid=..&appkey=..&type=..&code=..` → 返回 `{code,social_uid,access_token,faceimg,nickname}`
- 查询接口：`GET /connect.php?act=query&appid=..&appkey=..&type=..&social_uid=..`

## 各渠道申请说明（简述）

| 渠道 | 申请入口 |
| --- | --- |
| GitHub | github.com/settings/developers → OAuth Apps |
| Gitee | gitee.com/oauth/applications |
| 支付宝 | open.alipay.com → 开放平台密钥 → 网页授权 |
| QQ | connect.qq.com 应用管理 |
| 微信 | open.weixin.qq.com 网站应用 |
| 微博 | open.weibo.com |
| 百度 | developer.baidu.com |
| 钉钉 | open.dingtalk.com |
| 抖音 | developer.open-douyin.com |
| 飞书 | open.feishu.cn 应用 → 安全设置 → 重定向 URL |
| 开源中国 | gitee.com/oauth 或 oschina 开放平台 |
| 华为 | 华为开发者联盟 → AppGallery Connect → 我的项目 → 开通华为账号服务 |
| 谷歌 | Google Cloud Console → APIs & Services → Credentials → OAuth 2.0 客户端 |
| 微软 | Azure Portal → Azure Active Directory → 应用注册 |
| 企业微信 | 企业微信管理后台 → 应用管理 → 自建应用（AppID 填「CorpID|AgentId」） |
| 小米 | 小米开放平台 → 管理中心 → 账号服务 → 创建网站应用 |
| 哔哩哔哩 | 哔哩哔哩开放平台 → 开发者中心 → 创建应用 |
| GitLab | gitlab.com/-/profile/applications 创建应用（自建 GitLab 改域名即可） |
| X (Twitter) | developer.twitter.com → 应用 → OAuth 2.0 Client（需填回调 URL，PKCE 固定 plain） |
| Facebook | developers.facebook.com → 应用 → Facebook 登录（产品）配置 OAuth 重定向 |
| Discord | discord.com/developers/applications → OAuth2 重定向 |
| LINE | developers.line.biz → LINE Login 渠道（需设置回调 URL） |
| 领英 | linkedin.com/developers → 应用 → Auth 设置回调 |
| 360 | open.360.cn 申请（部分接口需审核） |
| 豆瓣 | developers.douban.com（申请 API Key） |
| 网易 | open.163.com 网易开放平台（OAuth2） |
| 淘宝 | open.taobao.com 开放平台（需企业/个人开发者资质） |
| 聚合平台 | 对接惊霄 / 彩虹聚合登录协议，详见下方「聚合平台对接」 |
| Coding | coding.net 开放平台 |

## 注意事项

- 建议 PHP 7.4+ / MySQL 5.7+，开启 `mysqli`、`fileinfo` 扩展
- 上传目录 `assets/uploads/`、`assets/uploads/products/` 需有写入权限（755）
- 生产环境务必修改默认管理员密码
- 支付宝渠道需在后台填入**应用私钥**（RSA2 签名使用），并在支付宝开放平台配置授权回调地址
