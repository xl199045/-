<?php
/**
 * 邮箱验证码接口（QQ 邮箱登录）
 * action=send   发送验证码（需后台已配置 SMTP）
 * action=verify 校验验证码并登录
 */
if (!file_exists(__DIR__ . '/config.php')) {
    header('Location: install/');
    exit;
}
require __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');
$action = $_GET['action'] ?? ($_POST['action'] ?? '');
$email = trim($_POST['email'] ?? '');

function out($ok, $msg, $extra = []) {
    echo json_encode(array_merge(['ok' => $ok, 'msg' => $msg], $extra), JSON_UNESCAPED_UNICODE);
    exit;
}

/* ===== 发送验证码 ===== */
if ($action === 'send') {
    if ($email === '') out(false, '请输入邮箱');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) out(false, '邮箱格式不正确');
    // 目前仅支持 QQ 邮箱
    if (strtolower(substr($email, -7)) !== '@qq.com') out(false, '目前仅支持 QQ 邮箱（@qq.com）');

    $smtp = [
        'smtp_host' => $systemConfig['smtp_host'] ?? '',
        'smtp_port' => $systemConfig['smtp_port'] ?? '',
        'smtp_user' => $systemConfig['smtp_user'] ?? '',
        'smtp_pass' => $systemConfig['smtp_pass'] ?? '',
        'smtp_from' => $systemConfig['smtp_from'] ?? '',
        'site_name' => $systemConfig['site_name'] ?? '聚合登录',
    ];
    if (empty($smtp['smtp_user']) || empty($smtp['smtp_pass'])) {
        out(false, '管理员尚未配置邮箱 SMTP，请先在后台「邮箱设置」中配置');
    }

    $code = (string)random_int(100000, 999999);
    $subject = '【' . ($systemConfig['site_name'] ?? '聚合登录') . '】邮箱验证码';
    $body = "您的登录验证码是：{$code}\n\n10 分钟内有效，请勿泄露给他人。\n（本邮件由系统自动发送，请勿回复）";
    $result = smtp_send($email, $subject, $body, $smtp);

    if ($result === true) {
        $_SESSION['email_code'] = $code;
        $_SESSION['email_code_expire'] = time() + 600;
        $_SESSION['email_code_target'] = $email;
        out(true, '验证码已发送到 ' . $email . '，请查收（10 分钟内有效）');
    } else {
        out(false, '发送失败：' . $result);
    }
}

/* ===== 校验验证码并登录 ===== */
if ($action === 'verify') {
    $code = trim($_POST['code'] ?? '');
    if ($email === '' || $code === '') out(false, '请输入邮箱和验证码');
    if (!isset($_SESSION['email_code']) || !isset($_SESSION['email_code_target'])) out(false, '请先获取验证码');
    if ($_SESSION['email_code_target'] !== $email) out(false, '邮箱与获取验证码的邮箱不一致');
    if (time() > ($_SESSION['email_code_expire'] ?? 0)) out(false, '验证码已过期，请重新获取');
    if ((string)$_SESSION['email_code'] !== $code) out(false, '验证码错误');

    // 登录成功（邮箱即账号：已存在则登录，不存在则自动注册并绑定该 QQ 邮箱）
    $nickname = explode('@', $email)[0];
    $uid = uc_resolve_email_login($conn, $email);
    uc_login_log($conn, 'email', $email, $nickname);
    uc_set_session($conn, $uid, 'email', $email, $nickname, '');

    unset($_SESSION['email_code'], $_SESSION['email_code_expire'], $_SESSION['email_code_target']);

    $success_url = !empty($systemConfig['success_redirect']) ? $systemConfig['success_redirect'] : '/user.php';
    out(true, '登录成功', ['redirect' => $success_url]);
}

out(false, '无效请求');
